//Incluyo biblioteca de entrada/salida.
#include <stdio.h>


int suma(int x, int y){
  return x+y;
}
int resta( int x,int y){
  return x-y;
}
int multiplicacion(int x, int y){
  return x*y;
}
float division(int x, int y){
  float result=0.0;
  if(y>0){
	result= (float)x/ (float)y;
  }else{
	printf("No se puede hacer esta operacion para los numeros %d--%d \n", x,y);
  }
  return result;
}


int pal(int num){
   int r,sum=0,temp,i, digitos=0,nume;
   nume = num;
   temp = num;
   while(nume/10>0){
    nume=nume/10;
    digitos++;
    }
    if (digitos == 8){
      for(i=0; i<9;i++){
       r = num%10;
       sum = sum*10+r;
       num = num/10;
       }
     num=temp;
     if (num==sum){
        printf("Es palindromo\n");
        }
     else{
        printf("No es palindromo\n");
        }
    }
   else{
     printf("Este numero no tiene 9 digitos\n");
     }
}


int calcularAnio(int anio){
   if (anio % 400 == 0) {
      return 1;
   }

   else if (anio % 100 == 0) {
      return 0;
   }
   
   else if (anio % 4 == 0) {
      return 1;
   }
   
   else {
      return 0;
   }
}

int main(){
  int numUno,numDos,resultadoEntero,numPal,pali,anio, bisiesto;
  float resultadoDecimal;
  printf("Bienvenidos a este programa \n");
  printf("Ingrese el num uno \n");
  scanf("%d",&numUno);
  printf("Ingrese el num dos \n");
  scanf("%d",&numDos);
  printf("Ingresa un numero de 9 digitos\n");
  scanf("%d",&numPal);
  printf("Ingrese un anio ");
  scanf("%d",&anio);
  

  
  //Operaciones
  resultadoEntero=suma(numUno,numDos);
  printf("Resultado de la suma %d \n", resultadoEntero);
  
   resultadoEntero=resta(numUno,numDos);
  printf("Resultado de la resta %d \n", resultadoEntero);
  
   resultadoEntero=multiplicacion(numUno,numDos);
  printf("Resultado de la multiplicacion %d \n", resultadoEntero);
  
   resultadoDecimal=division(numUno,numDos);
  printf("Resultado de la division %f \n", resultadoDecimal);

   pali = pal(numPal);

   bisiesto = calcularAnio(anio);
  if (bisiesto==1){
    printf("El anio %d es bisiesto y mi nombre es Juan",anio);
  }
  else{
    printf("El anio %d no es bisiesto y tengo 1 hermano",anio);
  }
  
  return 0;

}
