X=11
Y=9
Z=10
W=4
if X>W:
    print("verdadero")
else:
    print("falso")
    
X=11
Y=9
Z=10
W=4

if X>Y and Z<4:
    print("Verdadero")
else:
    print("Falso")
X=11
Y=9
Z=10
W=4

if not Y==X >X  :
    print("Verdadero")
else:
    print("Falso")


X=11
Y=9
Z=10
W=4

if (X+Z)>=Y and (Z+W)==X or (Y+W==X)>Z:
    print("Verdadero")
else:
    print("Falso")
if X>Y and Z<4:
    print("Verdadero")
else:
    print("Falso") 
