a = input("ingrese a:")
b = input("ingerse b:")
y = a
z = b

print("El nuevo valor de a es:", z)
print("El nuevo valor de b es:", y)
