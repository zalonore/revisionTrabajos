#Area de un circulo
pi = 3.1416
radio = int(input (" Escribe el radio: "))
area = pi * radio**2
print("el area del circulo es:",area)
