#include<stdio.h>


int main(){

    int i = 0, j = 0, k = 0, n = 0, largo = 0;
    int index = 0;
 
    char str[500], str2[500], palabra[50];

    printf("\nIngrese el texto inicial: ");
    gets(str);

    printf("\nPalabra a quitar: ");
    gets(palabra);

    while (palabra[i] != '\0'){
        largo++; 
        i++;
    }

    for(i = 0 ; str[i] != '\0' ; i++){
    	
        k = i;
        while(str[i] == palabra[j]){

            i++, j++;
            if(j == largo){
                index = 1;
                break;
            }
        }

    j = 0;

    if(index == 0){
        i = k;      
    } else {
        index = 0;
    }

    str2[n++] = str[i];

    }

    str2[n] = '\0';
    
    printf("\nTexto Final: %s", str2);
}