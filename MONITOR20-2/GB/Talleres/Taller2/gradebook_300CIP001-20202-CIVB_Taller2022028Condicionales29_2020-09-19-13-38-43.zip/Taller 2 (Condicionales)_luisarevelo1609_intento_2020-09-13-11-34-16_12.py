x=int(input("digite la cantidad de personas:"))
y=(input("digite la temporada en la que se encuentra:(alta o baja):"))
z= (input("digite la cantidad de atracciones a disfrutar:(8 o todas):"))


alta=49000*x
baja=45000*x
ochoalta=22000*x
ochobaja=20000*x

if y=="alta":
    if  z=="8":
        print("su valor base , segun sus opciones es:", ochoalta)
        print("ademas, su valor a pagar en taquilla es:", ochoalta*1.06) 
    
    else:
         print("su valor base , segun sus opciones es:", alta)
         print("ademas, su valor a pagar en taquilla es:",alta*1.06)
         
elif y=="baja":
    if z=="8":
        print("su valor base , segun sus opciones es:", ochobaja)
        print("ademas, su valor a pagar en taquilla es:", ochobaja*1.06)
        
    else:
        print("su valor base , segun sus opciones es:", baja)
        print("ademas, su valor a pagar en taquilla es:",baja*1.06)

        
     


    
