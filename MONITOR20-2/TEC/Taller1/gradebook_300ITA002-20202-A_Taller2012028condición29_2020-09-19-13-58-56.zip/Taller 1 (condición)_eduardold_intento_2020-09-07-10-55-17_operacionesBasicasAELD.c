
//Incluyo biblioteca de entrada/salida.
#include <stdio.h>


int suma(int x, int y){
  return x+y;
}
int resta(int x, int y){
  return x-y;
}
int multiplicacion(int x, int y){
  return x*y;
}
float division(int x, int y){
  float result=0.0;
  if(y>0){
	result= (float)x/ (float)y;
  }else{
	printf("No se puede hacer esta operacion para los numeros %d--%d \n", x,y);
  }
  return result;
}

void comprobarPalin(int num){
  if((num / 100000000 == num % 10) && ((num / 10000000) % 10 == (num % 100) / 10) && ((num / 1000000) % 10 == (num % 1000) / 100) &&( (num / 100000) % 10 == (num % 10000) / 1000)){
  printf("El numero %d es palindromo \n", num);
  }
  else{
  printf("El numero %d no es palindromo \n", num);
  }
}

int comprobarBisiesto(int num){
  int flag = 0;
  if(num % 400 == 0){
     flag = 1;
  }
  else if(num % 4 == 0 && num % 100 != 0){
     flag = 1;
  }
  return flag;
}

int main(){
  int num1,num2,num3,num4,resEntero,resBisiesto;
  float resDiv;
  printf("Bienvenidos a este programa \n");
  printf("Ingrese el num uno \n");
  scanf("%d",&num1);
  printf("Ingrese el num dos \n");
  scanf("%d",&num2);
  //Operaciones
  resEntero=suma(num1,num2);
  printf("Resultado de la suma %d \n", resEntero);
  
  resEntero=resta(num1,num2);
  printf("Resultado de la resta %d \n", resEntero);
  
  resEntero=multiplicacion(num1,num2);
  printf("Resultado de la multiplicacion %d \n", resEntero);
  
  resDiv=division(num1,num2);
  printf("Resultado de la division %f \n", resDiv);

  printf("Ingrese el numero para verificar si es palindromo \n");
  scanf("%d",&num3);
  comprobarPalin(num3);

  printf("Ingrese el anio \n");
  scanf("%d",&num4);
  resBisiesto=comprobarBisiesto(num4);

  if(resBisiesto == 1){
    printf("El anio %d es bisiesto\nMi nombre es Andres Eduardo Lozano Diaz", num4);
}
  else{
    printf("El anio %d no es bisiesto\nTengo 2 hermano(s)", num4);
}
  return 0;


}