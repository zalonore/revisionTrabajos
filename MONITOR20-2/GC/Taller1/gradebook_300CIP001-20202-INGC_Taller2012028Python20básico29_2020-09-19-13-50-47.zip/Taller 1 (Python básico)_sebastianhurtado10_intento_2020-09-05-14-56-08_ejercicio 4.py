# Area y perimetro del rectangulo
altura = int(input(" Escribe la altura: "))
base = int(input(" Escriba la base: "))
area = base * altura
perimetro = base*2 + altura*2
print(f"El area es: {area}. El perimetro es: {perimetro}")
