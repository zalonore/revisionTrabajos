#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifdef _WIN32
#define CLEAR "cls"
#else //In any other OS
#define CLEAR "clear"
#endif

#define PAUSE "pause > nul"
#define PAUSE2 printf_s("\nPresiona cualquier tecla para continuar\n-->");system(PAUSE);

void guessNumberGame(){
    const unsigned MAXNUMBER = 5000;
    unsigned number = rand()%(MAXNUMBER+1);
    unsigned guess = number+1;
    int guessResult = -1;
    char* messages[] = {"\n","El anterior (%d) numero fue mayor!\n","El anterior numero (%d) fue menor!\n"};
    char* message = messages[0];
    unsigned tries = 0;
    do
    {
        if(guessResult == 0) message = messages[1];
        else if(guessResult == 1) message = messages[2];
        system(CLEAR);
        printf_s("ADIVINA UN NUMERO HASTA %d!!!\n\n",MAXNUMBER);
        printf_s(message,guess);
        printf_s("\nEsribe el numero y presiona enter\n--> ");
        scanf_s("%u",&guess);
        tries++;
        if(guess > number) message = messages[1];
        else message = messages[2];
    } while (guess != number);
    
    printf_s("Adivinaste el numero %d en %d intentos\n",number,tries);
    PAUSE2
}

void numberBetween2Game(const int number1, const int number2, const int magicNumber, const unsigned attemps){
    char* messages[] = {"\n","El numero ha sido mal digitado\n","Felicitaciones!!!.\n",\
    "Venga manana por un premio!.\n","Es muy sospechoso!!\n"};
    char* message = messages[0];
    unsigned n = 0, entre50y60 = 0, number71Count = 0, numbersCount = 0, numbersSum = 0;
    int selection;
    do
    {
        system(CLEAR);
        printf_s("Ingrese un numero\n\n");
        printf_s("Feedback: \"%s\"\n",message);
        printf_s("--> ");
        scanf_s("%d",&selection);
        if(selection < number1 || selection > number2) message = messages[1];
        else if(selection == magicNumber){
            number71Count++;
            if(number71Count < 3) message = messages[number71Count+1];
            else message = messages[3+1];
        }else
        {
            numbersCount++;
            numbersSum+=selection;
            //No se incluyen los numeros 50 ni 60.
            if( selection < 60 && selection > 50) entre50y60++;
        }
        
    } while (++n < attemps);

    float average = (float)numbersSum/(float)numbersCount;
    printf_s("El promedio de los numeros ingresados (Ignorando los %d) es: %f \n",magicNumber, average);
}

void laFarra(){
    int counting = 1,selection,nPapas=0,nTomates=0,nCebollas=0,nNaranjas=0,nMangos=0;
    int nCamionesA = 0, nCamionesB = 0, tipoCamionB, camionB2=0,camionB3=0,camionB4=0;
    while(counting != 0){
        system(CLEAR);
        printf_s("1. Agregar Camion al inventario\n");
        printf_s("2. Terminar\n");
        scanf_s("%d",&selection);
        switch (selection)
        {
        case 1:
            //preguntar el tipo de camion
            system(CLEAR);
            printf_s("1. Agregar Camion tipo A\n");
            printf_s("2. Agregar Camion tipo B\n");
            printf_s("3. Volver\n");
            scanf_s("%d",&selection);
            switch (selection)
            {
            case 1:
                system(CLEAR);
                printf_s("Ha seleccionado Camion tipo A\n");
                printf_s("Ingrese el numero de Papas que trae el camion\n");
                printf_s("Ingrese -1 o un numero negativo para volver y omitir el camion seleccionado\n");
                scanf_s("%d",&selection);
                nCamionesA++;
                if(selection >= 0){
                    nPapas+=selection;
                }else nCamionesA--;
                break;
            case 2:
                system(CLEAR);
                printf_s("Ha seleccionado Camion tipo B\n");
                printf_s("1. Camion de 2 Productos\n");
                printf_s("2. Camion de 3 Productos\n");
                printf_s("3. Camion de 4 Productos\n");
                scanf_s("%d",&selection);
                switch (selection)
                {
                case 1:
                    camionB2++;
                    tipoCamionB = 1;
                    break;
                case 2:
                    camionB3++;
                    tipoCamionB = 2;
                    break;
                case 3:
                    camionB4++;
                    tipoCamionB = 3;
                    break;
                
                default:
                    tipoCamionB = 0;
                    break;
                }
                if(tipoCamionB > 0){
                    system(CLEAR);
                    printf_s("Ha seleccionado Camion tipo B\n");
                    printf_s("Ingrese el numero de Tomates que trae el camion\n");
                    printf_s("Ingrese -1 o un numero negativo para volver y omitir el camion seleccionado\n");
                    scanf_s("%d",&selection);
                    nCamionesB++;
                    if(selection >= 0 && tipoCamionB > 0){
                        nTomates+=selection;
                        system(CLEAR);
                        printf_s("Ha seleccionado Camion tipo B\n");
                        printf_s("Ingrese el numero de Cebollas que trae el camion\n");
                        printf_s("Ingrese -1 o un numero negativo para volver y omitir el camion seleccionado\n");
                        scanf_s("%d",&selection);
                        if(selection >= 0 && tipoCamionB > 1){
                            nCebollas+=selection;
                            system(CLEAR);
                            printf_s("Ha seleccionado Camion tipo B\n");
                            printf_s("Ingrese el numero de Naranjas que trae el camion\n");
                            printf_s("Ingrese -1 o un numero negativo para volver y omitir el camion seleccionado\n");
                            scanf_s("%d",&selection);
                            if(selection >= 0 && tipoCamionB > 2){
                                nNaranjas+=selection;
                                system(CLEAR);
                                printf_s("Ha seleccionado Camion tipo B\n");
                                printf_s("Ingrese el numero de Mangos que trae el camion\n");
                                printf_s("Ingrese -1 o un numero negativo para volver y omitir el camion seleccionado\n");
                                scanf_s("%d",&selection);
                                if(selection >= 0){
                                    nMangos+=selection;
                                }else nCamionesA--;
                            }else nCamionesA--;
                        }else nCamionesA--;
                    }else nCamionesA--;
                }
                break;
            
            default:
                break;
            }
            break;
        case 2:
            counting = 0;
            break;
        default:
            counting = 1;
            break;
        }
        
    }
    //Si hay camiones quiere decir que llegaron productos, por tanto hay inventario que hacer.
    if(nCamionesA > 0 || nCamionesB > 0){
        printf_s("Llegaron %d Camiones tipo A\n",nCamionesA);
        printf_s("Llegaron %d Camiones B3 y %d Camiones tipo B4\n",camionB3,camionB4);
        printf_s("Llegaron %d Kilos de Papas\n%d Kilos de Tomates\n&d Kilos de Cebollas\n\
        %d Kilos de Naranjas\n%d Kilos de Mangos",nPapas,nTomates,nCebollas,nNaranjas,nMangos);
    }

}

unsigned sumDigits(unsigned x){
    unsigned nDigits = 1, sum=0,tmp1,tmp2;
    while (pow(10,nDigits) < x){
        nDigits++;
    }
    for (unsigned i = 1; i < nDigits; i++)
    {
        tmp1 = pow(10,i);
        tmp2 = pow(10,i-1);
        sum+=((x%tmp1)-(x%tmp2))/tmp2;
    }
    return sum;
    
}

void primos1aN(const unsigned N){
    unsigned primeIndex = 0;
    unsigned* marcas = (unsigned*)malloc(N*sizeof(unsigned));
    unsigned* primos = (unsigned*)malloc(N*sizeof(unsigned));
    for (unsigned i0 = 0; i0 < N; i0++){
        marcas[i0] = 0;primos[i0]=0;
    }
    
    for(unsigned i = 2; i < N; i++){
        if(marcas[i] == 0){
            primos[i] = 1;
            //Se marcan todos los multiplos del numero i
            for(unsigned j = 1; j < N && i*j < N; j++){
                marcas[i*j] = 1;
            }
        }
    }

    //Mostrar los Primos desde el 2 hasta N
    printf_s("Numeros Primos desde el 2 hasta %d\n",N);
    for(unsigned i = 2; i < N; i++){
        if(primos[i] == 1) printf_s("%d, ",i);
    }
    printf_s("\n\n");
    //Numeros primos de 3 digitos
    unsigned nPrimos3Digitos = 0;
    for(unsigned i = 100; i < N && i < 1000; i++){
        if(primos[i] == 1){
            printf_s("%d, ",i); nPrimos3Digitos++;
        }
    }
    printf_s("\nHay %d primos que tienen 3 digitos\n\n",nPrimos3Digitos);

    //Numeros primos que la suma de sus digitos es otro numero primo
    //Desde 2 hasta N
    printf_s("Primos que la suma de sus digitos son primos %d\n");
    unsigned tmpPrim = 0;
    for(unsigned i = 2; i < N; i++){
        if(primos[i] == 1){
            tmpPrim = sumDigits(i);
            if(tmpPrim < N){
                if(primos[tmpPrim] == 1) printf_s("%d -> %d\n",i,tmpPrim);
            }
        }
    }
    free(marcas);
    free(primos);
}

void menu1(){
    printf_s("Haz seleccionado la opcion 1\nEsta corresponde al punto 2.1 del Taller 2\n");
    PAUSE2
    guessNumberGame();
    PAUSE2
}

void menu2(){
    unsigned n = 0;
    printf_s("Haz seleccionado la opcion 2\nEsta corresponde al punto 2.2 del Taller 2\n\n");
    PAUSE2
    system(CLEAR);
    printf_s("Ingrese el numero de veces que desea ingresar numeros en el juego\n--> ");
    scanf_s("%u",&n);
    numberBetween2Game(50,80,71,n);
    PAUSE2
}

void menu3(){
    printf_s("Haz seleccionado la opcion 3\nEsta corresponde al punto 2.3 del Taller 2\n");
    PAUSE2
    laFarra();
    PAUSE2
}

void menu4(){
    printf_s("Haz seleccionado la opcion 4\nEsta corresponde al punto 2.4 del Taller 2\n");
    PAUSE2
    system(CLEAR);
    unsigned N;
    printf_s("Ingrese hasta donde desea calcular los primos\n--> ");
    scanf_s("%u",&N);
    primos1aN(N);
    PAUSE2
}

void menu (){
    int option = 0;
    while(option != -1){
        system(CLEAR);
        printf_s("--------------\nMENU PRINCIPAL\n--------------\n\n");
        printf_s("Escriba el numero del punto del taller que desea ver\n");
        printf_s("1. Punto 1 del taller\n");
        printf_s("2. Punto 2 del taller\n");
        printf_s("3. Punto 3 del taller\n");
        printf_s("4. Punto 4 del taller\n");
        printf_s("-1. Salir\n");
        printf_s("--> ");
        scanf_s("%d",&option);
        switch (option)
        {
        case 1:
            menu1();
            break;
        case 2:
            menu2();
            break;
        case 3:
            menu3();
            break;
        case 4:
            menu4();
            break;        
        default:
            break;
        }
    }
}

int main(int argc, char const *argv[])
{
    /* code */
    menu();
    return 0;
}
