#include <stdio.h>

int main(){
	int i;
	char texto[ 1000 ];
	printf( "ponga el texto:\n");

	fgets( texto, sizeof(texto), stdin );
	for( i = 0; i < sizeof(texto); i++ ){
		if ( texto[ i ] == '\0' ){
    		break;
		}
	}

	texto[ 0 ] -= 32;
	texto[ 16 ] -= 32;
	texto[ 24 ] -= 32;

	printf( "\nParrafo con lo que se pide:\n" );
    printf("\n");
	for( i = 0; i < sizeof(texto); i++ ){
		if ( texto[ i ] == '\0' ){
    		break;
		}
		else{
			printf( "%c", texto[ i ] );
		}

	}
    printf("\n");
	return 0;
}