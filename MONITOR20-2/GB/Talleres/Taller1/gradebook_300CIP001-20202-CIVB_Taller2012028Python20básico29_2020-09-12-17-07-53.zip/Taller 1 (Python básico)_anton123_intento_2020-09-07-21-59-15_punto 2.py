numero1= int(input("dijite un valor="))
numero2= int(input("dijite un valor="))


suma=(numero1 + numero2)
resta=(numero1-numero2)
multiplicación=(numero1*numero2)
divición=(numero1/numero2)
potencia=(numero1**numero2)


print("el resultado de su suma es=",suma)
print("el resultado de su resta es=",resta)
print("el resultado de su multiplicación es=", multiplicación)
print("el resultado de su divición es=",divición)
print("el resultado de su potencia es=",potencia)
