## 1)se solicitan los datos al usuario
a=int(input("ingrese primer valor:"))
b=int(input("ingrese segundo valor:"))
## 2) se procede a calcular si los valores digitados para a y b son pares
r1=(a%2==0)
r2=(b%2==0)
## 3) si a es par, continua por aqui:

if r1:
##         4) ahora, se analiza si b es par entonces continua aca y se calcula a*b:    
    if r2:
        print(a*b)
##      5) pero, si a es par y b impar, se realiza la operacion a*a        
    else:
        print(a*a)
## 6) si a no fue par, es decir, es impar continua aqui:
else:
##     7) ahora, si b es par , entonces se calcula b*b:    
    if r2:
        print(b*b)
##    8)  si a es impar, pero b no es par, (es impar), entonces el resultado es nulo
    else:
        print(0)


## B)  si a=11 b=2, el programa imprime en pantalla: 4
        
## porque? si analizamos, el primer camino o if, el cual estudia si a es par, entonces conforme a esto podemos comprobar que no lo es, por tanto, sigue
##         el otro camino del else, a partit de este, continua los dos subcaminos del else, en donde el primero de ellos analiza si b es par, y como si
##        lo es , se calcula el resultado de la operacion definida aqui.          
        
        
        
