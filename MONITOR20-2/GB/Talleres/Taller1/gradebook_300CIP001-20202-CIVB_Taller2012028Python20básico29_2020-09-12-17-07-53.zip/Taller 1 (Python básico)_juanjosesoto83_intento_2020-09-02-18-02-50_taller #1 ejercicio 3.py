print ("EJERCICIO 2")

radio= int(input("escriba radio de la circunferencia"))
pi= 3.1415
area= (radio**2)*pi
print( "el area del circulo es:", area)
