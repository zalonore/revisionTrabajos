numero = int(input("Digite numero entero:"))

if numero%2==0:
    print("true")
else:
    print("false")
    
