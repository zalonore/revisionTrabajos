#include<stdio.h>
#include<conio.h>

int remover_duplicados(int d[], int x) {

  if (x == 0 || x == 1)
    return x;
  int temp[x];

  int j = 0;
  int i;
  for (i = 0; i < x - 1; i++)
    if (d[i] != d[i + 1])
      temp[j++] = d[i];
  temp[j++] = d[x - 1];

  for (i = 0; i < j; i++)
    d[i] = temp[i];

  return j;
}

int main(){
   int i, j, k, eq, n = 0, x = 0 , a[20], b[20], c[20], d[x];

   printf("\nIngrese el conjunto a: ");
   for(i = 0; i < 20; i++){
      scanf("%d", &a[i]);
   }
   printf("\nIngrese el conjunto b: ");
   for(i = 0; i < 20; i++){
      scanf("%d", &b[i]);
   }
   printf("\nIngrese el conjunto c: ");
   for(i = 0; i < 20; i++){
      scanf("%d", &c[i]);
   }
   for (i = 0; i < 20; i++) {
      for (j = 0; j < 20; j++) {
          for (k = 0; k < 20; k++) {
            if (a[i] == b[j] && c[k] == a[i] ) {
               x++;
               eq == 1;
            } 
            if (eq == 1) {    
	           d[n] = a[i];
	           n++;
        }
        eq = 0;
           }
        }
    }

  n = remover_duplicados(d, x);

    printf("conjunto d : ");
    for(i = 4; i < x+4 ; i++){
      printf(" %d ", d[i]);
    }
    return 0;
}
