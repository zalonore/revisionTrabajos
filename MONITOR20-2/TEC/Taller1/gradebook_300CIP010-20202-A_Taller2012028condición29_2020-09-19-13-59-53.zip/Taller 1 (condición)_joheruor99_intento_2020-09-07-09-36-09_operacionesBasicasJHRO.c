
//Incluyo biblioteca de entrada/salida.
#include <stdio.h>

int sumar(int x, int y){
  return x+y;
}
int restar(int x, int y){
  return x-y;
}
int multiplicar(int x, int y){
  return x*y;
}
float dividir(int x, int y){
  float result=0.0;
  if(y>0){
	result= (float)x/ (float)y;
  }else{
	printf("No se puede hacer esta operacion para los numeros %d--%d \n", x,y);
  }
  return result;
}

void capicua(int x){
  int i;
  int digito;
  int invertido = 0;
  int num = x;
  for(i=1;i<9;i++){
    digito = num%10;
    num = num / 10;
    invertido = invertido*10 + digito;
  }
  invertido = invertido*10 + num;
  if(invertido%x == 0){
    printf("El numero es capicua\n");
  }else{
    printf("El numero no es capicua\n");
  }
}

int bisiesto(int anio){
  if(((anio%4 == 0) && (anio%100 != 0)) || (anio%400 == 0)){
    return 1;
  }else{
    return 0;
  }
}
    

int main(){
  int num1,num2,resultado,anio,palin;
  float resultadoDiv;
  printf("Bienvenidos a este programa \n");
  printf("Ingrese el numero uno \n");
  scanf("%d",&num1);
  printf("Ingrese el numero dos \n");
  scanf("%d",&num2);
  
  //Operaciones
  resultado=sumar(num1,num2);
  printf("La suma de los dos numeros es %d \n", resultado);
  
  resultado=restar(num1,num2);
  printf("La resta %d - %d da como resultado %d \n", num1,num2,resultado);
  
  resultado=multiplicar(num1,num2);
  printf("El resultado de multiplicar ambos numeros es %d \n", resultado);
  
  resultadoDiv=dividir(num1,num2);
  printf("Dividir %d entre %d da como resultado %f \n", num1,num2,resultadoDiv);
  
  printf("\nIngrese el numero a evaluar (Debe ser de 9 digitos)\n");
  scanf("%d", &palin);
  capicua(palin);

  printf("\nIngrese el anio \n");
  scanf("%d",&anio);
  if(bisiesto(anio)){
    printf("El anio %d es bisiesto y mi nombre es JOHAN\n",anio);
  }else{
    printf("El anio %d no es bisiesto y tengo 2 hermanos\n",anio);
  }

  return 0;

}