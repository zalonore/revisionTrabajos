#include <stdio.h>
#define CAP 250

int main(){
	int i, cont, acum = 0;
	char cadena[ CAP ];
	printf( "Digite el parrafo a convertir:\n");

	fgets( cadena, CAP, stdin );

	cadena[ 0 ] -= 32;
	cadena[ 16 ] -= 32;
	cadena[ 24 ] -= 32;
	cadena[ 31 ] -= 32;

	printf( "Parrafo cambiado:\n" );
	puts( cadena );
	return 0;
}