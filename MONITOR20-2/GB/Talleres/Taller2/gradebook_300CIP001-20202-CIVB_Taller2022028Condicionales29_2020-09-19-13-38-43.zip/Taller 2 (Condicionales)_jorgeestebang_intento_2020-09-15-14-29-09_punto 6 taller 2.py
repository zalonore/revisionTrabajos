usuario=int(input("ingrese a que piso desea ir: "))

if usuario>15:
    print("use el ascensor 1")
elif usuario==1 or usuario==2:
    print("use las escaleras")
elif usuario%2 !=0  and usuario<=15:
    print("use el ascensor 2")
elif usuario%2==0 and usuario<15 :
    print("use el ascensor 3")
else:
    print("numero piso invalido")
