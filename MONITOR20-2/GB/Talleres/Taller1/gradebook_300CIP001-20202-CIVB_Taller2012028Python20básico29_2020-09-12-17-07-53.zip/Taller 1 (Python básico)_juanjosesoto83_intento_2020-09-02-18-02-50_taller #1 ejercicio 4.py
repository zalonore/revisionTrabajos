print("ejercicio 4")
base= int(input("escriba el valor de la base"))
altura= int(input("escriba el valor de la altura"))
perimetro=(2*altura)+(2*base)
area= base*altura
print ( 'el perimetro del rectangulo es:', perimetro)
print ("el area del rectangulo es:", area)
