numero1= float(input("INSERTAR PRIMER NUMERO"))
numero2= float(input("INSERTAR SEGUNDO NUMERO"))
suma= numero1+numero2
resta= numero1-numero2
multiplicacion= numero1*numero2
divicion= numero1/numero2
potencia= numero1**numero2
print( "los resultados son","suma", suma, "resta", resta, "multiplicacion", multiplicacion, "divicion", divicion, " y potencia", potencia)
