numero= int(input("dijite un numero entero de 4 cifras="))
numero1= numero%10
numero2= numero//10
numero3= numero2%10
numero4= numero2//10
numero5= numero4%10
numero6= numero4//10
numero7= numero6%10
numero8= numero6//10



print("su numero invertido es=",numero1,numero3,numero5,numero7)
