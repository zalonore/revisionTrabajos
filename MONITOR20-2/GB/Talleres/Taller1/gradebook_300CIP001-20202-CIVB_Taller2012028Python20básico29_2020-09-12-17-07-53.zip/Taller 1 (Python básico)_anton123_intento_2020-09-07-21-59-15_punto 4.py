altura= int(input("dijite la altura de su rectangulo="))
base= int(input("dijite la base de su rectangulo="))

area= (altura*base)
perimetro= (2*(altura+base))

print("el area de su rectangulo es=",area)
print("el perimetro de su rectangulo es=",perimetro)
