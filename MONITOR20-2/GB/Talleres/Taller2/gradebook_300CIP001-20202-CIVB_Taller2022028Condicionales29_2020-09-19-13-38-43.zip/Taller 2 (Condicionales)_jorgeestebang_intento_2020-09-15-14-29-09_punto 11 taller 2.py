a=int(input("ingrese primer valor: "))
b=int(input("ingrese segundo valor: "))
r1= (a%2==0)
r2= (b%2==0)
if r1:
    if r2:
        print(a*b)
    else:
        print(a*a)
else:
    if r2:
        print(b*b)
    else:
        print(0)

print(" A.) primero el programa pide digitar 2 valores, el programa coje r1 y r2 para realizar operaciones con modulo para saber si son valores pares, si es asi imprime la multiplicacion de los valores, si solo es el primero imprime la multiplicacion de este por este mismo, si no se cumple, se verifica el segundo valor si es par o no, si es par imprime la multipliacion del segundo valor por este mismo sino es asi imprimira 0")

print(" B.) imprime 4 ya que no cumple la primera condicion pero si cumple la segunda condicion entonces lo que imprime es el segundo multiplicaco por este mismo")
