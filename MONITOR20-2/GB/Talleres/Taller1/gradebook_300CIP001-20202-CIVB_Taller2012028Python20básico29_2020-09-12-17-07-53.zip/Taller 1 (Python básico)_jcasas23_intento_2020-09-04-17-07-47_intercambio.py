X = input ("Ingrese la primera variable: ")
Y = input ("Ingrese la segunda variable: ")

Z = X
X = Y
Y = Z

print ("Su primer variable ahora es: ",X)
print ("Su segunda variable ahora es: ",Y)

# Jorge Casas
