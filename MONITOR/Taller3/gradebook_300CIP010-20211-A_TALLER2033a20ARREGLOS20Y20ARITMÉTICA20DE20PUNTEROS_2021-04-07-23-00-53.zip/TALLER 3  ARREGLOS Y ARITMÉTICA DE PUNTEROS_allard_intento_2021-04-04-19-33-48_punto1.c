#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int conjuntoA[20] = {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
int conjuntoB[20] = {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
int conjuntoC[20] = {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
int conjuntoD[20];

void LlenarArreglo(int arreglo[], int limite){
   int i;
   for( i=0; i < 20; i++){
      *(arreglo + i) = 1 + rand() % limite;
   }
}

void Interseccion(int arregloA[], int arregloB[], int arregloC[], int arregloD[]){
   int i,j,m,k,elementoActual,conteo = 0, repetido;

   for( i=0; i < 20; i++){
      elementoActual =  *(arregloA + i);
      repetido = 0;
      for( j=0; j < 20; j++){
         for( m=j; m < 20; m++){
            if( (elementoActual == *(arregloC + m)) && ( *(arregloB + j) == *(arregloC + m))  ){
               for( k=0; k < 20; k++){
                  if (elementoActual == *(arregloD + k)){
                     repetido = 1;
                  }                 
               }               
               if (repetido == 0){
                  *(arregloD + conteo) = elementoActual;
                   conteo = conteo + 1;
               }
            }
         }       
      }
   }   
}

 
int main(){
   int limite, modificacion, contador, i, j, k, tam, temp;
   srand (time(NULL));
   contador = 1;
   printf( "Este programa, hara una lista aleatoria de numeros ubicados en trees conjuntos diferentes A B C, e imprimira una lista adicional E que contienes las intersecciones de los tres conjuntos" );
   printf(" \n");
   printf(" \n");
   printf( "los numeros son aleatorios y van desde 1 hasta un limite fijado por el usuario. Digite aqui ese limite(solo numeros): ");
   scanf("%d", &limite);

   printf( "El arreglo que representa el conjunto A es: ");
   printf(" \n");
   LlenarArreglo(conjuntoA, limite);
   for( contador=0; contador < 20; contador++){
      printf("%d, ",conjuntoA[contador]);
   }
   printf(" \n");
   printf(" \n");
   contador = 2;
   
   printf( "El arreglo que representa el conjunto B es: ");
   printf(" \n");
   LlenarArreglo(conjuntoB, limite);
   for( contador=0; contador < 20; contador++){
      printf("%d, ",conjuntoB[contador]);
   }
   printf(" \n");
   printf(" \n");
   contador = 3;

   printf( "El arreglo que representa el conjunto C es: ");
   printf(" \n");
   LlenarArreglo(conjuntoC, limite);
   for( contador=0; contador < 20; contador++){
      printf("%d, ",conjuntoC[contador]);
   }
   printf(" \n");
   printf(" \n");

   printf( "El arreglo que representa la interseccion entre los tres conjuntos es: ");
   printf(" \n");
   Interseccion(conjuntoA, conjuntoB, conjuntoC, conjuntoD);
   for( contador=0; contador < 20; contador++){
      if (conjuntoD[contador] != 0){
         printf("%d, ",conjuntoD[contador]);
      }
   }
   printf(" \n");
   printf(" \n");



   

  


   return 0;

}