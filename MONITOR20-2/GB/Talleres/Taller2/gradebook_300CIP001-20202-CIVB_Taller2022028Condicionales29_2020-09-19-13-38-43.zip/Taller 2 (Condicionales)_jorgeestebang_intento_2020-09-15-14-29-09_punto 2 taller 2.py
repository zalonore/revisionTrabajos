numero=int(input("digite un numero: "))
if numero%2==0:
    print("es par")
else:
    print("es impar")
