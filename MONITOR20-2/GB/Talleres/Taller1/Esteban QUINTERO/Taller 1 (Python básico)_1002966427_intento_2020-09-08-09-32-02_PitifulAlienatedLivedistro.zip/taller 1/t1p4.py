x = float(input ("digite la altura: "))
y = float(input ("digite la base: "))
perimetro = x*2 + y*2
Area = x*y
print ("El area es: ",Area,". Y el perimetro es: ",perimetro)
 