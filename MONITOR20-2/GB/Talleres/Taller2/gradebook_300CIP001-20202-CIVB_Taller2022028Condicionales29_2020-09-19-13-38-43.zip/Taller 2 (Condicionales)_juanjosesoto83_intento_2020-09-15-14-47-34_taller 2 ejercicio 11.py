## 1)se solicitan los datos al usuario
a=int(input("introducir un numero"))
b=int(input("introducir un numero"))
## 2) se procede a calcular si los valores digitados para a y b son pares
r1=(a%2==0)
r2=(b%2==0)
## 3) si A es par:

if r1:
##         4)si b es par entonces continua se calcula a*b:    
    if r2:
        print(a*b)
##      5) pero, si a es par y b impar, se realiza la operacion a*a        
    else:
        print(a*a)
## 6) si a  es impar :
else:
##     7) si b es par , entonces se calcula b*b:    
    if r2:
        print(b*b)
##    8)  si a es impar, pero b no es par, entonces el resultado es nulo
    else:
        print(0)


## B)  si a=11 b=2, el programa imprime en pantalla: 4
        
## porque? como a es impar la unica posibilidad del programa es tomar el primer if, a lo cual procede en multiplicar b*b dando 4 como resultado
        
        
        
        
