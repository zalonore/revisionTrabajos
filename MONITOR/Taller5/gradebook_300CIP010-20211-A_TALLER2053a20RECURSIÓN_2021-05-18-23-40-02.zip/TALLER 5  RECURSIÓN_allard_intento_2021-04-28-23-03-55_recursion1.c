#include <stdio.h>
#include <stdlib.h>


int fibonacci(int m){
   if (m > 1){
      return fibonacci(m-1) + fibonacci(m-2);
   }
   
   if(m == 1){
      return 1;
   }
   
   if( m == 0){
      return 0;
   }
   // esta funcion usa recursividad no final(porque incluye operaciones aritmeticas ligada a la llamada recursiva)
}


int mayorNumero( int arreglo[], int contador, int maximo ){
   if (arreglo[contador] > maximo){
      maximo = arreglo[contador];
   }

   if (contador == 11){
      return maximo;
   }
   else{
      return mayorNumero( arreglo , contador+1, maximo );
   }
   
   //esta funcion usa recursividad final
}

int maximoComunDivisor(int m, int n){
   int r;
   if (n == 0){
      return m;
   }
   else{
      r = m % n;
      return maximoComunDivisor(n, r);
   }
   //esta funcion usa recursividad final
}


int multiploEnteros(int minimo, int maximo, int actual, int totalSuma){
   if (actual % 3 == 0){
      totalSuma = totalSuma + actual;
   }

   if (actual == maximo){
      return totalSuma;
   }
   else{
      return multiploEnteros(minimo, maximo, actual+1, totalSuma);
   }
   //Esta funcion usa recursividad directa
   
   
}

void menu(){
   int minimo, maximo, actual, opcion, resultado, totalSuma, m, n, contador;
   printf("Bienvenido al programa de recursiones, este programa estara dividido en cuatro secciones diferentes para analisis de recursion, dichas secciones son: ");
   printf(" \n");
   printf("1. Suma de multiplos de 3 de un intervalo ");
   printf(" \n");
   printf("2. Maximo comun divisor de dos numeros positivos");
   printf(" \n");
   printf("3. Valor mayor entre un arreglo establecido");
   printf(" \n");
   printf("4. Sucesion de fibonacci ");
   printf(" \n");
   printf(" \n");
   printf("Ingrese aqui el numero correspondiente a la seccion que desee analizar(cualquier otro valor terminara el programa): ");
   scanf("%d", &opcion);
   
   switch(opcion){
      case 1:  
         printf("Ahora, hallaremos los numeros entre un rango determinado por el usuario, que sean multiplos de 3");
         printf(" \n");
         printf("Digite el numero minimo del intervalo, este debe ser un numero entero(no funciona de otro modo): ");
         scanf("%d", &minimo);
         printf(" \n");
         printf("Digite el numero maximo del intervalo, este debe ser un numero entero: ");
         scanf("%d", &maximo);
         
         actual = minimo;
         totalSuma = 0;

         printf("Los numeros multiplos de 3 que estan entre %d y %d son: ", minimo, maximo );
         printf(" \n");
         resultado = multiploEnteros(minimo, maximo, actual, totalSuma);
         printf("El resultado total de sumar los multiplos de 3 de los intervalos es: %d ", resultado);
         printf(" \n");
         printf(" \n");
         menu();
         break;
     
      case 2:
         printf("Ahora, hallaremos el maximo comun divisor de entre dos numeros enteros positivos");
         printf(" \n");
         printf("Digite aqui el primer numero entero positivo(debe ser menor al segundo): ");
         scanf("%d", &m);
         printf("Digite aqui el segundo numero(debe ser mayor al primero): ");
         scanf("%d", &n);

         resultado = maximoComunDivisor( m, n);
         printf("El Maximo comun divisor de %d y de %d es: %d ", m, n, resultado);
         printf(" \n");
         printf(" \n");
         menu();
         break;
     
      case 3:
         printf( "Para este caso, tendreis en pantalla el valor maximo de un arreglo predeterminado en el programa ");
         int arreglo[] = { 12,15,20,7,6,3,1,0,9,11};
         printf(" \n");
         maximo = 0;
         contador = 0;
         resultado = mayorNumero( arreglo, contador, maximo );
         printf("El valor mas alto dentro del arreglo es: %d ", resultado);
         printf(" \n");
         printf(" \n");
         menu();
         break;

      case 4:
         printf("Para este caso, se utilizara la secuencia fibonacci para obtener el numero de dicha secuancia en la posicion exacta, digitada por el usuario: ");
         printf(" \n");
         printf("Digite aqui la posicion(en entero positivo) del numero de la secuencia que busca hallar: ");
         scanf("%d", &m);
         printf(" \n");
         resultado = fibonacci( m );
         printf("El numero de la sucesion ubicado en la posicion %d es: %d ", m, resultado);
         printf(" \n");
         printf(" \n");     
 
         menu();
         break;

     default:
        printf("El programa ha terminado");
   }
   // esta funcion usa recursividad multiple
}



int main(){
   menu();

   return 0;
}


     


   

   






