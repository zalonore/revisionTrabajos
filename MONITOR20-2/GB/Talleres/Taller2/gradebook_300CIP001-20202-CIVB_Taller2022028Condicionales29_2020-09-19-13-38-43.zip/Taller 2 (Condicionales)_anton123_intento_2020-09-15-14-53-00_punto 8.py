a=int(input("ingresa año"))
if(a % 4 == 0 and a % 100 != 0 or a % 400 == 0):
 print("El año Si es bisiesto ")
else:
 print("El año No es bisiesto ")
