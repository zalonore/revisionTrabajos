a = int (input("Por favor digite un numero de 4 cifras:"))

b = a%10
c = (a%100)//10
d = (a%1000)//100
e = (a%10000)//1000

print (b,c,d,e)
