#include <stdio.h>  


// Realice una función que, dada una cadena de caracteres ingresada por el usuario, 
//retorne la cantidad de caracteres que posee dicha cadena. 
   
int main(){  

    char str[100];  
    int i = 0,j = 0, num = 0;

    printf("Ingrese una cadena de caracteres: ");  
    gets(str);

    while (str[i] != '\0'){
        j++; 
        i++;
    }

    for(i = 0; i < j; i++) {  
        if(str[i] != '\0' && str[i] != ' '){  
            num++;
        }
    } 
      
    printf("Total de caracteres: %d", num);  
   
    return 0;  
}  

