#include <stdio.h>
#include <stdlib.h>

void randomPicker(){
   int numAletorio, cont = 0, numIngresado;
   numAletorio = rand() % 5001;
   while( numAletorio != numIngresado || cont == 5 ) {
      printf( "%d %d ", numAletorio, cont );
      printf( "Ingrese el numero que cree que es:\n" );
      scanf( "%d", &numIngresado );
      if ( cont == 5 ) {
         printf( "Lo siento, pero eres muy lento, tendras que jugar de nuevo\n" );
         randomPicker();
      }
      if( numIngresado < numAletorio ) {
         printf( "El numero ingresado es menor al numero aleatorio\n" );
      }else if( numIngresado > numAletorio ){
         printf( "El numero ingresado es mayor al numero aleatorio\n" );
      }else{
         printf( "Acertaste! Te ha costado %d intentos\n", cont );
      }
      cont++; 
   }
}

void felicidades71(){
   int intentos, rangMenor = 50, rangMayor = 80, cont, contDe71, numIngresado, cantLimites, suma, promedio;
   printf( "Cuantos intentos quiere?\n" );
   scanf( "%d", &intentos );
   while( cont != intentos ){
      printf( "Ingrese un numero entre (50 y 80):\n" );
      scanf( "%d", &numIngresado );
      if ( numIngresado <= rangMenor && numIngresado >= rangMayor ){
         printf( "Se paso del rango dado" );
	 scanf( "%d", &numIngresado );
      }else if ( numIngresado == 71 ){
         contDe71++;
         if( contDe71 == 1 ) {
            printf( "Felicidades por igresar 71\n" );
         }else if( contDe71 == 2 ) {
            printf( "Felicidades, venga mañana por un premio\n" );
         }else if( contDe71 == 3 ) { 
            printf( "Usted esta sospechoso\n" );
         }else{
            printf( "Usted esta sospechoso\n" );
         }   
      }else if( numIngresado >= 50 && numIngresado <= 60 ) {
         cantLimites++;
         suma += numIngresado;
      }else {
         suma += numIngresado;
      }
      cont++;   
   }
   promedio = suma / (cont - contDe71);
   printf( "El promedio de los numeros digitados son: %d\n", promedio );
}

void laFarra(){
   int i, cantCamiones , tipoCamion, cantPapa, totalPapa = 0, tipoA = 0, tipoB = 0, tipoProducto, cantCebolla, cantTomate, cantNaranja, totalCebolla = 0, totalNaranja = 0, totalMango = 0, totalCamiones3 = 0, totalCamiones4 = 0, cantMango;
   printf( "Cuantos camiones llegaron hoy?:\n" );
   scanf( "%d", &cantCamiones );
   for( i = 1; i <= cantCamiones; i++ ){
      printf( "Que tipo de camion es?\n1. Camion tipo A\n2. Camion tipo B\n" );
      scanf( "%d", &tipoCamion );
      switch( tipoCamion ){
         case 1: tipoA++;
            printf( "Cuantos kilos de papa trajo?\n" );
            scanf( "%d", &cantPapa );
            totalPapa += cantPapa; break;
         case 2: tipoB++;
            printf( "Cuantos productos trae el camion?\n" );
            scanf( "%d", &tipoProducto );
            switch( tipoProducto ){
               case 2: printf( "Cuantos bultos de tomate trajo?:\n" );
                  scanf( "%d", &cantTomate );
                  printf( "Cuantos bultos de cebolla trajo?:\n" );
                  scanf( "%d", &cantCebolla ); 
                  totalCebolla += cantCebolla; break;
               case 3: totalCamiones3++;
                  printf( "Cuantos bultos de tomate trajo?:\n" );
                  scanf( "%d", &cantTomate );
                  printf( "Cuantos bultos de cebolla trajo?:\n" );
                  scanf( "%d", &cantCebolla );
                  printf( "Cuantos bultos de naranja trajo?:\n" );
                  scanf( "%d", &cantNaranja );
                  totalCebolla += cantCebolla;
                  totalNaranja += cantNaranja; break;
               case 4: totalCamiones4++;
                  printf( "Cuantos bultos de cebolla trajo?:\n" );
                  scanf( "%d", &cantCebolla );
                  printf( "Cuantos bultos de naranja trajo?:\n" );
                  scanf( "%d", &cantNaranja );
                  printf( "Cuantos bultos de mango trajo?:\n" );
                  scanf( "%d", &cantMango );
                  printf( "Cuantos bultos de tomate trajo?:\n" );
                  scanf( "%d", &cantTomate );
                  totalCebolla += cantCebolla;
                  totalNaranja += cantNaranja; 
                  totalMango += cantMango; break;
               default: printf( "Numero de productos erroneo\n" );
            } break;
         default: printf( "Tipo de camion equivocado" );
      }
   }
   printf( "Cantidad de camiones tipo A: %d \nCantidad de camiones con 3 productos: %d\nCantidad de camiones con 4 productos: %d\nKilos de cebolla: %d\nKilos naranja: %d\nKilos mango: %d\n", tipoA, totalCamiones3, totalCamiones4, totalCebolla, totalNaranja, totalMango );
}

void numerosPrimos(){
   int n, x, i, result, contCien = 0, numEntero, resultado, cont2, numRestante, sumaDigitos;
   printf( "Hasta que numero quiere ver los primos?\n" );
   scanf( "%d", &n );
   for( i = 1; i <= n; i++ ){
      int cont = 0;
      for ( x = 1; x <= i; x++ ){
         result = i % x;
         if( result == 0 )
            cont++;
      }
      if( cont == 2 ){
         printf( "%d ", i );
         if( i > 99 && i < 1000 )
            contCien++;
         if( i > 9 ){
            cont2 = 0;
            sumaDigitos = 0;
            numEntero = i ;
            while( numEntero != 0 ){
               numRestante = numEntero % 10;
               numEntero = numEntero / 10;
               sumaDigitos += numRestante;
            }
            for( x = 1; x <= sumaDigitos; x++ ){
               result = sumaDigitos % x;
               if( result == 0 )
                  cont2++;
            }
            if( cont2 == 2 ){
               printf( "\nEl numero %d tiene la particularidad\n", i );
            }
         }
      }
   }
   printf( "La cantidad de numeros con 3 digitos son: %d\n", contCien );
}

int menu () {
   int opcion;
   do {
      printf( "Que desea hacer:\n1. Numero Aleatoreo\n2. Felicidades 71\n3. La farra\n4. Numeros Primos\n5. Terminar programa\n" );
      scanf( "%d", &opcion );
      if ( opcion == 1 ){
         randomPicker();
      }else if( opcion == 2 ){
         felicidades71();
      }else if( opcion == 3 ){
         laFarra();
      }else if( opcion == 4 ){
         numerosPrimos();
      }
   } while( opcion !=5 );   
}

int main(){
   menu();
   return 0;
}