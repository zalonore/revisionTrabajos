#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

// PUNTO 1
int ContarCaracteres(char cadena[]){
	char *p = &cadena[0];
	int contador = 0;

	while(*p != '\0'){
		contador++;
		p++;
	}
	return contador;
}

// PUNTO 2
void ColocarMayuscula(char cadena[], int lugar){
	char minus = cadena[lugar];
	cadena[lugar] = toupper(minus);
}

// PUNTO 3
void IntercalarMayusculasMinusculas(char* p, int contador){
	char letra = *p;
	if(contador % 2 != 0){
		*p = toupper(letra);
	}
	else if(contador % 2 == 0){
		*p = tolower(letra);
	}
}

int BuscarVocal(char cadena[], char vocal){
	char *p = &cadena[0];
	int contador = 0;

	while(*p != '\0'){
		if(tolower(*p) == vocal){
			contador++;
			IntercalarMayusculasMinusculas(p, contador);
		}
		p++;
	}
	return contador;
}

//PUNTO 4
void EliminarPalabra(char cadena[], char palabra[]){
	char *leer = &cadena[0], *escribir = &cadena[0];
	char *aux = &palabra[0];
	int contador = 0;

	while(*leer != '\0'){
		*escribir = *leer;
		if(tolower(*leer) == *aux){	
			contador++;
			if(contador == ContarCaracteres(palabra)){
				escribir -= (ContarCaracteres(palabra)+1);
				aux = &palabra[0];
				contador = 0;
			}
			else{
				aux++;
			}
		}
		else
		{
			aux = &palabra[0];
			contador = 0;
		}

		leer++;
		escribir++;
	}

	while(*escribir != '\0'){
		*escribir = ' ';
		escribir++;
	}
}

int main(){

	int opcion;
	char cadena1[100];
	char cadena2[] = "en un comienzo, gabriel garcia Marquez penso en titular su novela La Casa, pero se decidio por Cien anios de soledad para evitar confusiones con la novela La Casa Grande, publicada en 1954 por su amigo, Alvaro Cepeda Samudio";
	char vocal[1], cadena3[227];
	char cadena4[] = "Mi profe consiguio una camara vieja antes de la pandemia, pero como ahora es un profe digital, el profe se consiguio una camara nueva mas bonita. Pasado el tiempo se dio cuenta que la camara nueva aunque bonita era una camara mala, pero que bobada, al fin y al cabo, ya sea con una camara vieja o una camara nueva, nunca la muestra en clase.";
	
	do
	{
		printf("\n\n1. Cantidad de caracteres\n2. Modificar cadena\n3. Modificar cadena 2.0\n4. Modificar cadena 3.0\n0. Salir\n");
		scanf("%d",&opcion);

		switch(opcion)
		{
			case 1:
				// PUNTO 1		
				printf("\nIngrese una cadena de caracteres: ");
				//fgets (cadena1, 100, stdin);
				scanf("%*c%[^\n]", cadena1);
				printf("\nTamaño: %d",ContarCaracteres(cadena1));
				break;
			case 2:
				// PUNTO 2	
				printf("\nOriginal: %s", cadena2);
				ColocarMayuscula(cadena2, 0);		
				ColocarMayuscula(cadena2, 16);		
				ColocarMayuscula(cadena2, 24);		
				printf("\n\nModificada: %s", cadena2);
				break;
			case 3:
				// PUNTO 3	
				do{
					printf("\nIngrese una vocal: ");
					scanf("%*c%[^\n]", vocal);
				}while(tolower(vocal[0])!='a' && tolower(vocal[0])!='e' && tolower(vocal[0])!='i' && tolower(vocal[0])!='o' && tolower(vocal[0])!='u');
				
				for(int i = 0; i < 227; i++){
					cadena3[i] = cadena2[i];
				}

				printf("\nCantidad de %c: %d",vocal[0], BuscarVocal(cadena3, tolower(vocal[0])));
				printf("\nOriginal: %s", cadena2);
				printf("\n\nModificada: %s", cadena3);
				break;
			case 4:
				// PUNTO 4
				printf("\nOriginal: %s", cadena4);
				EliminarPalabra(cadena4, "camara");
				printf("\n\nModificada: %s", cadena4);
				break;
			case 0:
				// SALIR
				printf("\nAios.");
				break;
			default:
				printf("\nNo es una opción válida.");
				break;
		}
	}while(opcion != 0);

	return 0;
}