numero = int(input("Digite el numero:"))

if numero==11 or numero==4 or numero==6 or numero==9:
    print("el mes tiene 30 dias")
if numero==2:
    print("el mes tiene 28 dias")
if numero==1 or numero==3 or numero==5 or numero==7 or numero==8 or numero==10 or numero==12:
    print("el mes tiene 31 dias")
if numero<1 or numero>12:
    print("lo siento el numero no corresponde a un mes del año")
    