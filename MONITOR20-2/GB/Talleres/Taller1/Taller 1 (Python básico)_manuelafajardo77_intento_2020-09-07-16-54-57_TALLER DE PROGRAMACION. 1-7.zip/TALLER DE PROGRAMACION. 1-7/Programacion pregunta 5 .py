a = float (input ("Por favor digite la primera variable:"))
b = float (input ("Por favor digite la segunda variable:"))
c = float (input ("Por favor digite la tercera variable:"))

d = (b*-1)
e = (b**2)-(4*a*c)
f = e**(1/2)
g = 2*a
X1 = ((d+f)/g)
X2 = ((d-f)/g)

print ("El primer valor de X es igual a:",X1)
print ("El segundo valor de X es igual a:",X2)
