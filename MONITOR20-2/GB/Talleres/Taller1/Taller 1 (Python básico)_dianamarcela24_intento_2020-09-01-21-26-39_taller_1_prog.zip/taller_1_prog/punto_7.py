valorde_x= (input("digite por favor el valor del usuariox"))
valorde_y= (input("digite por favor el vaalor del usuarioy"))

aux = valorde_x

valorde_x = valorde_y

valorde_y = aux

print("el valorde_x es:" ,valorde_x)
print("el valorde_y es:" ,valorde_y)
