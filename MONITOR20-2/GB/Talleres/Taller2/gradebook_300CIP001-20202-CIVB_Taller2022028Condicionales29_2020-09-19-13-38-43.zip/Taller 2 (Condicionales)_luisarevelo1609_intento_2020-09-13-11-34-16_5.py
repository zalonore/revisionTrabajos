x= int(input("digite un numero:"))
if x>=1 and x<= 12:
    if x==11 or x==4 or x==6 or x==9:
        print("este mes tiene 30 dias")
    elif x==2:
         print("este mes tiene 28 dias")
    else:
         print("este mes tiene 31 dias")
         
else:
     print("lo siento el numero no corresponde a un mes del año")
        
    
    
    
