a = float (input("Por favor digite el primer numero:"))
b = float (input("Por favor digite el segundo numero:"))

suma= a+b
resta= a-b
multiplicacion= a*b
division= a/b
potencia= a**b

print ("La suma de ",a,"+",b," es: ",suma)
print ("La resta de ",a,"-",b," es: ",resta)
print ("La multiplicacion de ",a,"*",b," es: ",multiplicacion)
print ("La division de ",a,"/",b," es: ",division)
print ("La potencia de ",a,"^",b," es: ",potencia)
