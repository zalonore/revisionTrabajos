base=float(input("ingrese la base del rectangulo:"))
haltura=float(input("ingrese la altura del rectangulo:"))

A= base*haltura
P= (base*2)+(haltura*2)

print("el area del rectangulo es:",A,"y el perimetro es igual a:",P)


