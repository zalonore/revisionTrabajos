Base = float(input("Escriba la base del rectangulo"))
Altura=float(input("Escriba la altura del rectangulo"))
Area= Altura*Base
Perimetro= Altura+Base+Altura+Base
print("El area del rectangulo es", Area,)
print("El perimetro del rectangulo es", Perimetro,)