#include <stdio.h>
#include <stdlib.h>

int generarAsteriscos(int opcion1){     // PRIMERA FUNCION ( ASTERISCOS )

	int i, c = 1;
	while (c <= 2){                      // CILO WHILE PARA REPETIR LA LINEA DE ASTERISCOS        

		for (i = -1; i <= opcion1; i++){  // CICLO FOR PARA HACER LA LINEA DE ASTERISCOS
			if (i == -1 || i == opcion1)
			printf("%d ", opcion1);
			else
				printf("* ");
		}

		printf("\n");
		c++;
	}
	return 0;
}

int jugarAzar(int cantidadJugadas){   // SEGUNDA FUNCION ( JUEGO DE AZAR )

	int a, bandera, sumaNum, contadorNum, contador50_60, numero;
	float promedio;

	a = 1;  
	bandera = 0;
	sumaNum = 0;
	contadorNum = 0;
	contador50_60 = 0;

	while ( a <= cantidadJugadas ){
		printf(" \nDigite su numero: " );
		scanf( "%d", &numero );
		if ( numero >= 50 && numero <= 80 ){
			if ( numero == 71 && bandera == 0 ){
				printf( "\nFelicitaciones" );
				bandera++;
			}
			else if ( numero == 71 && bandera == 1 ){
				printf( "\nFelicitaciones, venga mañana y reclame su premio" );
				bandera++;
			}
			else if ( numero == 71 && bandera == 2 ){
				printf( "\nEsta muy sospechoso...." );
				bandera++;
			}
			else if ( numero >= 50 && numero <= 60 ){
				contador50_60++;
			}
			if ( numero != 71 ){
				sumaNum+=numero;
				contadorNum++;
			}
			a++;
		}
		else
			printf(" \nPor favor digite un numero valido\n ");
	}
	promedio = sumaNum / (float)contadorNum;
	printf( "\nUsted digito %d numeros entre 50 y 60", contador50_60 );
	printf( "\nEl promedio de sus numeros es: %f\n", promedio );
	return 0;
}

int inventarioDia(){  // TERCERA FUNCION:  INVENTARIO DE LA FARRA

	int a, b, cantProductos, camionesA, camionesB, contCamiones;
	int kgPapa, kgTomate, kgCebolla, kgNaranja, kgMango;
	int totalPapa, totalCebolla, totalTomate, totalNaranja, totalMango;

	totalPapa = 0;
	totalCebolla = 0;
	totalTomate = 0;
	totalNaranja = 0;
	totalMango = 0;
	contCamiones = 0;

	printf( "\nDigite cuantos caminones de tipo A llegaron: " );
	scanf( "%d", &camionesA );
	for ( a = 1; a <= camionesA; a++ ){         // AQUI SE CALCULA LOS PRODUCTOS DE LOS CAMIONES TIPO A
		printf( "\nCamino tipo A, # %d", a );
		printf( "\nDigite cuantos Kg de papa trae el camion: " );
		scanf( "%d", &kgPapa );
		totalPapa += kgPapa;
	}

	printf( "\nDigite cuantos caminones de tipo B llegaron: " );// AQUI SE CALCULA LOS PRODUCTOS DE LOS CAMIONES TIPO B
	scanf( "%d", &camionesB );
	for ( b = 1; b <= camionesB; b++ ){
		printf( "\nCamino tipo B, # %d", b );
		printf( "\nDigite cuantos productos trae: " );
		scanf( "%d", &cantProductos );
		if ( cantProductos == 2 ){
			printf( "\nDigite los Kg de Tomate: " );
			scanf("%d", &kgTomate);
			printf( "\nDigite los Kg de Cebolla: " );
			scanf( "%d", &kgCebolla );
			totalTomate += kgTomate;
			totalCebolla += kgCebolla;
		}
		else if ( cantProductos == 3 ){
			printf( "\nDigite los Kg de Tomate: " );
			scanf( "%d", &kgTomate );
			printf( "\nDigite los Kg de Cebolla: " );
			scanf( "%d", &kgCebolla );
			printf( "\nDigite los Kg de Naranja: " );
			scanf( "%d", &kgNaranja );
			totalTomate += kgTomate;
			totalCebolla += kgCebolla;
			totalNaranja += kgNaranja;
			contCamiones++;
		}
		else if ( cantProductos == 4 ){
			printf( "\nDigite los Kg de Tomate: " );
			scanf( "%d", &kgTomate );
			printf( "\nDigite los Kg de Cebolla: " );
			scanf( "%d", &kgCebolla );
			printf( "\nDigite los Kg de Naranja: " );
			scanf( "%d", &kgNaranja );
			printf( "\nDigite los Kg de Mango: " );
			scanf( "%d", &kgMango );
			totalTomate += kgTomate;
			totalCebolla += kgCebolla;
			totalNaranja += kgNaranja;
			totalMango += kgMango;
			contCamiones++;
		}
		else{
			printf( "\nSentencia invalida" );
		}
	}
	printf( "\nResultado: " );
	printf( "\nLlegaron %d caminones de tipo A", camionesA );
	printf( "\nEl total de camiones que llegaron con 3 o 4 productos fueron: %d", contCamiones );
	printf( "\nEl dia de hoy llegaron: " );
	printf( "\n%d Kg de Cebolla", totalCebolla );
	printf( "\n%d Kg de Tomate", totalTomate );
	printf( "\n%d Kg de Naranja", totalNaranja );
	printf( "\n%d Kg de Mango", totalMango );
	printf( "\n%d Kg de Papa\n", totalPapa );
	return 0;
}

int sumarDigitos(int num){      // Funcion para sumar los digitos de un numero

	int suma = 0, resto, i, vefPrimo = 0;
 
   while ( num != 0 ){
       resto = ( num % 10 );
       suma += resto;
       num -= resto;      
       num /= 10;
   }
 
   for ( i = 1; i <= suma; i ++ ){     // Luego de tener la suma de los digitos, verifico si es primo, si lo es, lo imprimo
    if ( suma % i == 0 )
    	vefPrimo++;
   }
   if ( vefPrimo == 2 )
   	printf( "\nLa suma de sus digitos da un numero primo\n" );

	return 0;
}

int verPrimo(){  // CUARTA FUNCION: NUMEROS PRIMOS

	int n, i, a, comprobante_3digitos, contador = 0;

	printf("\nDigite el numero N: ");
	scanf("%d", &n);

	for ( i = 1; i <= n; i++ ){  // ESTE FOR SE UBICA EN CADA UNO DE LOS NUMEROS DEL 1 HASTA EL N

		int vefPrimo = 0;

		for ( a = 1; a <= i; a++ ){ // ESTE FOR SE ENCARGA DE VERIFICAR SI EL NUMERO i, Es primo
			if ( i % a == 0 )
				vefPrimo++;
		}
		comprobante_3digitos = i / 100;  // SI EL RESULTADO DE ESTA OPERACION ES MAYOR QUE 0, SIGNIFICA TIENE 3 DIGITOS
		if ( comprobante_3digitos > 0 && vefPrimo == 2 ){
			printf( "\n%d es primo y tiene 3 digitos", i );
			contador++;   // Contador para los primos de 3 digitos
		}
		else if ( vefPrimo == 2 )
			printf( "\n%d es primo", i );

		if ( i > 9 && vefPrimo == 2 ){   // Este if entrara cuando el numero primo tenga mas de 1 digito
			sumarDigitos(i);
		}

	}
	printf( "\n%d numeros son primos de 3 digitos\n", contador );
  return 0;
}

int main(){

	int a, n, cantidadJugadas, opcion, opcion1;

	do{
		printf( "\n       MENU\n\n" );
		printf( "1. Linea de asteriscos\n" );
		printf( "2. Juego de numeros\n" );
		printf( "3. La farra\n" );
		printf( "4. Numeros primos\n" );
		printf( "0. SALIR\n" );
		printf( "\nDigite la opcion deseada: " );
		scanf( "%d", &opcion );
		switch( opcion ){

			case 1:
				a = 1;
				while ( a<=10 ){
					printf( "\nDigite el numero para la linea: " );
					scanf( "%d", &opcion1 );
					if ( opcion1 < 0 || opcion1 == 0 )
					a = 15;	
					else{
						if ( opcion1 <= 15 ){
						generarAsteriscos(opcion1);
						}
					}
					a++;
				} 
				break;

			case 2:
				printf( "\nDigite las veces que jugara: " );
				scanf( "%d", &cantidadJugadas );	
				jugarAzar(cantidadJugadas);
				break;

			case 3:
				inventarioDia();
				break;

			case 4:
				verPrimo();
				break;
		}
		}while( opcion != 0 );

return 0;
}