a=float(input("digite la medida del primer lado"))
b=float(input("digite la medida del segundo lado"))
area=a*b
perimetro=((2*b)+(2*a))
print("el area de la figura es", area)
print("el perimetro de la figura es", perimetro)
