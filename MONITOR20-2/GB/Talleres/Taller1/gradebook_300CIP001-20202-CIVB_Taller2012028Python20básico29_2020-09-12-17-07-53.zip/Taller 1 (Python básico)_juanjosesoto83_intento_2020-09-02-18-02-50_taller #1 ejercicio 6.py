print("ejercicio 6")
numero= int(input("digitar numero 4 digitos "))
digito4= numero%10
digito3= (numero%100)//10
digito2= (numero%1000)//100
digito1= (numero%10000)//1000
print(digito4, digito3, digito2, digito1)

