//Incluyo biblioteca de entrada/salida.

#include <stdio.h>

#include <stdlib.h>

int Suma(int primeroNumero, int segundoNumero){

  return primeroNumero + segundoNumero;
}

int Resta(int primeroNumero, int segundoNumero){

  return primeroNumero - segundoNumero;
}

int Multiplicacion(int primeroNumero, int segundoNumero){

  return primeroNumero * segundoNumero;
}

float Division(int primeroNumero, int segundoNumero){

  float result=0.0;

  if(segundoNumero > 0){

   result= (float)primeroNumero / (float)segundoNumero;
  }

  else{

   printf("No se puede hacer esta operacion para los numeros %d--%d \n", primeroNumero, segundoNumero);
  }

  return result;
}

int calcularAnioBisiesto(int anio){

  if(anio % 4 == 0 && anio % 100 != 0){

    return 1;
  }

  else if(anio % 400 == 0){

    return 1;
  }

  else{

    return 0;
  }
}

int calcularCapicua(int numeroNueveDigitos){

  // Nota: Al referirse a numeros se dice capicua, no palindromo

  int cifra, reves=0, copiaNumero;   

   copiaNumero = numeroNueveDigitos;

   while(numeroNueveDigitos != 0){

      cifra = numeroNueveDigitos % 10;

      reves = reves * 10 + cifra;

      numeroNueveDigitos = numeroNueveDigitos / 10;

   }
   
   if(copiaNumero == reves){

     printf("El numero %d si es palindromo\n",copiaNumero);

     }

   else{

     printf("El numero %d no es palindromo\n",copiaNumero);
     
     }

   return 0;
}

int main(){

  int primeroNumeroUsuario, segundoNumeroUsuario, resultadoOperacionEntera, anio, numeroNueveDigitos;

  float resultadoOperacionFlotante;

  printf("Bienvenidos a este programa \n");

  printf("Ingrese el numero entero uno \n");

  scanf("%d",&primeroNumeroUsuario);

  printf("Ingrese el numero entero dos \n");

  scanf("%d",&segundoNumeroUsuario);

  printf("Ingrese el anio \n");

  scanf("%d", &anio);

  printf("Ingrese un numero de nueve digitos\n");

  scanf("%d", &numeroNueveDigitos);
  
  //Operaciones

  resultadoOperacionEntera = Suma(primeroNumeroUsuario,segundoNumeroUsuario);

  printf("Resultado entero de la operacion uno %d \n", resultadoOperacionEntera);
  
   resultadoOperacionEntera = Resta(primeroNumeroUsuario,segundoNumeroUsuario);

  printf("Resultado entero de la operacion dos %d \n", resultadoOperacionEntera);
  
   resultadoOperacionEntera = Multiplicacion(primeroNumeroUsuario,segundoNumeroUsuario);

  printf("Resultado entero de la operacion tres %d \n", resultadoOperacionEntera);
  
   resultadoOperacionFlotante = Division(primeroNumeroUsuario,segundoNumeroUsuario);

  printf("Resultado flotante de la operacion cuatro %f \n", resultadoOperacionFlotante);
  
  resultadoOperacionEntera = calcularAnioBisiesto(anio);

  if(resultadoOperacionEntera == 1){

    printf("El año %d es bisiesto y mi nombre es Steven Guerrero\n", anio);
  }

  else if(resultadoOperacionEntera == 0){

    printf("El anio %d no es bisiesto y tengo 2 hermanos\n", anio);
  }

  calcularCapicua(numeroNueveDigitos);

  return 0;
  
}

