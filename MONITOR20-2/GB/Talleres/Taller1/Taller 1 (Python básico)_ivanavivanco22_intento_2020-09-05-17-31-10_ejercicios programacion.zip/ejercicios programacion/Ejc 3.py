PI=3.01416
r= float(input("ingrese el radio del circulo"))
area = (PI*r**2)
print("El area del circulo es", area,)
