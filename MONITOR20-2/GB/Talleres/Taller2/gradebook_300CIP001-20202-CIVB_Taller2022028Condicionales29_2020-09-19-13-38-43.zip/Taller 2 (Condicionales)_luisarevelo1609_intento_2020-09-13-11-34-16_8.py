año=int(input("digite un año:"))
if año%4==0 and año%100==0 and año%400==0:
        print(" es un año bisiesto")

else:
    print("no es año bisiesto")
