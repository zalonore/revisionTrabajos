x=int(input("digite la cantidad de personas:"))
y=(input("digite la temporada en la que se encuentra:(alta o baja):"))
z= (input("digite la cantidad de atracciones a disfrutar:(8 o todas):"))


alta=49000*x
baja=45000*x
alta2=22000*x
baja2=20000*x

if y=="alta":
    if  z=="8":
        print("su valor base es:", alta2)
        print("ademas, su valor a pagar en taquilla es:", alta2*1.06) 
    
    else:
         print("su valor base , segun sus opciones es:", alta)
         print("ademas, su valor a pagar en taquilla es:",alta*1.06)
         
elif y=="baja":
    if z=="8":
        print("su valor base , segun sus opciones es:", baja2)
        print("ademas, su valor a pagar en taquilla es:", baja2*1.06)
        
    else:
        print("su valor base , segun sus opciones es:", baja)
        print("ademas, su valor a pagar en taquilla es:",baja*1.06)

        
     


    
