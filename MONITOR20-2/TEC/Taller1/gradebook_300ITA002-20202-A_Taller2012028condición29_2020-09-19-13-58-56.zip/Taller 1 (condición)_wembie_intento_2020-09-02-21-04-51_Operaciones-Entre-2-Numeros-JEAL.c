#include <stdio.h>

int Sumar(int x, int y){
  return x+y;
}
int Restar(int x, int y){
  return x-y;
}
int Multiplicar(int x, int y){
  return x*y;
}
float Dividir(int x, int y){
  float result=0.0;
  if(y>0){
  result= (float)x/ (float)y;
  }else{
  printf("No se puede hacer esta operacion para los numeros %d--%d \n", x,y);
  }
  return result;
}
int Invertir(int Numero){ //// INVERTIR NUMERO
  int A, B, Voltear = 0;
  while(Numero != 0){
    A = Numero % 10;
    B = Numero / 10;
    Voltear = Voltear*10+A;
    Numero = B;
  }
  return Voltear;
}
int Bisiesto(int Year){
  if (Year % 4 == 0 && Year % 100 != 0 || Year % 400 == 0){
    printf("%d Es un Year Bisiesto y mi nombre es Juan Esteban Acosta Lopez\n", Year);
    return 1;
  }
  else{
    printf("%d No es Year Bisiesto y Tengo 3 Hermanos\n", Year);
    return 0;
  }
}

int main(){
  int Numero_Uno,Numero_Dos,Resultado, Numero, Year;
  float Resultado_Decimal;
  printf("Bienvenidos a este programa \n");
  printf("Ingrese el Numero uno: \n");
  scanf("%d",&Numero_Uno);
  printf("Ingrese el Numero dos: \n");
  scanf("%d",&Numero_Dos);
  printf("Ingrese el Numero a Invertir: \n");
  scanf("%d", &Numero);
  printf("Ingrese un Year: \n");
  scanf("%d", &Year);
  
  //Operaciones
  Resultado=Sumar(Numero_Uno,Numero_Dos);
  printf("Resultado operacion de la suma es: %d \n", Resultado);
  
  Resultado=Restar(Numero_Uno,Numero_Dos);
  printf("Resultado operacion de la resta es: %d \n", Resultado);
  
  Resultado=Multiplicar(Numero_Uno,Numero_Dos);
  printf("Resultado operacion de la multiplicacion es: %d \n", Resultado);
  
  Resultado=Dividir(Numero_Uno,Numero_Dos);
  printf("Resultado operacion de la division es: %f \n", Resultado_Decimal);

  Resultado=Invertir(Numero);
  printf("El Numero %d al invertirlo da: %d\n",Numero, Resultado);
  if(Numero == Resultado){
  printf("El numero %d, Es Palindromo\n", Numero);
  }
  else{
    printf("El numero %d, No es Palindromo\n", Numero);
  }
  Resultado=Bisiesto(Year);
  printf("Resultado es %d,\n",Resultado);
  return 0;
}