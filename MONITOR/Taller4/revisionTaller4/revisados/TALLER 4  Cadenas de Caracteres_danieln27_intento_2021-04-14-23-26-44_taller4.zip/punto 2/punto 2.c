#include <stdio.h>

int main(){
	int i, cont;
	char cadena[ 1000 ];
	printf( "ingrese el parrafo:\n");

	fgets( cadena, sizeof(cadena), stdin );
	for( i = 0; i < sizeof(cadena); i++ ){
		if ( cadena[ i ] == '\0' ){
    		break;
		}
		else{
			cont++;
		}
	}

	cadena[ 0 ] -= 32;
	cadena[ 16 ] -= 32;
	cadena[ 24 ] -= 32;

	printf( "parrafo convertido:\n" );
	for( i = 0; i < sizeof(cadena); i++ ){
		if ( cadena[ i ] == '\0' ){
    		break;
		}
		else{
			printf( "%c", cadena[ i ] );
		}
	}
	return 0;
}
