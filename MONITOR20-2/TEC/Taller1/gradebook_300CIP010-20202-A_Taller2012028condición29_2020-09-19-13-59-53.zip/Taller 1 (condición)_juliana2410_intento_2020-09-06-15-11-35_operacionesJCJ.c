/*1.1 ¿Para qué sirve la instrucción #include?
Esta instrucción sirve para incluir las librerias principales.

1.2 ¿Cuál es el objetivo principal de ese programa?
El programa recibe dos números y retorna el resultado de las
operaciones suma, resta. multiplicación y divisón.

1.3 ¿Cuántas variables tiene en total?
En total tiene cuatro variables (a, b, c, d)

1.4¿Cuáles de esas son variables locales y cuales son variables
globales? ¿Por qué?
a y b son variables locales porque son los parámetros que reciben las funciones
c y d variables son globales, ya que están fuera de las funciones.

1.5	¿Cuántas funciones definidas por el usuario tiene ese programa?
El usuario no define ninguna función, solo ingresa los parámetros.

1.6	¿Cuál es el nombre de cada una de esas funciones?
Las funciones definidas son funcionUno, funcionDos, funcionTres y funcionCuatro.

1.7	¿Para qué cree usted que se convierten los números enteros en flotantes en la función cuatro? Explique
Porque por definición la división es un numero racional (float) y si los números ingresados permanecen enteros
la división va a estar parcialmente definida.


1.8	¿Explique qué es la función main y por qué es importante?
La función main es la función principal, es importante porque es en esta en donde se llaman las otras funciones.

2.1	Cambie la función main de posición. Córtela y péguela luego de la declaración de las librerías. Compile y 
ejecute nuevamente el programa. ¿Qué resultado obtuvo? ¿Por qué cree usted que se obtuvo ese resultado?

Se presenta un error porque en la función main se llaman las otras funciones que aún no están definidas.

2.2	Modifique la función funcionDos. Borre la declaración de la variable x. Compile y ejecute nuevamente el programa. 
¿Qué resultado obtuvo? ¿Por qué cree usted que se obtuvo ese resultado?

Se presenta un error en funcionDos porque al retornar el resultado se emplea una variable que no ha sido declarada todavía.
*/


#include <stdio.h>

int suma(int x, int y){
  return x+y;
}
int resta(int x,int y){
  return x-y;
}
int multiplicacion(int x, int y){
  return x*y;
}
float division(int x, int y){
  float result=0.0;
  if(y>0){
	result= (float)x/ (float)y;
  }else{
	printf("No se puede hacer esta operacion para los numeros %d--%d \n", x,y);
  }
  return result;
}

int invertir(int x){
	int invertido = 0;

	while(x > 0){

		invertido = invertido + x%10;
		invertido = invertido * 10;
		x = x/10;
	}
	return invertido/10;
}

int esPalindromo(int x){
	if(x == invertir(x)){
		printf("%d es Palindromo\n",x);
	}else{
		printf("%d no es Palindromo\n",x);
	}
}

int esBisiesto(int x){
	if( x%4 == 0 && x% 100 != 0 || x % 400 == 0){
		return 1;
	} else {
		return 0;
	}
}

int bisiesto(int anio){
	if(esBisiesto(anio) == 1){
		printf("El año %d es bisiesto y mi nombre es Juliana\n",anio);
	}else{
		printf("El año %d no es bisiesto y tengo un hermano\n",anio);
	}
}

int main(){
	
  int numUno,numDos,numTres, resultado, anio;

  float resultDivision;
  printf("Bienvenidos a este programa \n");
  printf("Ingrese el num uno \n");
  scanf("%d",&numUno);
  printf("Ingrese el num dos \n");
  scanf("%d",&numDos);
  printf("Ingrese un numero \n");
  scanf("%d",&numTres);
  printf("Ingrese el anio\n");
  scanf("%d",&anio);
  
  
  //Operaciones
  resultado = suma(numUno,numDos);
  printf("La suma es %d \n", resultado);
  
  resultado = resta(numUno,numDos);
  printf("La resta es %d \n", resultado);
  
  resultado = multiplicacion(numUno,numDos);
  printf("La multiplicacion es %d \n", resultado);
  
  resultDivision = division(numUno,numDos);
  printf("La division es %f \n", resultDivision);
 
  esPalindromo(numTres);

  bisiesto(anio);
  return 0;

}

