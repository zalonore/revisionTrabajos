print("vamos a hallar el area y perimetro de un rectangulo")
b=float(input("da un valor para la base: "))
h=float(input("da un valor para la altura: "))
A=b*h
print("el area es igual a: ",A)
P=b+h+b+h
print("el area del perimetro es: ",P)
