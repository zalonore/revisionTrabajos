B=float(input('Digite la base del rectangulo'))
A=float(input('Digite la altura del rectangulo'))
area = (B*A)
perimetro = 2*(B+A)

print ('El area del rectangulo es', area, 'cm')
print ('El perimetro del rectangulo es de', perimetro , 'cm')
