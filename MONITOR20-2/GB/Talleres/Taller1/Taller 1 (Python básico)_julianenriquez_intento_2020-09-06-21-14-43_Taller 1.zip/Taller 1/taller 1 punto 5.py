m = input('ingrese su primer valor"a":')
n = input('ingrese su segundo valor "b":')
l = input('ingrese su tercer valor "c":')
a = complex(m)
b = complex(n)
c = complex(l)
bpot = (b**2)
equisde = complex(2*a)
t = complex(bpot-4*a*c)
sqrt = complex(t**.5)
yaCasi = complex(-b+sqrt)
yaCasiDos = complex(-b-sqrt)
xUno = complex(yaCasi/equisde)
xDos = complex(yaCasiDos/equisde)



print ("Sus dos valores de x son :",xUno,",",xDos)
