numero1 = int(input("Digite el primer numero:"))
numero2 = int(input("Digite el segundo numero:"))
numero3 = int(input("Digite el tercer numero: "))

if numero1==numero2==numero3:
    print("triangulo equilatero")
if numero1==numero2!=numero3:
    print("tiangulo isosceles")
if numero1==numero3!=numero2:
    print("triangulo isosceles")
if numero2==numero3!=numero1:
    print("triangulo isosceles")
if numero1!=numero2!=numero3:
    print("triangulo escaleno")
    
