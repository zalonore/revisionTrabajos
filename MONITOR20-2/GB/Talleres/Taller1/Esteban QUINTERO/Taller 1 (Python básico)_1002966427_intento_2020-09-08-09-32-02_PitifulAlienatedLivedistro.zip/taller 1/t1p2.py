x = int(input ("digite el primer numero"))
y = int(input ("digite el segundo numero"))
suma = x+y
resta = x-y
multiplicacion = x*y
division = x/y
potencia = x**y
print ("la suma es: ", suma)
print ("la resta es: ", resta)
print ("la multiplicacion es: ", multiplicacion)
print ("la division es: ", division)
print ("la potencia es: ", potencia)
