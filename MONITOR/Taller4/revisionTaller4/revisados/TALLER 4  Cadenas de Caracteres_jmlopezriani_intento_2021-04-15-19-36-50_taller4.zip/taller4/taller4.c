#include <stdio.h>
#include <stdlib.h>

int countChar(char *s){
	int c = 0;
	while( s[ c ] != '\0'){
		c++;
	}
	return c;
}

void corregir(char s[]){
    int i = 0;
    for(i; i < 25; i++){
        switch( i ){
            case 0:
            s[ i ] -= 32;
            break;
            case 16:
            s[ i ] -= 32;
            break;
            case 24:
            s[ i ] -= 32;
            break;
        }
    }
}

int contarV(char s[], char c){
    int i = 0, counter = 0;
    for(i; i < 225; i++){
        if(s[ i ] == c){
            counter++;
        }
    }
    return counter;
}

void cambiarUna(char s[], char c){
    int i = 0, b = 1;
    while(b){
        if((s[ i ] == c) && (s[ i ] > 96)){
            *(s + i) -= 32;
            b = 0;
        }
        else if(s[ i ] == c - 32){
            b = 0;
        }
        
        i++;
    }
}

void cambiarIntercalado(char s[], char c){
    int i = 0, b = 1;
    if(c > 96){
        c -= 32;
    }
    for(i; i < 225; i++){
        if(s[ i ] == c){
            if(b == 0){
                *(s + i) += 32;
                b = 1;
            }
            else{
                b = 0;
            }
        }
        if(s[ i ] == c + 32){
            if(b == 1){
                *(s + i) -= 32;
                b = 0;
            }
            else{
                b = 1;
            }
        }
    }
}

void quitarCam(char s[]){
    int i = 0, j = 0, n = 0;
    for(i; i < 336 - n; i++){
        if(s[ i ] == 'c' && s[ i + 1 ] == 'a' && s[ i + 2 ] == 'm'){
            for(j = i; j < 336 - n; j++){
                *(s + j) = *(s + j + 6);
            }
        }
    }
}

void menu(){
	printf("1.Punto 1\n"
		   "2.Puntos 2 y 3\n"
		   "3.Punto 4\n"
		   "0.Salir\n");
}

int main(){
	int opt;
	char *s = (char*)malloc(sizeof(char) * 1000), car, gg[ 225 ] = "en un comienzo, gabriel garcia Marquez penso en titular su novela La Casa, pero se decidio por Cien anios de soledad para evitar confusiones con la novela La Casa Grande, publicada en 1954 por su amigo, Alvaro Cepeda Samudio\0", cad[ 342 ] = "Mi profe consiguio una camara vieja antes de la pandemia, pero como ahora es un profe digital, el profe se consiguio una camara nueva mas bonita. Pasado el tiempo se dio cuenta que la camara nueva aunque bonita era una camara mala, pero que bobada, al fin y al cabo, ya sea con una camara vieja o una camara nueva, nunca la muestra en clase.\0";
	do{	
		menu();
		scanf("%d", &opt);
		switch(opt){
			case 1:
				printf("Ingrese la palabra: ");
				fflush(stdin);
				scanf("%s", s);
				printf("El numero de letras en la palabra es %d.\n", countChar(s));
			break;
			case 2:
				corregir( gg );
			    printf("%s\n\n\n", gg);
			    printf("Ingrese el caracter: ");
			    fflush(stdin);
			    scanf("%c", &car);
			    cambiarUna(gg, car);
			    printf("%s\n\n\n", gg);
			    printf("Ingrese el caracter: ");
			    fflush(stdin);
			    scanf("%c", &car);
			    cambiarIntercalado(gg, car);
			    printf("%s\n\n\n", gg);
			break;
			case 3:
				printf("%s\n\n\n", cad);
			    quitarCam(cad);
			    printf("%s\n\n\n", cad);
			break;
		}
	}while(opt != 0);
	return 0;
}