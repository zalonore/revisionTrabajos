x=11
y=9
z=10
w=4
if x>=w:
    print("Verdadero")
# B)       
if  y==y and y>=z  and z**w!=y**x:

    print("verdadero")
else:
    print("falso")
# C)    
if not(y==w and x>=y and x<w):
    print("verdadero")
# D)    
if not (y==w or w!=y and x>=z):
    print("verdadero")
else:
   print("falso")
# E)
if (x*w==w*z+w and y**w>x**w) and (not x>=y or y<x):
    print("verdadero")
else:
    print("falso")
    
    

    


    
    
