x = 11
y = 9 
z = 10
w = 4



if (x<y or z==w and y>z or y==w):
    print("verdad")
else:
    print("falso")
