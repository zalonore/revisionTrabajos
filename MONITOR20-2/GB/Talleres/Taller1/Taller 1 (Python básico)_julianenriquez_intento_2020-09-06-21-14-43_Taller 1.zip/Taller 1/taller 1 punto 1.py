print(" \ | / ")
print("  @ @  ")
print("       ")
print('\ """ /')

