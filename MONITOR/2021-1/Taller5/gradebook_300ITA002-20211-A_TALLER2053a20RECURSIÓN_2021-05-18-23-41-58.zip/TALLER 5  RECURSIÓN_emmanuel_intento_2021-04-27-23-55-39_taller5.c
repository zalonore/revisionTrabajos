#include <stdio.h>
#include <stdlib.h>

int sumaRecursiva(int x, int y, int sum){
	if (x>y){
		return sum;
	}
	else{
		if (x % 3 == 0){
			 sum += x;
		}
		return sumaRecursiva(x+1, y, sum);
	}
}

int maximoComunDivisor(int x, int r){
	if (r==0){
		return x;
	}
	else{
		return maximoComunDivisor(r, x % r);
	}
}

int mayorArreglo(int * x, int e, int y){
	if (e == 10){
		return y;
	}
	else{
		if (x[e] > y){
			y = x[e];
		}
		return mayorArreglo(x, e+1, y);
	}
}

int serieFibonacci(int x, int num1, int num2, int sum){
	if (x == 1){
		return sum;
	}
	else{
		sum = num1 + num2;
		num1 = num2;
		num2 = sum;
		return serieFibonacci(x-1, num1, num2, sum);
	}
}

int matrizIdentidad(int * m, int x, int y){
	if (x == 0){
		return 1;
	}
	else{
		if (x == y){
			if (m[x, y] != 1){
				return 0;
			}
			return matrizIdentidad(m, x-1, y);
		}
		if (x < y){
			if (m[x, y] != 0){
				return 0;
			}
			return matrizIdentidad(m, x+1, y-1);
		}
		if (x > y){
			if (m[x, y] != 0){
				return 0;
			}
			return matrizIdentidad(m, x-1, y);
		}
	}
}

int menuRecursivo(int opcion){
	int num, num1, lista[10]={15,52,33,64,53,61,7,84,19,10}, matriz[3][3]={{1,0,0},{0,1,0},{0,0,1}};
	if (opcion==0){
		return 1;
	}
	else{
		printf("MENU:\n"
			   "1. Punto 2\n"
			   "2. Punto 3\n"
			   "3. Punto 4\n"
			   "4. Punto 5\n"
			   "5. Punto 6\n"
			   "0. Salir\n"
			);
		printf("Opcion a elegir: ");
		scanf("%d", &opcion);
		switch(opcion){
			case 1:
			    printf("Digita el rango entre A y B: ");
			    scanf("%d%d", &num, &num1);
			    printf("La suma de los multiplos de 3 en ese rango son %d\n", sumaRecursiva(num, num1, 0));
				break;
			case 2:
				printf("Digita dos numeros: ");
			    scanf("%d%d", &num, &num1);
			    printf("El maximo comun divisor (MCD) de esos numeros es %d\n", maximoComunDivisor(num, num1));
			    break;
			case 3:
				printf("El valor mayor del arreglo es %d\n", mayorArreglo(lista, 0, 0));
				break;
			case 4:
				printf("Fibonacci de: ");
				scanf("%d", &num);
				printf("Es %d\n", serieFibonacci(num, 0, 1, 1));
				break;
			case 5:
				printf("%d\n", matriz[1][1]);
				if (matrizIdentidad(*matriz,2,2)){
					printf("Es matriz identidad\n");
				}
				else{
					printf("No es matriz identidad\n");
				}
				break;
		}
		return menuRecursivo(opcion); 
	}

}

int main(){
	menuRecursivo(1);
	return 0;
}