#include <stdio.h>
#include <iostream>

//recursividad directa,simple y final
int mcd(int m, int n) {
    if (n == 0) {
        return m;
    }
    return mcd(n, m % n);
}

//recursividad directa, simple y no final
int multiplos(int a,int b,int suma){
	int rta;
	if (a%3==0){
			suma+= a;
		}
	a++;
	if (b<a){
		rta=suma;
	}
	else
		rta=multiplos(a,b,suma);
	return rta;
}
//recursividad directa,multiple y final
int fibonacci(int x){
    if (x == 0)
        return 0;
    if (x == 1)
        return 1;
    return fibonacci(x-1)+fibonacci(x-2);
}

void menu() {
	int opc;
	int a, b, m, n, suma= 0, x, flag= 1;
	printf("menu \n"
        "=================\n"
        "1. sumar multiplos de 3 en un rango a-b\n"
        "2. maximo comun multiplo\n"
        "3. fibonacci \n"
        "0. exit\n"
        "opc: ");
            
        scanf("%d", & opc);
        switch (opc){
        case 1:// multiplos de 3
        	printf("ingrese a y b: ");
    		scanf("%d %d", &a, &b);
    		system("cls");
    		printf(" la suma de los multiplos de 3 que se encuentran entre %d y %d es %d\n", a, b, multiplos(a,b,suma)); 
            break;
        case 2:// maximo comun divisor
    		printf("ingrese m y n: ");
    		scanf("%d %d", &m, &n);
    		system("cls");
    		printf(" el mcd de %d y %d es %d\n", m, n, mcd(m, n));
            break;
        case 3:
        	printf("ingrese x: ");
    		scanf("%d", &x);
    		system("cls");
    		printf("fibonacci de %d es %d\n", x, fibonacci(x));
		}
		menu();
}


int main(){
	menu();
	return 0;
}



