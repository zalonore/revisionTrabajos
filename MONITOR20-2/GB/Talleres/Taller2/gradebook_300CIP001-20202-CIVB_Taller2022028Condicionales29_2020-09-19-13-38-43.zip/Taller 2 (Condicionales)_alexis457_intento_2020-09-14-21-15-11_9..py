ventasMedicamento = float(input("ventas total de medicamento:"))
ventasProductosAseo = float(input("ventas total de productos de aseo:"))

pagoSemanalFijoVendedor = 200
gananciaVendedorMedicamento =(ventasMedicamento*0.09)
gananciaVendedorProductosAseo =(ventasProductosAseo*0.13)
gananciaTotal = gananciaVendedorMedicamento+gananciaVendedorProductosAseo+pagoSemanalFijoVendedor

print("ganancia total del vendedor:", gananciaTotal)

