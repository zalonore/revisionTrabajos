#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int diferenciaParejas(int n1, int n2){
    int sum = 0;
    if (n1 > n2){
        sum = n1 - n2;
    }
    else{
        sum = n2 - n1;
    }
    return sum;
}

int sumarParejas(int arreglo[], int tam){
    int i, j, dif, minDif = 10000, count = 0, sum = 0, clave[10];
    for (i = 0; i < tam; i++){
	    for (j = 0; j < tam; j++){
	        sum = *(arreglo + i) + *(arreglo + j);
	        if (sum >= 3333){
	            dif = diferenciaParejas(*(arreglo + i), *(arreglo + j));
	            if (minDif > dif && dif != 0){
	                minDif = dif;
	            }
	        }
	    }
    }
    return minDif;
}

int main(){
	int i, j, clave,sum, count, tam = 40, arreglo[40], nAleatorio;
	srand(time(NULL));
	for(i = 0; i < tam; i++){
		nAleatorio = 100 + rand() % (2500 - 101);
		*(arreglo + i) = nAleatorio; 
	}
	clave = sumarParejas(arreglo, 40);
	printf("%p", &clave);
	return 0;
}