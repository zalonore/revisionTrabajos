valor = int(input("Ingrese un número: "))
revertir = 0
if valor > 0:
 residuo = valor % 10
 revertir = (revertir * 10) + residuo
 valor= valor//10
 residuo = valor % 10
 revertir = (revertir * 10) + residuo
 valor= valor//10
 residuo = valor % 10
 revertir = (revertir * 10) + residuo
 valor= valor//10
 residuo = valor % 10
 revertir = (revertir * 10) + residuo
 print ("El inverso del número ingresado es: ",revertir)
else:
  print("Ese número no es valido. Inténtalo de nevo !")