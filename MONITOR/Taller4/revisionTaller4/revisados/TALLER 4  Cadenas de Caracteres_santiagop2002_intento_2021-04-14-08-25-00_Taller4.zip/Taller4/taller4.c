#include <stdio.h>

void menu(){
   printf("Taller 4:\n"
          "=================\n"
          "1. Punto 1.\n"
          "2. Punto 2.\n"
          "3. Punto 3.\n"
          "4. Punto 4.\n"
          "0. Salir.\n"
          "opcion: ");
}

int punto1(){
	int car = 0, c;
	printf("Ingrese la cadena de caracteres: ");
	c = getchar();
	while(c != '\n'){
		car++;
		c = getchar();
	}
	return car;
}

void punto2(char *cadena){
	cadena[0] -= 32;
	cadena[16] -= 32;
	cadena[24] -= 32;
	printf("%s", cadena);
}

void punto3(char *cadena, char vocal, int n){
	int numVocal = 0, i;
	char vocalm, vocalM;
	if(vocal > 85){
		vocalm = vocal;
		vocalM = vocal - 32;
	}else{
		vocalM = vocal;
		vocalm = vocal + 32;
	}
	for(i = 0; i < n; i++){
		if(vocalm == cadena[i] || vocalM == cadena[i]){
			switch(numVocal % 2){
			case 0:
				if(cadena[i] > 85){
					cadena[i] -= 32;
				}
				break;
			case 1:
				if(cadena[i] < 85){
					cadena[i] += 32;
				}
				break;
			}			
			numVocal++;
		}
	}
	printf("Numero de vocales %d.\n", numVocal);
	printf("%s", cadena);
}

int comparar(char *cad1){
	int i, ans = 0;
	char cad2[] = "camara";
	for(i = 0; i < 6; i++){
		if(cad1[i] != cad2[i]){
			ans++;
		}
	}
	return ans;
}

void punto4(){
	int i, j;
	char c1[6], c3[341], c2[] = "Mi profe consiguio una camara vieja antes de la pandemia, pero como ahora es un profe digital, el profe se consiguio una camara nueva mas bonita. Pasado el tiempo se dio cuenta que la camara nueva aunque bonita era una camara mala, pero que bobada, al fin y al cabo, ya sea con una camara vieja o una camara nueva, nunca la muestra en clase.\nueva";
	for(i = 0, j = 0; i < sizeof(c2); i++){
		if(comparar(&c2[i])){
			c3[j++] = c2[i];  
		}else{
			i += 6;
		}
	}
	printf("%s", c3);
}

int main(){
	int punto;
	char vocal, cadena[] = "en un comienzo, gabriel garcia Marquez penso en titular su novela La Casa, pero se decidio por Cien anios de soledad para evitar confusiones con la novela La Casa Grande, publicada en 1954 por su amigo, Alvaro Cepeda Samudio\n";
	do{
		menu();		
		scanf("%d", &punto);
		fflush(stdin);
		switch(punto){
			case 1:
				printf("La cadena tiene %d caracteres.\n", punto1());
				break;
			case 2:
				punto2(cadena);
				break;
			case 3:
				printf("Ingrese la vocal: ");
				scanf("%c", &vocal);
				punto3(cadena, vocal, sizeof(cadena));
				break;
			case 4:
				punto4();
				break;
		}
	}while(punto);
	return 0;
}