first=float(input("digite su primer número:"))

second=float(input("digite su segundo número:"))
suma=first+second
resta=first-second
multiplicacion=first*second
division=first/second
potencia=first**second
print( "(teniendo en cuenta el orden del primero ante el segundo) el resultado de la suma es:",suma,"el de la resta es:",resta,"el de la multiplicacion es:",multiplicacion,"el de la division es:",division,"y por ultimo el de la potencia es:",potencia,)


                 
                 
