numero=int(input("digite su numero:"))

if numero%2==0:
    print("true")

else:
    print("false")
    
