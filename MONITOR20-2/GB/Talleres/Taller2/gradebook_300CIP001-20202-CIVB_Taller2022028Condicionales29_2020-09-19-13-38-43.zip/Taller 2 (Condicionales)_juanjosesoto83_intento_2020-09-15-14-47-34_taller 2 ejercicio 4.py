numero1=float(input("numero 1= "))
numero2=float(input("numero 2= "))
numero3=float(input("numero 3= "))
if (numero1+numero2)>numero3 or (numero2+numero3)>numero1 or (numero1+numero3)>numero4:
    print("es triangulo")
    if numero1==numero2 and numero2==numero3 and numero1==numero3:
        print("es equilatero")
    else:
        if (numero1==numero2)  or (numero3==numero2) or (numero1==numero3):
            print("es isoceles")
        else:
            print("es escaleno")
    
    
              
