a=float(input("digite el primer numero"))
b=float(input("digite el segundo numero"))
suma=a+b
resta=a-b
multiplicacion=a*b
division=a/b
potencia=a**b
print("el resultado de la suma es", suma)
print("el resultado de la resta es", resta)
print("el resultado de la multiplicacion es", multiplicacion)
print("el resultado de la division es", division)
print("el resultado de la potencia es", potencia)
