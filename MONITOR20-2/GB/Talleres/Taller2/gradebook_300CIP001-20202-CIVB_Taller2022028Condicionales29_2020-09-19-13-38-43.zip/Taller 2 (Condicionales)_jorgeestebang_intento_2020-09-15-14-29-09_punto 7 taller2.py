usuario1 = input("digite su nombre: ")
usuario2= input("digite su nombre: ")
import random
dado1 = random.randrange(1,6)
print(" el numero de",usuario1, "es",dado1)

dado2=random.randrange(1,6)
print(" el numero de",usuario2," es",dado2)

if dado1==dado2:
    print("hubo empate repiten el juego")
elif dado1>dado2:
    print("el ganador es", usuario1)
elif dado1<dado2:
    print("el ganador es", usuario2)
    
