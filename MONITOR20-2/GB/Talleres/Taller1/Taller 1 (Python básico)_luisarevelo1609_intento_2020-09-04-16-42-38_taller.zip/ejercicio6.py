numero=int(input("por favor ingrese un numero de cuatro cifras:"))
n4=numero%10

n3=(numero%100)//10
n2=(numero%1000)//100
n1=(numero-(numero%1000))//1000
resultado=int(str(n4)+ str(n3)+str(n2)+str(n1))

print("el termino invertido es:",resultado)



