x=input("digite el valor de x: ")
y=input("digite el valor de y: ")
X=y
Y=x
print("la variable x es: ",X)
print("la variable y es: ",Y)
