a=float(input("escriba el coeficiente de la primera variale:"))
b=float(input("escriba el coeficiente de la segunda variable:"))
c=float(input("escriba el coeficiente de la tercera variable:"))

x1=((-b+((b**2)-4*a*c)**(1/2))/(2*a))
print("la solucion 1 es ",x1,"")

x2=((-b-((b**2)-4*a*c)**(1/2))/(2*a))
print("la solucion 2 es ",x2,"")



