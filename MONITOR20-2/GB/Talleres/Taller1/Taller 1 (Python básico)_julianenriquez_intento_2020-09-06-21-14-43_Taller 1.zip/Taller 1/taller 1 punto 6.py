numero = int(input("Porfavor ingrese una fila de numeros: "))    
reversa = 0    
while(numero > 0):
    equisde = numero %10    
    reversa = (reversa*10)+ equisde
    numero = numero //10    
     
print("La reversa del numero ingresado es: =",reversa)
