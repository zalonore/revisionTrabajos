a=int(input("digite el valor de la variable a:"))
b=int(input("digite el valor de la variable b:"))
c=int(input("digite el valor de la variable c:"))
primera=(-1)*b
raiz=((b**2)-4*a*c)**(1/2)
divisor=2*a
xa=(primera+raiz)/divisor
xb=(primera-raiz)/divisor

print("la primera solucion o raiz de la formula cuadratica  es:",xa,";la segunda solucion o raiz de la ecuacion cuadratica es;",xb)
    
