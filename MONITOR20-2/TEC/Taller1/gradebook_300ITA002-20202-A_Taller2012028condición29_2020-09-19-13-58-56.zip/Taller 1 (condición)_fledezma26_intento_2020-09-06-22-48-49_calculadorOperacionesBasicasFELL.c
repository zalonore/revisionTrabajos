//Incluyo biblioteca de entrada salida.
#include <stdio.h>

int sumaNumeros(int numeroUno, int numeroDos){
  return numeroUno+numeroDos;
}
int restaNumeros(int numeroUno ,int numeroDos){
  return numeroUno-numeroDos;
}
int multiplicacionNumeros(int numeroUno, int numeroDos){
  return numeroUno*numeroDos;
}
float divicionNumeros(int numeroUno, int numeroDos){
  float result=0.0;
  if(numeroDos>0){
	result= (float)numeroUno/(float)numeroDos;
  }else{
	printf("No se puede hacer esta operacion para los numeros %d--%d \n", numeroUno,numeroDos);
  }
  return result;
}

int verificarPalindromo(int numeroPal){
  int numeroVolteado = 0, numOperar, cifra, i;
  numOperar = numeroPal;

  for(i = 100000000; i >= 1; i /= 10){
    cifra = numOperar % 10;
    numeroVolteado += (cifra*i);
    numOperar -= cifra;
    numOperar /= 10;
   
  }
  if(numeroPal == numeroVolteado){
    return 1;
  }
  else{
    return 0;
  }
}

int verificarBisiesto(int ano){
  if(ano % 4 == 0 && ano % 100 != 0){
    return 1;
  }
  else if(ano % 400 == 0){
    return 1;
  }
  else{
    return 0;
  }
}

int main(){
  int numeroUno,esBisiesto, numeroPal,numeroDos,resultado, esPalindromo, ano;
  float resultadoDivicion;
  printf("Bienvenidos a este programa de operaciones basicas\n");
  printf("Ingrese el numero uno a operar\n");
  scanf("%d",&numeroUno);
  printf("Ingrese el numero dos a operar\n");
  scanf("%d",&numeroDos);
  printf("Ingrese un numero y le diremos si es palindromo o no, debe tener 9 cifras: \n");
  scanf("%d", &numeroPal);
  printf("Ingrese un ano y le diremos si es bisiesto o no: ");
  scanf("%d", &ano);
  
  //Operaciones
  resultado=sumaNumeros(numeroUno,numeroDos);
  printf("Resultado operacion suma es %d \n", resultado);
  
   resultado=restaNumeros(numeroUno,numeroDos);
  printf("Resultado operacion resta es %d \n", resultado);
  
   resultado=multiplicacionNumeros(numeroUno,numeroDos);
  printf("Resultado operacion multiplicacion es %d \n", resultado);
  
   resultadoDivicion=divicionNumeros(numeroUno,numeroDos);
  printf("Resultado operacion divicion es %f \n", resultadoDivicion);

  esPalindromo = verificarPalindromo(numeroPal);
  if(esPalindromo == 1){
    printf("El numero %d es palindromo\n", numeroPal);
  }
  else{
    printf("El numero %d NO es palindromo o no es de las cifras pedidas\n", numeroPal);
  }
  esBisiesto = verificarBisiesto(ano);
  esBisiesto? printf("El ano es bisiesto"): printf("El ano no es bisiesto");
  
  
  return 0;

}