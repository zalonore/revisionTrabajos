//Incluyo biblioteca de entrada/salida.
#include <stdio.h>





int anoBisiesto(int x){

  if(x % 4 == 0 && x % 100 != 0 ){

    return 1;
  }

  else if(x % 400 == 0){

    return 1;
  }

  else{
    return 0;
  }

}




int suma(int x, int y){
  return x+y;
}

void palindromo(int x){

    int reversedX = 0, remainder, originalX;
    originalX = x;

   
    while (x != 0) {
        remainder = x % 10;
        reversedX = reversedX * 10 + remainder;
        x /= 10;
    }

  
    if (originalX == reversedX){
        printf("%d is a palindrome.", originalX);
      }
    else{
        printf("%d is not a palindrome.", originalX);
    }
    return;
}




int resta(int x, int y){
  return x-y;
}
int multiplicacion(int x, int y){
  return x*y;
}



float division(int x, int y){
  float result=0.0;
  if(y>0){
	result= (float)x/ (float)y;
  printf("Resultado de la division es: %.2f \n", result);
  }else{
	printf("No se puede hacer la division para los numeros %d y %d \n", x,y);
  }
  return result;
}


int main(){
  int a,b,c, palindrome, ano, x;
  float d;
  printf("Bienvenidos a este programa \n");
  printf("Ingrese el num uno \n");
  scanf("%d",&a);
  printf("Ingrese el num dos \n");
  scanf("%d",&b);
  
  //Operaciones
  c=suma(a,b);
  printf("Resultado de la suma es : %d \n", c);
  
   c=resta(a,b);
  printf("Resultado de la resta es: %d \n", c);
  
   c=multiplicacion(a,b);
  printf("Resultado de la multiplicacion es: %d \n", c);
  
   division(a,b);

   printf("Ingrese un numero de 9 digitos: \n");
   scanf("%d",&palindrome);
   palindromo(palindrome);

   printf("\nDigite un ano: \n");
   scanf("%d",&ano);
   x=anoBisiesto(ano);
   if(x == 1){
    printf("El ano %d es bisiesto y mi nombre es Esteban Herrera \n", ano);
   }
   else{
    printf("El ano %d no es bisiesto y tengo 1 hermano \n");
   }


  return 0;
}

