#include<stdio.h> 
#define CAP 30 

int main(){
    char cadena[ CAP ];
    int i, numLetras = 0;
   
    printf( "Introducir palabra: " );
    fgets(cadena, CAP, stdin );

    for( i = 0; i < CAP; i++ ){
    	if( cadena[ i ] == '\0' ){
    		break;
    	}else{
    		numLetras++;
    	}
    }
   
    printf( "El numero de letras de la palabra es: %d" , numLetras - 1 );

    return 0;
}