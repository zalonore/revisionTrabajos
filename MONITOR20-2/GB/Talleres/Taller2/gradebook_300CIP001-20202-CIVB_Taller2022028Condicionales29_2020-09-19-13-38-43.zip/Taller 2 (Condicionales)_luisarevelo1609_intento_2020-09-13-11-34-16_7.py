nombre1=input("digite el nombre del jugador 1:")
nombre2=input("digite el nombre del jugador 2:")
import random
x=random.randrange (1,6)
print("el numero de", nombre1, "es:",x)
y=random.randrange (1,6)
print("el numero de", nombre2, "es:",y)


if x>y:
    print("por lo tanto, el ganador es:",nombre1)
    
elif y>x:
    print(" por lo tanto, el ganador es:",nombre2)
    
else:
    print(" por lo tanto,hubo un empate")
    
