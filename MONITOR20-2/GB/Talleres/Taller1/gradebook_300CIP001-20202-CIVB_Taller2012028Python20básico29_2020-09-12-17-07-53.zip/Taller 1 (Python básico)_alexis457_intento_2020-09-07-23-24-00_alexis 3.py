radio = int(input("digite el radio:",))
radioTotal = radio**2
area = 3.14*radioTotal

print("el area total del circulo es:", area)