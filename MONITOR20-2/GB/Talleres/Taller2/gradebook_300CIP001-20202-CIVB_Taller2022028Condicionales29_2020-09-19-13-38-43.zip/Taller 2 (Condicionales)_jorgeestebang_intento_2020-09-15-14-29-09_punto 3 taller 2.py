numero1=int(input("digite su numero 1: "))
numero2=int(input("digite su numero 1: "))

if numero1%numero2==0:
    print (True)
else:
    print (False) 
            
