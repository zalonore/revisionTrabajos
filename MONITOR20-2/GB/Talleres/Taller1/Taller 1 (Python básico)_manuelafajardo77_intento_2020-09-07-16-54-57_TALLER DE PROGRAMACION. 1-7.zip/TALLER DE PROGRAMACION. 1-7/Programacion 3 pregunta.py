Radio = float (input ("Por favor digite el numero de radio:"))
Pi = 3.1416
Radio2 = (Radio **2)
Area = (Pi*Radio2)

print ("El area de el circulo es:",Area)
