x = float(input ("digite el radio: "))
a = x * x * 3.1416
print ("El area del circulo de radio: ",x,"es: ",a)