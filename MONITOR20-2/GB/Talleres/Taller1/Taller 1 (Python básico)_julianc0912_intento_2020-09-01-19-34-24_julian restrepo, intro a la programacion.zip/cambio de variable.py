a=input("digite el valor de X")
b=input("digite el valor de Y")
a,b=b,a
print("digite el valor de X es", a)
print("digite el valor de Y es", b)
