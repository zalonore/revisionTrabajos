pi=3.1416
radio=float(input("digite el valor del radio"))
area=pi*(radio**2)
print("el area del circulo es:",area)

