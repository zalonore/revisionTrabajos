a = int(input("ingrese primer valor:"))
b = int(input("ingerse segundo valor:"))
r1 = (a%2==0)
r2 = (b%2==0)

if r1:
    if r2:
        print(a*b)
    else:
        print(a*a)
else:
    if r2:
        print(b*b)
    else:
        print(0)
 
1.Respuesta:pedir dos valores los cuales sean pares y al ingresarlos den 3 diferentes condiciones cuando sean pares los dos se
 multipliquen entre si, si uno es par y el otro impar se multiplica el par dos veces el mismo y si los dos son impares da igual a cero.
2.Da como resultado 4 porque el 11 es un numero impar y se multiplica el par dos veces.      