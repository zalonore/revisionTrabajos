numero = int(input("ingrese el año:"))

if numero%100!=0:
    if numero%4==0:
        print("es año bisiesto")
    else:
        print("no es año bisiesto")
elif numero%400==0:
    print("es un año bisiesto")
else:
    print("no es un año bisiesto")
     
