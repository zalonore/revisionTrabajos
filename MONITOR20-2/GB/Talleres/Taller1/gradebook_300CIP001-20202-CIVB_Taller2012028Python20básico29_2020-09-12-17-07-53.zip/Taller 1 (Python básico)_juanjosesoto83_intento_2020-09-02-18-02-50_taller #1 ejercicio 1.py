print( "EJERCICIO 1")

print ( ''' \  |  /
        
   @ @  
        
\  """  / ''')
