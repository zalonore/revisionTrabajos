#Imagen
print(" \     |     /")
print()
print("    @@  ")
print()
print(" \   '' '' ''   /")

