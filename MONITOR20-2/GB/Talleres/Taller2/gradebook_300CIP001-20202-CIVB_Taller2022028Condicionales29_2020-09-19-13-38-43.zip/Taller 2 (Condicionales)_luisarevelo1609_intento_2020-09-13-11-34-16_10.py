x=int(input("digite el valor de la transaccion:"))
if x>=1000 and x<=300000:
     diez= x//10000
     x=x-diez*10000
     cinco=x//5000
     x=x-cinco*5000
     dos=x//2000
     x=x-dos*2000
     uno=x//1000
     x=x-uno*1000
     print("use",diez, "billetes de 10000, use",cinco, "billetes de 5000,use",dos,"billetes de 2000,use",uno,"billetes de 1000" )
else:
    print("su transaccion no es valida")



     
    

      
      
