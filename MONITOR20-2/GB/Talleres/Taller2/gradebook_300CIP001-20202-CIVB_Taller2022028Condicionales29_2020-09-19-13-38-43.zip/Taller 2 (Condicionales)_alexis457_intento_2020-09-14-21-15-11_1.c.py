x = 11
y = 9 
z = 10
w = 4



if not(y>z and x==w):
    print("verdad")
else:
    print("falso")

