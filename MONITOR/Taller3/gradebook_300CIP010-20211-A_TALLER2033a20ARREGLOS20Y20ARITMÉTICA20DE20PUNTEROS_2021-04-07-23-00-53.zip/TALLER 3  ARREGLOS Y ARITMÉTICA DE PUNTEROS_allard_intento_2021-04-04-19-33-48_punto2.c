#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int tam = 40;
int conjuntoA[40];
int candidatosTesoro[40];
int clavesTesoro[2];

void LlenarArreglo(int arreglo[]){
   int i;
   for( i=0; i < tam; i++){
      *(arreglo + i) = 100 + rand() % 2500;
   }
}

void ParejaNumeros( int conjuntoA[], int clavesTesoro[], int tam ){
   int sumaActual,elementoA,elementoB,restaActual,restaMenor = 2500,i,j,conteo,elementoGanadorA,elementoGanadorB;
   
   for( i=0; i < tam; i++){
      elementoA = *(conjuntoA + i);
      for( j=0; j < tam; j++){
         elementoB = *(conjuntoA + j);
         if (elementoB != elementoA){         
            sumaActual = elementoA + elementoB;
            if (sumaActual >= 3333){
               restaActual = elementoA - elementoB;
               if (restaActual < 0){
                  restaActual = restaActual*(-1);
               }
            
               if (restaActual < restaMenor){
                  restaMenor = restaActual;
                  elementoGanadorA = elementoA;
                  elementoGanadorB = elementoB;
               }        
            }                 
         }
      }
   }

   *(clavesTesoro + 0) = elementoGanadorA;
   *(clavesTesoro + 1) = elementoGanadorB;
      
}


int main(){

   int contador;
   srand (time(NULL));
   LlenarArreglo(conjuntoA);
   printf("La lista protagonista en este programa es: ");
   printf(" \n");
   for (contador = 0; contador < tam; contador++){
      printf(" %d, ",conjuntoA[contador]);
   }
   printf(" \n");
   printf(" \n");

   printf("Las direcciones de memoria de cada elemento de la lista son respectivamente: ");
   printf(" \n");
   for (contador = 0; contador < tam; contador++){
      printf(" %p, ",conjuntoA + contador);
   }

   printf(" \n");
   printf(" \n");
   ParejaNumeros(conjuntoA,clavesTesoro,tam);
   

   printf("Los elementos ganadores son: ");
   printf(" \n");
   for (contador = 0; contador < 2; contador++){
      printf("%d ,",clavesTesoro[contador]);
   }

   printf(" \n");
   printf(" \n");
   printf("Las claves de tesoro(guardadas en las direcciones de memoria de los elementos ganadores)son: ");
   printf(" \n");
   for (contador = 0; contador < tam; contador++){
      if (conjuntoA[contador] == clavesTesoro[0]){
         printf(" %p, ",&conjuntoA[contador]);
      }
      if (conjuntoA[contador] == clavesTesoro[1]){
         printf(" %p, ",&conjuntoA[contador]);
      }
   }

   
   

return 0;
}