number=int(input("registre un numero de 4 cifras:"))
modulo1=number%10
number=number//10
modulo2=number%10
number=number//10
modulo3=number%10
number=number//10
modulo4=number%10

print(modulo1,modulo2,modulo3,modulo4)






