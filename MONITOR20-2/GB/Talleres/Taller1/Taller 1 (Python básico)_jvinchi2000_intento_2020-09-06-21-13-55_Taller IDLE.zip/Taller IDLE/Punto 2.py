a=float(input('primero numero'))
b=float(input('segundo numero'))

suma = a+b
resta = a-b
multiplicacion = a*b
division = a/b
potencia = a**b
print ('la suma es',(suma))
print ('la resta es', (resta))
print ('la multiplicacion es',(multiplicacion))
print ('la division es',(division))
print ('la potencia es',(potencia))
