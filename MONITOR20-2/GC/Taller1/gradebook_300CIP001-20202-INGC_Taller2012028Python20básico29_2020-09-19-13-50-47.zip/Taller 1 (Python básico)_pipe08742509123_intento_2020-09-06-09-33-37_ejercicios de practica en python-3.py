dmm=float(input("ingrese el diametro del circulo:"))
radio=dmm/2
π=3.1416
A=π*radio**2
print("el area del circulo es igual a",A)

