#include <stdio.h>
#include<stdlib.h>

void contarcadenas(char cad[]){
     int con=0;
     char *p=cad;

     while(*p!=0){
          p++;
          con++;
          if(*p=='\0'){ // si encuentra un espacio
               con--;
          }
     }
     printf(" la cadena ingresada tiene %d caracteres",con);
}

void modificar_cadena(char cad[]){
     char *p=cad;
     while(*p!=0){

          if (p==cad){//condicion de primera letra de una cadena
               *p='E'; // cambia a E
          }

          if(*p=='g'){
               *p='G'; // cambia a G
          }
          p++; // apunta al siguiente caracter
     } 
     printf(" \nla cadena nueva es: %s",cad);
}

void buscar_vocal(char cad[]){

     char vocal;
     char *p=cad;
     printf("ingrese la vocal a buscar:\n");
     scanf("%s",&vocal);
     int con=0;

     while(*p!=0){

          if (*p>='A' && *p<='Z'){  // si es mayuscula
               *p= *p - ('A'-'a');   // pasar a minúscula       
          }
          if (*p== vocal){ 
               con++;
               if (con % 2== 0){
                    *p= *p - ('a'-'A'); //pasar a mayúscula
               }
          }

          p++; // apunta al siguiente caracter
     } 
     printf("\nla vocal aparece %d veces",con);
     printf("\nla cadena nueva es: %s",cad);
}



void quitar_palabra(char cad[]){

     char *p=cad;
     int i;
     char cadena_nueva[10000];
     char *p1=cadena_nueva;

     while(*p!=0){

          if (*p=='c'){  // si es c
               p++;
               if (*p== 'a'){
                    p++;
                    if (*p== 'm'){
                         p++;
                         if (*p== 'a'){
                              p++;
                              if (*p== 'r'){
                                   p++;
                                   if (*p== 'a'){
                                        for (i=0;i<6;i++){
                                             *(p-i)='*';
                                        }
                                   }
                              }
                         }
                    }
               }       
          }

          p++;
     } 

    // while(*p!=0){

//        if (*p != '*'){
//           *p1=*p;
//           p1++;
//        }
//        p++;
//   } 

     printf("\nla cadena nueva es: %s",cad);
}


int main(){
     char cadena[40];
     printf("Escriba un texto:\n");
     gets(cadena);
     contarcadenas(cadena);
     char cad[]="en un comienzo, gabriel garcia Marquez penso en titular su novela La Casa, pero se decidio por Cien anios de soledad para evitar confusiones con la novela La Casa Grande, publicada en 1954 por su amigo, Alvaro Cepeda Samudio";
     modificar_cadena(cad);
     buscar_bocal(cad);
     char cad2[]="Mi profe consiguio una camara vieja antes de la pandemia, pero como ahora es un profe digital, el profe se consiguio una camara nueva mas bonita. Pasado el tiempo se dio cuenta que la camara nueva aunque bonita era una camara mala, pero que bobada, al fin y al cabo, ya sea con una camara vieja o una camara nueva, nunca la muestra en clase.";
     quitar_palabra(cad2);
     return 0;
}
