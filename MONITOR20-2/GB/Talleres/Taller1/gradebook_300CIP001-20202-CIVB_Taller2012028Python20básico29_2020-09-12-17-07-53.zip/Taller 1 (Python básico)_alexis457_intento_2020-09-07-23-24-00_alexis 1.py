print(" \  |  / ")

print("   @ @   ")

print('\  """  /')



