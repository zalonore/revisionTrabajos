#include <stdio.h>

int main (){
   char palabra[100];
   int i;
   gets (palabra);
   for (i = 0; palabra[i] != '\0'; i++){
   }
   printf("%d", i);
   return i;
}