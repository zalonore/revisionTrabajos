z = 10
w = 4

if z>w:
    print("verdadero")
