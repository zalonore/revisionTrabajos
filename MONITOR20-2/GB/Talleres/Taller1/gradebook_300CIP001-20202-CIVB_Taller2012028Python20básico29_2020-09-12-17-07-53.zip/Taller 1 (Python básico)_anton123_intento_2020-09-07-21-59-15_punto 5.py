a= int(input("dijite el valor de la variable cuadratica(a)="))
b= int(input("dijite el valor de la variable lineal(b)="))
c= int(input("dijite el valor del termino independiente(c)="))






variable=(b**2)
variable2=(-4*(a)*(c))
variable3= variable-variable2
raiz= variable3**(.5)
suma=(-b)+ raiz
divición=suma/2*a


variable=(b**2)
variable2=(-4*(a)*(c))
variable3= variable-variable2
raiz= variable3**(.5)
resta=(-b)-raiz
divición1= resta/2*a

print("el resultado de su eciacion cuadratica con signo positivo en b=",divición)
print("el resultado de su eciacion cuadratica con signo negativo en b=",divición1)
