//Incluyo biblioteca de entrada/salida.
#include <stdio.h>

int suma(int n1, int n2){
  return n1+n2;
}
int resta(int n1, int n2){
  return n1-n2;
}
int multiplicacion(int n1, int n2){
  return n1*n2;
}
float division(int n1, int n2){
  float result=0.0;
  if(n2>0){
	result= (float)n1/ (float)n2;
  }else{
	printf("No se puede hacer esta operacion para los numeros %d--%d \n", n1,n2);
  }
  return result;
}
int palindromo(int a){
  int i, numInvertido = 0, diezModulo = 10, diezDivisionEntera = 1, elevador = 100000000;
  for(i=1; i <= 9; i++){
    numInvertido += ((a % diezModulo) / diezDivisionEntera) * elevador;
    diezModulo *= 10;
    diezDivisionEntera *= 10;
    elevador /= 10;
  }
  a == numInvertido ? printf("El numero %d es palindromo.\n", a) : printf("El numero %d no es palindromo.\n", a);
}
int calcularBisiesto(int anio){
  if((anio%4 == 0 && anio%100 != 0) || (anio%400 == 0)){
    return 1;
  } else {
    return 0;
  }
}

int main(){
  int num1,num2,resultado,numeroPalindromo,anio,prueba;
  float resultadoFlotante;
  printf("Bienvenidos a este programa \n");
  printf("Ingrese el num uno \n");
  scanf("%d",&num1);
  printf("Ingrese el num dos \n");
  scanf("%d",&num2);
  printf("Ingrese un numero de 9 digitos para revisar si es palindromo o no. \n");
  scanf("%d",&numeroPalindromo);
  
  //Operaciones
  resultado=suma(num1,num2);
  printf("Resultado de la suma: %d \n", resultado);
  
  resultado=resta(num1,num2);
  printf("Resultado de la resta: %d \n", resultado);
  
  resultado=multiplicacion(num1,num2);
  printf("Resultado de la multiplicacion: %d \n", resultado);
  
  resultado=division(num1,num2);
  printf("Resultado de la division: %f \n", resultadoFlotante);

  palindromo(numeroPalindromo);

  printf("Ingrese el anio: \n");
  scanf("%d", &anio);
  calcularBisiesto(anio) ? printf("El anio %d es bisiesto, y mi nombre es Fabian.\n", anio) : printf("El anio %d no es bisiesto, y tengo 2 hermanos.\n", anio);

  return 0;

}