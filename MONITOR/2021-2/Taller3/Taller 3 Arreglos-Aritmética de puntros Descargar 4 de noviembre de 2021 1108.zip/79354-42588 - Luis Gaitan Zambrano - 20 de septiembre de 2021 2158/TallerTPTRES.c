/* 
TALLER 3
LUIS FELIPE GAITAN ZAMBRANO
PUNTO 3
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
# define CAPACITY 20
void imprimir(int A[]){
	int conta, contb;	
	for( conta = 0; conta < 20; conta++ ){
		printf( "%d ", A[ conta ] );
	}
	printf( "\n");
	
	return;
	
	
	
	
	
}/*
void sumaPosiciones( int A[CAPACITY] ){
	int j, o, k, numUno, numDos, suma;
	int B[CAPACITY];
	
	for( j = 0; j < 70; j++){
		numUno = A[ j ];
	
		for( k = 0; k < 70; k++){
			if( j != k){
	
				numDos = A[ k ];
				suma = numUno + numDos;
	
				if(suma > 100){
					for( j = 0; j < 70; j++){
						B[ j++ ];
					
				}
			}
		}
	}
	
	
	}
		printf( "\n %d ", suma );
		for( o = 0; o < CAPACITY; o++ ){
			printf( " %d\n ", B[ o ] ); 
	}
}
*/
int main(){
	int A[CAPACITY]; 
	int B[CAPACITY];
	int i, j, numUno, numDos, suma;
	srand(time(NULL));
	
	for( i=0; i<CAPACITY; i++){
		A[i]= 1+rand()%(70-1+1); printf( " %d ", A[i]);
	}	
	imprimir( A );
	
	for( i = 0; i < CAPACITY; i++){
		numUno = A[ i ];
	
		for( j = 0; j < CAPACITY; j++){
			if( j != i){
	
				numDos = A[ j ];
				suma = numUno + numDos;
	
				if(suma > 100){
					for( j = 0; j < 70; j++){
						B[ j++ ];
	}
	//sumaPosiciones( A );
	imprimir( B );
	return 0;
	}	
   }
  }
 }
}

