/* 
TALLER 3
LUIS FELIPE GAITAN ZAMBRANO
PUNTO 2
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

const int ELEMENTOS = 200;
void sumaPareja( int A[ELEMENTOS] ){
	int i, k, menor; 
	int * parejai, * parejak;
	int primero = 1; //bandera
	int numUno, numDos, suma, resta;
	for( i = 0; i < ELEMENTOS ; i++){
		numUno = *(A + i); //Aritmetica de punteros
		
		// A es un puntero: en la direccion de la memoria en una determinada posici�n
	
		for( k = 0; k < ELEMENTOS; k++){
			if( i != k ){
				numDos = *(A + k); //Aritmetica de punteros
				suma = numDos + numUno;
				resta = abs(numDos - numUno);// valor absoluto
							
				if ( suma >= 3333){
					 if(primero == 1 || resta < menor){
					 	primero = 0;
					 	menor = resta;
						parejai = &numUno;					 	
						parejak = &numDos;
					 }	
				}
			} 
		}
	}	
	printf( "\n %x %x \n", parejai, parejak);
}

int main(){
	
	int A[ELEMENTOS]; 
	int i;
	srand(time(NULL));
	for( i=0; i<ELEMENTOS; i++){
		A[i]= 100 + rand()%(2500-100+1); 
		printf( " %d ", A[i]);
	}	
	//printf( "\n %d \n ", *(A + 4)); //Aritmetica de punteros
	sumaPareja(A);
	return 0;
	
}

	

