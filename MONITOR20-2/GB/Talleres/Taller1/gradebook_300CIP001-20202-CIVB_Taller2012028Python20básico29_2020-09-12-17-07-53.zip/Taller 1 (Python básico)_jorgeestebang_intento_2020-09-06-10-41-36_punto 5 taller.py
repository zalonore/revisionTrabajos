print("vamos a calular una ecuacion cuadratica")
a=float(input("digite la variable a: "))
b=float(input("digite la variable b: "))
c=float(input("digite la variable c: "))
x=((-1)*b +(((b**2)- (4*a*c))**(.5)))
x1=x/(2*a)
X=((-1)*b -(((b**2)- (4*a*c))**(.5)))
x2=X/(2*a)
print(x1)
print(x2)




