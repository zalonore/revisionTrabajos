print("vamos a calcular el area de un circulo")
r=float(input("de un valor para el radio: "))
pi=3.1416
A =pi*(r**2)
print("el area del circulo es:", A)
          
