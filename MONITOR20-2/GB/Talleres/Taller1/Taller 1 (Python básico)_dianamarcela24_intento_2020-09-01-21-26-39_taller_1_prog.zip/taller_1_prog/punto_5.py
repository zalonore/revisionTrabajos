b= float(input("digitime la variable b"))
c= float(input("digiteme la variable c"))
a= float(input("digiteme la variable a"))

formula_cuadratica= (-b+(((b**2) - (4*a*c))**0.5)) / (2*a)
formula_cuadratica2= (-b-(((b**2) - (4*a*c))**0.5)) / (2*a)

print("resultado de la formula_cuadratica es: ", formula_cuadratica)
print("resultado de la formula_cuadratica2 es: ",formula_cuadratica2)     
