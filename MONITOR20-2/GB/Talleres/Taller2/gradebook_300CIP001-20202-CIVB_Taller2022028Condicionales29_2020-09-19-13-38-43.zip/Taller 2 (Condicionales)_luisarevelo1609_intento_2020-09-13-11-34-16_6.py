x=int(input("digite el numero de piso al cual se dirige:"))
if x==1 or x==2:
    print("usted debe usar las escaleras")

else:
    if x>15:
        print("usted se despacha en el ascensor 1")
    
    elif x%2!=0 and x<=15:
        print("usted se despacha en el ascensor 2")

    elif x%2==0 and x<15:
        print("usted se despacha en el ascensor 3")

