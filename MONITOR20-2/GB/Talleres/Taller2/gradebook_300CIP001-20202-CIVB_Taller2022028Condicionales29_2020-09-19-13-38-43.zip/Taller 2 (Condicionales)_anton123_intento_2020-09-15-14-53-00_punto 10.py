t = float(input("Inserte valor transaccion(use el punto para definir los miles)"))
Billetes10 = t // 10.000
restante = t % 10.000
a = ("1 Billete de")
b = ("2 Billetes de ")
c = 9.000
d = 8.000
e = 7.000
f = 6.000
g = 5.000
h = 4.000
i = 3.000
j = 2.000
k = 1.000
l = 0
if(t > 300.000):
   print("El limite de dinero que se puede mandar en una transaccion es 300.000")
else:
 if(restante == c):
      print(Billetes10, " Billetes de 10.000", a ," 5.000", b, " 2.000")
 else:
  if(restante == d):
    print(Billetes10, " Billetes de 10.000", a, " 5.000", a, " 2.000",a, " 1.000")
  else:
    if(restante == e):
      print(Billetes10, " Billetes de 10.000", a, " 5.000", a, " 2.000")
    else:
      if(restante == f):
        print(Billetes10, " Billetes de 10.000", a, " 5.000", a, " 1.000")
      else:
        if(restante == g):
          print(Billetes10," Billetes de 10.000", a, " 5.000" )
        else:
          if(restante == h):
            print(Billetes10," Billetes de 10.000", b, " 2.000" )
          else:
            if( restante == i):
              print(Billetes10," Billetes de 10.000", a, " 2.000", a, " 1.000")
            else:
              if(restante == j):
                print(Billetes10," Billetes de 10.000", a, " 2.000")
              else:
                if(restante == k):
                  print(Billetes10," Billetes de 10.000", a, " 1.000")
                else:
                  if(restante == l):
                    print(Billetes10," Billetes de 10.000")
