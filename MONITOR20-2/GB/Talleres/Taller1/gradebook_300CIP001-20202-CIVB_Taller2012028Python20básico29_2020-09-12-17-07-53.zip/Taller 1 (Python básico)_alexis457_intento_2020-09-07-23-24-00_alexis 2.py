primerNumero = int(input("Digite el primer numero:"))
segundoNumero = int(input("Digite el segundo numero:"))
suma = primerNumero+segundoNumero
resta = primerNumero-segundoNumero
multiplicacion = primerNumero*segundoNumero
division = primerNumero/segundoNumero
primerPotencia = primerNumero**2
segundaPotencia = segundoNumero**2
print("resultadodelasuma:", suma)
print("resultadodelaresta:", resta)
print("resultadodivision:", division)
print("resultadoprimerapotencia:", primerPotencia)
print("resultadosegundapotencia:", segundaPotencia)
