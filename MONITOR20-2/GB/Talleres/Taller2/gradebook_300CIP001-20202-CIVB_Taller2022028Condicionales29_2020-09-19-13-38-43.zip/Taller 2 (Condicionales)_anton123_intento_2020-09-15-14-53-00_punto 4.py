a= int(input("Valor lado 1:"))
b= int(input("Valor lado 2:"))
c= int(input("Valor lado 3:"))
Triangulo = a+b>c or a+c>b or b+c>a
if Triangulo:
  if a==b and a==c and b==c:
    print ("Es equilatero")
  if a==b!=c or a==c!=b or b==c!=a:
    print ("Es Isosceles")
  else:
    if a!=b or a!=c or b!=c:
      print ("Es Escaleno")
