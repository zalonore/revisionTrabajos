#include <stdio.h>

int main(){
	int i, j, acum = 0;
	char c[ 1000 ], tra[1000];

	printf( "ingrese el parrafo:\n");

	fgets( c, sizeof(c), stdin );
	for( i = 0; i < sizeof(c); i++ ){
    	if( c[ i ] == '\0' ){
    		break;
    	}else{
    		acum++;
    	}
    }

	for( i = 0, j = 0; i < acum; i++ ){
		if( ( c[ i ] == 'c' ) && ( c[ i + 1 ] == 'a' ) && ( c[ i + 2 ] == 'm' ) && ( c[ i + 3 ] == 'a' ) && ( c[ i + 4 ] == 'r' ) && ( c[ i + 5 ] == 'a' ) ){
			i += 6;
		}else{
			tra[ j ] = c[ i ];
			j++;
		}
	}
	printf("El texto corregido es:\n");
 	for( i = 0; i < sizeof(c); i++ ){
		if ( tra[ i ] == '\0' ){
    		break;
		}
		else{
			printf( "%c", tra[ i ] );
		}
	}
	return 0;
}