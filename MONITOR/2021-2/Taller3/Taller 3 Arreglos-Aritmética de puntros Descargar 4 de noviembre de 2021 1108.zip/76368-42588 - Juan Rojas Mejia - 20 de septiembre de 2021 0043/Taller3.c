#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void menu(){
	printf("1. Punto uno\n");
	printf("2. Punto dos\n");
	printf("3. Punto tres\n");
	printf("0. Salir\n");
	printf("Digite una opcion: ");
}

void llenarArreglo(int array[], int valor){
	for(int i = 0; i < 20; i++){
		array[i] = rand()%valor;
	}
}

void imprimirArreglo(int array[], int size){
	for(int i = 0; i < size; i++){
		printf("%d ", array[i]);
	}
	printf("\n");
}

void puntoUno(int arreglo1[], int arreglo2[], int arreglo3[], int arreglo4[], int size1, int size2, int size3){
	int numArreglo = 0, size4 = 0, i, j, k, verificacion, auxiliar = 0;
	llenarArreglo(arreglo1, 30);
	llenarArreglo(arreglo2, 30);
	llenarArreglo(arreglo3, 30);

	imprimirArreglo(arreglo1, 20);
	imprimirArreglo(arreglo2, 20);
	imprimirArreglo(arreglo3, 20);

	for(i = 0; i < size1; i++){
		for(j = 0; j < size2; j++){
			if(arreglo1[i] == arreglo2[j]){
				for(k = 0; k < size3; k++){
					if(arreglo2[j] == arreglo3[k]){
						for(verificacion = 0; verificacion < size4; verificacion++){
							if(arreglo4[verificacion] == arreglo3[k]){
								auxiliar++;
							}
						}
						if(auxiliar == 0){
							arreglo4[size4++] = arreglo3[k];
						}
					}
				}
			}
		}
	}

	imprimirArreglo(arreglo4, size4);
}

void puntoDos(int p[], int size){
	int i, j, auxiliar = 0, men = 2500, auxiliar2 = 0, pos1, pos2;

	for(i = 0; i < size; i++){
		//scanf("%d", (p+i));
		*(p+i) = (rand()%2400)+100;
	}


	for(i = 0; i < size; i++){
		printf("%d ", *(p+i));
	}

	printf("\n");
	for(i = 0; i < size; i++){
		printf("%d %d\n", *(p+i), *(p+(i+1)));
		auxiliar = *(p+i) + *(p+(i+1));
		for(j = 0; j < size; j++){
			if(auxiliar >= 3333 && i != j){
			auxiliar2 = *(p+i) - *(p+(j));
			if(auxiliar2 < 0 && i != j){
				auxiliar2 *= -1;
			}
			if(auxiliar2 < men && i != j){
				men = auxiliar2;
				pos1 = i;
				pos2 = j;
			}
		}
	}
		i++;
	}

	printf("\n");
	printf("%d-%d\n", pos1, pos2);
	printf("%d-%d\n", *(p+pos1), *(p+pos2));
	printf("La clave del tesoro es: %p%p\n", &p+pos1, &p+pos2);
}

void puntoTres(int inicial[], int final[], int size){
	int auxiliar = 0, sizeFinal = 0, i, j, bandera = 0, temp = 0, n = 0, p = 0;
	llenarArreglo(inicial, 70);
	imprimirArreglo(inicial, 10);
	printf("\n");
	for(i = 0; i < size; i++){
		temp = 0;
		auxiliar = 0;
		p = 0;
		bandera = 0;
		for(j = 0; bandera == 0; j++){
			temp += inicial[i];
			if(temp <= 100 && n < size){
				auxiliar += inicial[i++];
				p++;
				n++;
			}else{
				i--;
				bandera = 1;
			}
		}
		if(p == 0){
			auxiliar = inicial[i++];
			p++;
		}
		final[sizeFinal++] = p;
		final[sizeFinal++] = auxiliar;
	}

	imprimirArreglo(final, sizeFinal);
}

int main(){
	int arreglo1[20], arreglo2[20], arreglo3[20], arreglo4[20], arrayOriginal[10], resultadoFinal[10], juego[40], opc;
	srand(time(NULL));

	do{
		menu();
		scanf("%d", &opc);
		switch(opc){
			case 1:
				puntoUno(arreglo1, arreglo2, arreglo3, arreglo4, 20, 20, 20);
			break;
			case 2:
				puntoDos(juego, 40);
			break;
			case 3:
				puntoTres(arrayOriginal, resultadoFinal, 10);
			break;
		}
	}while(opc != 0);
}