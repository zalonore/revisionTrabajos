base = int(input("digite la base:"))
altura = int(input("digite la altura:"))
area = base*altura
perimetro = base+base+altura+altura
print("resultado area:", area)
print("resultado de perimetro", perimetro)




