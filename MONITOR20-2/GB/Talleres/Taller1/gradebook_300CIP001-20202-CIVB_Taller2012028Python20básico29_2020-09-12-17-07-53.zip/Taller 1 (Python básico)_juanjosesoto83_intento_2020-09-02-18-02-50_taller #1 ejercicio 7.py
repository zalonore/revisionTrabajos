print("ejercicio 7")
x= int(input("insertar valor numerico (variable x)"))
y= input("insertar serie de caracteres (variable y)")
z=x
w=y
x=w
y=z
print( "variable x ", x)
print( "variable y ", y)
