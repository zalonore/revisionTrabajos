print ("ejercicio 1")
x= 11
y= 9
z= 10
w= 4
print ("A) x>w", x>w)
print ("B) y==z or z<y",y==z or z<y)
print ("C) not(x==y and z<w)and w==w",not(x==y and z<w)and w==w)
print ("D) x<y and w=<z or w>=w", x<y and w<=z or w>=z)
print("E) w==w and y>z or z<x and not(w<=z)",w==w and y>z or z<x and not(w<=z))
