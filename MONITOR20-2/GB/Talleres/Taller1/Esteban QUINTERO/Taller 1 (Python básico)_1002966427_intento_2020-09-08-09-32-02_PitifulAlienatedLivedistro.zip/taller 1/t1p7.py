a = input("Ingresar variable a ")
b = input("Ingresar variable b ")
aux = a;
a = b;
b = aux;
print("ahora a= ",a, " y b= ",b)