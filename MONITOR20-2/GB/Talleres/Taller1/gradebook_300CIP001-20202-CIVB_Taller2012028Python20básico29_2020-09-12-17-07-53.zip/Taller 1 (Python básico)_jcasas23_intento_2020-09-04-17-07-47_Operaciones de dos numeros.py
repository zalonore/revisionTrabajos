primernumero = int (input ("Ingrese su primer número: "))
segundonumero = int (input ("Ingrese su segundo número: "))

suma = primernumero + segundonumero
resta = primernumero - segundonumero
multiplicacion = primernumero * segundonumero
division = primernumero / segundonumero
potencia = primernumero ** segundonumero

print ("El resultado de la suma es: ",suma)
print ("El resultado de la resta es: ",resta)
print ("El resultado de la multiplicación es: ",multiplicacion)
print ("El resultado de la division es: ",division)
print ("El resultado de la potencia es: ",potencia)

# Jorge Casas
