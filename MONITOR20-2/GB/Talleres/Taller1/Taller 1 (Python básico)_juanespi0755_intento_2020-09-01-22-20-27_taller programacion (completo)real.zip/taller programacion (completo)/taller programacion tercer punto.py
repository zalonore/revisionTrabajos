radio=float(input("escriba el numero del radio del circulo:"))
Pi=3.1416
area=((radio**2)*Pi)

print("el valor del area del circulo a tratar es",area,"") 
