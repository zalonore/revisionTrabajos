#include <stdio.h>

int main(){
	int i, cont = 0, m = 1, acum = 0;
	char cadena[ 1000 ], l, l2;
	printf( "Digite la oracion:\n");
	fgets( cadena, sizeof(cadena), stdin );

	for( i = 0; i < sizeof(cadena); i++ ){
    	if( cadena[ i ] == '\0' ){
    		break;
    	}else{
    		acum++;
    	}
    }

	printf( "Digite la vocal que desea buscar en minuscula:\n" );
	scanf( "%c", &l );

	for( i = 0; i < acum; i++ ){
		if( (cadena[ i ] == l) || ( cadena[ i ] == l - 32 ) || ( cadena[ i ] == l + 32 ) ){
			cont++;
		}
	}
	printf( "La vocal esta %d veces \n", cont );

	printf( "\n" );

	for( i = 0; i < acum; i++ ){
		if( cadena[ i ] == l ){
			cadena[ i ] -= 32;
			break;
		}
	}
	printf( "Oracion cambiada:\n" );
	puts(  cadena );
	getchar();
	acum = 0;
	printf( "Digite la oracion en minusculas:\n");

	fgets( cadena,sizeof(cadena) , stdin );
	for( i = 0; i < sizeof(cadena); i++ ){
    	if( cadena[ i ] == '\0' ){
    		break;
    	}else{
    		acum++;
    	}
    }

	printf( "Digite la vocal que desea cambiar en minuscula:\n" );
	scanf( "%c", &l );

	for( i = 0; i < acum; i++ ){
		if( cadena[ i ] == l ){
			if( m % 2 != 0 ){
				cadena[ i ] -= 32;
				m++;
			}else{
				m++;
			}	
		}
	}
	printf( "Oracion cambiada:\n" );
	puts( cadena );
	return 0;
}