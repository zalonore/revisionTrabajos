nombre= str(input("coloque su nombre="))
numero= int(input("dijite un numero entero="))



c=nombre
d=numero

print("ahora su nuevo numero es=",c)
print("ahora su nuevo nombre es=",d)
