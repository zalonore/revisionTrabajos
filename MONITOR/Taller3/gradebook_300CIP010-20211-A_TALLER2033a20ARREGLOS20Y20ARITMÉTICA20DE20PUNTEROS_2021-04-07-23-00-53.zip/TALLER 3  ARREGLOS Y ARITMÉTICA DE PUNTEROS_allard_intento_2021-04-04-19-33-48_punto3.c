#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void LlenarArreglo(int arreglo[],int tam){
   int i;
   for( i=0; i < tam; i++){
      *(arreglo + i) = rand() % 70;
   }
}

void SumaConjunta(int arregloA[], int arregloB[], int tam){
   int i, j, elemento, sumaActual, sumaAnterior, contador=0, cantidadSumas=0;
   sumaActual = *(arregloA + 0);
   for( i=1; i < tam; i++){  
      elemento = *(arregloA + i);
      sumaActual = sumaActual + elemento;
      if (sumaActual < 100){
         sumaAnterior = sumaActual;
         cantidadSumas = cantidadSumas + 1;
      }
      
      else{
         printf("%d, ",sumaAnterior);
         printf("%d, ",cantidadSumas);
         sumaActual = *(arregloA + (i));
         sumaAnterior = *(arregloA + (i));
         cantidadSumas = 0;         
      }
   }
   



}

int main(){
   int tam, contador;
   srand (time(NULL));
   printf("Este programa calculara dos arreglos especiales, uno con elementos aleatorios y un tamano digitado por el usuario, y otro como un producto de la suma y cantidad de dichos elementos del primero");
   printf(" \n");
   printf(" Digite el numero de elementos que tendra el primer arreglo: ");
   scanf("%d",&tam);
   int arregloA[tam];
   int arregloB[tam];
   printf(" \n");

   LlenarArreglo(arregloA,tam);

   printf("El arreglo con el que trabajaremos es:");
   for (contador = 0; contador < tam; contador++){
      printf(" %d, ",arregloA[contador]);
   }
   
   printf(" \n");
   printf(" \n");
   printf("La lista que representa la operacion de sumas indicada es: ");
   printf(" \n");
   SumaConjunta(arregloA, arregloB, tam);



return 0;
}


