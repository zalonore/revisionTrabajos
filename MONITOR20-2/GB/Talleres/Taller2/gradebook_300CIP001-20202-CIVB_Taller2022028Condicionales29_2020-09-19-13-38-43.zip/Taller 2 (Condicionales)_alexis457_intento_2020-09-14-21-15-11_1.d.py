x = 11
y = 9 
z = 10
w = 4



if not(y+x>z+w and x==w and x>9):
    print("verdad")
else:
    print("falso")

