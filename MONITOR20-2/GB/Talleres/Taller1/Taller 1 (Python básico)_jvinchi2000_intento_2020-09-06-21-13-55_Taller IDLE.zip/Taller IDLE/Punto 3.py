radio=float(input ("introduzca el radio de la circunferencia para calcular su respectiva area"))
pi = (3.1416)
area = (pi*(radio)**2)

print ('El area es',round(area,2))
