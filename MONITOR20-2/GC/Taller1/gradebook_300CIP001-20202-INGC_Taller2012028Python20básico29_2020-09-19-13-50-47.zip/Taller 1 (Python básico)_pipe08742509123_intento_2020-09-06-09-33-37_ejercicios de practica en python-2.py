numero1=float(input("escriba un digito:"))
numero2=float(input("escriba otro digito:"))
suma=numero1+numero2
print("el resultado de la suma es",suma)
resta=numero1-numero2
print("el resultado de la resta es",resta)
multiplicacion=numero1*numero2
print("el resultado de la multplicacion es",multiplicacion)
division=numero1/numero2
print("el resultado de la division es", division)
potencia=numero1**numero2
print("el resultado de la potencia es", potencia)
