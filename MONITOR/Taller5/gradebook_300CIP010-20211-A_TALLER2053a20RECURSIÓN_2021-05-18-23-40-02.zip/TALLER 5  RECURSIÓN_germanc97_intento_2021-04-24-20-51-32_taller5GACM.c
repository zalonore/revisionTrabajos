//
// Created by German Caycedo on 22/04/21.
//

#include <stdio.h>

// Tipos de recusividad: No lineal o multiple, no final, directa.
int punto1(int A, int B){
    if (A == B){
        return A;
    } else{
        return A + punto1(A+3,B);
    }
}

int punto2(int m, int n){
    int r = m%n;
    if (r == 0){
        return n;
    } else{
        return punto2(n,r);
    }
}

int punto3(int max, int i){
    int r[10] = {1,5,4,2,4,5,3,1,0,9};
    if (i == 10){
        return max;
    }else{
        if(r[i] > max){
          max = r[i];
        }
        return punto3(max,i+1);
    }
}

// Tipos de recusividad: No lineal o multiple, no final, directa.
int punto4(int n){
    if (n <= 1){
        return n;
    }else{
        return punto4(n-1) + punto4(n-2) ;
    }
}

// Tipos de recusividad: No lineal o multiple, final, directa.
int punto5(int m, int n){
    int matrix[4][4] = {{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,0}};

    if (m == 4 && n == 4){
        return 1;
    }else if (m == n && matrix[m][n] != 1){
        return 0;
    }else if (m != n && matrix[m][n] == 1){
        return 0;
    }
    else if (m == 4){
        return punto5(0,n+1) ;
    }else{
        return punto5(m+1,n);
    }
}

int main(){
    int opc;
    printf("\nIngrese la opcion que desea: ");
    scanf("\n%d", &opc);

    if(opc == 0){
        return 0;
    }
    if(opc == 1){
        int A, B, N;
        printf("Ingrese el limite inferior y el limite superior: ");
        scanf("\n%d", &A);
        scanf("\n%d", &B);
        if(A % 3 != 0){
            while (A % 3 != 0){
                A = A+1;
            }
        }
        if(B % 3 != 0){
            while (B % 3 != 0){
                B = B-1;
            }
        }
        int ans = punto1(A,B);
        printf("%d", ans);

        return main();
    }
    if (opc == 2){
        int m, n;
        printf("Ingrese dos numeros enteros positivos, el primero debe ser mayor al segundo: ");
        scanf("\n%d", &m);
        scanf("\n%d", &n);
        if (m > n){
           int ans = punto2(m,n);
           printf("%d", ans);
        } else{
            printf("El primer numero debe ser mayor al segundo");
        }
        return main();
    }
    if (opc == 3){
        int ans = punto3(0,0);
        printf("%d", ans);
        return main();
    }
    if (opc == 4){
        int n;
        printf("Ingrese el numero a calcular Fibonacci: ");
        scanf("\n%d", &n);
        int ans = punto4(n);
        printf("%d", ans);
        return main();
    }
    if (opc == 5){
        int ans = punto5(0,0);
        if (ans == 0){
            printf("No es una matriz identidad");
        } else if (ans == 1){
            printf("Es una matriz identidad");
        }
        return main();
    }
}