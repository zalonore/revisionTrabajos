X=11
Y=9
Z=10
W=4

print ("Solucion a", X>Y)
print ("Solucion b", X<W and Y>Z)
print ("Solucion c", not X<Z or W>Z)
print ("Solucion d", X<Z and ((Y>W == X)))
print ("Solucion e", (Z!=Z)<(W<X)and(W==Y)or Z)
