base = input("Ingrese la base del recatangulo en cm ")
altura = input("Ingrese la altura del rectangulo en cm ")
b = float(base)
h = float(altura)
area = (b*h)
perimetro = (b+b+h+h)

print ("El area de su rectangulo es:",area,"cm cuadrados")
print ("El perimetro de su rectangulo es", perimetro, "cm")
