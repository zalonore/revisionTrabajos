r = int (input ("Ingrese el radio de su círculo: "))


pi = 3.1416

print ("A = Pi*r^2")

A = pi * r**2

print ("El área de su círculo es: ",A)
# Jorge Casas
