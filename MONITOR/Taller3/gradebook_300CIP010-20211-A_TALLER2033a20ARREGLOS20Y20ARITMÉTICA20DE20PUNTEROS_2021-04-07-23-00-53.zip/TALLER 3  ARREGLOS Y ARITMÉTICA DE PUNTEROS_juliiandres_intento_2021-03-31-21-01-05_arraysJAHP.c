/* Julián Andrés Hernández Potes      */
/* Programming Techniques & Practices */
/* Assignment 3    {arrays}           */

#include <stdio.h>
#include <stdlib.h> // I need this library for random numbers (time.h makes an error)
#include <math.h> // For Absolute Value function

int repeatedNumber( int D[], int sizeD, int num ){
    int i;
    for( i = 0; i < sizeD; i++ ){
        if( D[i] == num ) return 0;
    }
    return 1;
}

void random( int arr[], int sizeArray, int from, int to ){ // This procedure generates the numbers for the array
    int i, randomNum;
    srand(time(NULL)); // start random number generator
    for( i = 0; i < sizeArray; i++ ){
        randomNum = rand() % (to - from + 1) + from;
        *( arr + i ) = randomNum;
    }
}

void intersection( ){
    int A[20] = { 1, 2, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
    int B[20] = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 18, 16, 13, 12, 10, 8, 6, 4, 2, 1 };
    int C[20] = { 2, 3, 7, 13, 17, 20, 17, 13, 2, 3, 7, 13, 17, 21, 17, 13, 7, 3, 2, 1 };
    int D[] = {0}, i, j, k, sizeD = 0;
    for( i = 0 ; i < 20; i++ ){
        for( j = 0; j < 20; j++ ){
            for( k = 0; k < 20; k++ ){
                if( ( A[i] == B[j] && B[j] == C[k] && A[i] == C[k] ) && repeatedNumber( D, sizeD, A[i] ) ){
                    D[sizeD] = A[i]; 
                    sizeD++;
                }
            }
        }
    }
    printf( "Intersection: D = ");
    for( i = 0; i < sizeD; i++ ){
        printf( "%d ", D[i] );
    }
}

void treasureChest( ){
    int i, j, numA, numB, sum, subsAbsolute, lastSubs = 2401;
    int *aux1, *aux2;
    int array[40];
    int *pointer = array;
    random( array, 40 , 100, 2500 );
    printf( " ARRAY: " ); // Just to visualize
    for( i = 0; i < 40; i++ ){
        printf( "%d, ", array[i] );
    }
    for( i = 0; i < 40; i++ ){
        numA = *( pointer + i );
        for( j = i+1; j < 40; j++ ){ // I's not necessary to add with the previous ones cuz it is redundant
            numB = *( pointer + j );
            sum = numA + numB;
            if( sum >= 3333 ){
                subsAbsolute = fabs( numA - numB );
                if( subsAbsolute < lastSubs ){
                    lastSubs = subsAbsolute;
                    aux1 = ( pointer + i );
                    aux2 = ( pointer + j ); 
                }
            }
        }
    }
    printf( "\n\nNumberA = %d and NumberB = %d, whose sum = %d, has the substraction with minimum abs = %d\n", *aux1, *aux2, (*aux1 + *aux2), lastSubs );
    printf( "***THE DIRECTIONS FOR TREASURE CHEST ARE: 0x%p AND 0x%p***\n", aux1, aux2 );
}

void thirdExercise( ){
    int N, i, j, k = 0, sum, counter;
    printf( "Type the size of array: " );
    scanf( "%d", &N );
    int array[N];
    int resultsArray[50]; // I don't know how to reserve memory por an array
    random( array, N, 0, 70 );
    printf( " ARRAY: " );
    for( i = 0; i < N; i++ ){ // Just to visualize
        printf( "%d, ", array[i] );
    }
    for( i = 0; i < N; i++ ){
        sum = array[i];
        counter = 1;
        j = i;
        while( sum < 100 && j < N ){
            j++;
            counter++;
            sum += array[j]; 
        }
        
        sum -= array[j];
        resultsArray[ 2*k ] = counter - 1;
        resultsArray[ 2*k + 1 ] = sum;
        k += 1;
        i = j-1;
    }
    printf( "\n\nRESULT ARRAY: " );
    for( i = 0; i < (2*k); i++ ){
        printf( "%d ", resultsArray[i] );
    }
}


int main( ){
    int select;
    printf( "SELECT THE EXERCISE: " );
    scanf( "%d", &select );
    switch( select ){
        case 1:
            intersection( );
            break;
        case 2:
            treasureChest( );
            break;
        case 3:
            thirdExercise( );
            break;
        default:
            printf( "NO\n" );
            break;
    }
    return 0;
}

/*// Don't staring at this, is only for testing.
int try(){
    int D[] = { 1, 2, 3, 4, 5 };
    int sizeD = sizeof(D) / sizeof(D[0]);
    int a = repeatedNumber( D, sizeD, 5 );
    printf("%d",a);
    return 0;
}*/
