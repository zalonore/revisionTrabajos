a = float(input("Digite su numero:"))
b = float(input("Digite su numero:"))
c = float(input("Digite su numero:"))

X1 = (-b+(((b**2)-(4*a*b))**1/2))/(2*a)
x2 = (-b-(((b**2)-(4*a*b))**1/2))/(2*a)

print("Resultado de la primera variable:", X1)
print("Resultado de la segunda variable:", x2)

