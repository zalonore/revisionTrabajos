numero=int(input("insetar numero entero"))
if numero%2==0:
    print("el numero es par", "false")
else:
    print("el numero es impar","true")
numero1= int(input("primer numero"))
numero2= int(input("segundo numero"))
if numero1%numero2==0:
    print("true")
else:
    print("false")
