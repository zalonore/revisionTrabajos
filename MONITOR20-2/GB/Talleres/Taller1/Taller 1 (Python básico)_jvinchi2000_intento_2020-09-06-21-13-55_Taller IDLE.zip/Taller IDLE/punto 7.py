a = ('rodolfo')
b = 1225421394551661625

print  (a)
print  (b)

a = 1225421394551661625
b = ('rodolfo')

print (a)
print (b)
