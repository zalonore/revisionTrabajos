#include <stdio.h>
#define CAP 400

int main(){
	int i, cont, j, acum = 0;
	char c[ CAP ];

	printf( "Digite el parrafo:\n");

	fgets( c, CAP, stdin );
	for( i = 0; i < CAP; i++ ){
    	if( c[ i ] == '\0' ){
    		break;
    	}else{
    		acum++;
    	}
    }
	char new[ acum ];

	for( i = 0, j = 0; i < acum; i++ ){
		if( ( c[ i ] == 'c' ) && ( c[ i + 1 ] == 'a' ) && ( c[ i + 2 ] == 'm' ) && ( c[ i + 3 ] == 'a' ) && ( c[ i + 4 ] == 'r' ) && ( c[ i + 5 ] == 'a' ) ){
			i += 6;
		}else{
			new[ j ] = c[ i ];
			j++;
		}
	}
	puts( new );

	return 0;
}