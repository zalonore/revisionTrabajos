a=float(input("digite la variable a"))
b=float(input("digite la variable b"))
c=float(input("digite la variable c"))
primera=b*(-1)
segunda=(b**2)-(4*a*c)
tercera=segunda**0.5
cuarta=2*a
x=((primera+tercera)/cuarta)
y=((primera-tercera)/cuarta)
print("el resultado 1 es", round(x, 2))
print("el resultado 2 es", round(y, 2))
