#include<stdio.h>

int punto1(){
    char palabra[ 100 ];
    int i, num = 0;
   
    printf( "Ponga una palabra / frase: " );
    fgets(palabra, sizeof(palabra), stdin );

    for( i = 0; i < sizeof(palabra); i++ ){
    	if( palabra[ i ] == '\0' ){
    		break;
    	}
    	else if ( palabra[ i ] == ' ' ){
    		num=num;
    	}
    	else{
    		num++;
    	}
    }

    printf("\n");
    printf( "la palabra o frase tiene %d letras" ,num - 1 );
    printf("\n");
    return 0;
}
int punto2(){
	int i;
	char texto[ 1000 ];
	printf( "ponga el texto:\n");

	fgets( texto, sizeof(texto), stdin );
	for( i = 0; i < sizeof(texto); i++ ){
		if ( texto[ i ] == '\0' ){
    		break;
		}
	}

	texto[ 0 ] -= 32;
	texto[ 16 ] -= 32;
	texto[ 24 ] -= 32;

	printf( "\nParrafo con lo que se pide:\n" );
    printf("\n");
	for( i = 0; i < sizeof(texto); i++ ){
		if ( texto[ i ] == '\0' ){
    		break;
		}
		else{
			printf( "%c", texto[ i ] );
		}

	}
    printf("\n");
	return 0;
}
int punto3a(){
    int i, vecesvocal = 0;
    char texto[500], vocal;
    printf("\n ponga el texto: \n");
    fgets(texto, sizeof(texto), stdin);
    printf("\n ponga la vocal : \n");
    scanf("%s", &vocal);
    for(i = 0; i < sizeof(texto); i++){
        if(texto[i] == vocal){
            vecesvocal++;
        }
    }
    printf("\nLa vocal %c está %d veces en el texto\n", vocal, vecesvocal);
    return 0;
}
int punto3b(){
    int i;
    char texto[500], vocal;
    printf("\n ponga el texto: \n");
    fgets(texto, sizeof(texto), stdin);
    printf("\n ponga la vocal : \n");
    scanf("%s", &vocal);
    for(i = 0; i < sizeof(texto); i++){
        if (texto[i] == vocal){
            if (vocal == 'a'){
                vocal = 'A';
            }
            else if (vocal == 'e'){
                vocal = 'E';
            }
            else if (vocal == 'i'){
                vocal = 'I';
            }
            else if (vocal == 'o'){
                vocal = 'O';
            }
            else if (vocal == 'u'){
                vocal = 'U';
            }
            texto[i] = vocal;
        }
    }
    for(i = 0; i < sizeof(texto); i++){
        if(texto[i] == '\0'){
            break;
        }
        else{
            printf("%c", texto[i]);
        }    
    }    
    return 0;
}
int punto3c(){
    int i = 0;
    char texto[500], vocal, vocalnocambia;
    printf("\n ponga el texto: \n");
    fgets(texto, sizeof(texto), stdin);
    printf("\n ponga la vocal : \n");
    scanf("%s", &vocal);
    vocalnocambia = vocal;
    while(i < sizeof(texto)){
        if (texto[i] == vocal){
            if (vocal == 'a'){
                vocal = 'A';
            }
            else if (vocal == 'e'){
                vocal = 'E';
            }
            else if (vocal == 'i'){
                vocal = 'I';
            }
            else if (vocal == 'o'){
                vocal = 'O';
            }
            else if (vocal == 'u'){
                vocal = 'U';
            }
            texto[i] = vocal;
        }
        if (texto[i] == vocalnocambia){
            if (vocal == 'A'){
                vocal = 'a';
            }
            else if (vocal == 'E'){
                vocal = 'e';
            }
            else if (vocal == 'I'){
                vocal = 'i';
            }
            else if (vocal == 'O'){
                vocal = 'o';
            }
            else if (vocal == 'U'){
                vocal = 'u';
            }
        }
        i++;
    }
    for(i = 0; i < sizeof(texto); i++){
        if(texto[i] == '\0'){
            break;
        }
        else{
            printf("%c", texto[i]);
        }    
    }    
    return 0;
}
int punto4(){
    char texto[500];
    char textomodificado[500];
    int i, j = 0;

    printf("\nPonga el texto: ");
    fgets(texto, sizeof(texto), stdin);
    printf("\n");
    for(i = 0; i < sizeof(texto); i++){
        if(texto[i] != 'c' && texto[i+1] != 'a' && texto[i+2] != 'm' && texto[i+3] != 'a' && texto[i+4] != 'r' && texto[i+5] != 'a'){
            textomodificado[j] = texto[i];
            j++;
        }
    }
    for(i = 0; i < sizeof(textomodificado); i++){
        if(textomodificado[i] == '\0'){
            break;
        }
        else{
            printf("%c", textomodificado[i]);
        }    
    }
    printf("\n");
    return 0;
}

int main(){
    int numerousuario;
    printf("\nNúmero 1 para el punto 1\n");
    printf("\n");
    printf("Número 2 para el punto 2\n");
    printf("\n");
    printf("Número 3 para el punto 3a\n");
    printf("\n");
    printf("Número 4 para el punto 3b\n");
    printf("\n");
    printf("Número 5 para el punto 3c\n");
    printf("\n");
    printf("Número 6 para el punto 4\n");
    printf("\n");
    printf("Ingresa un número para entrar a ese punto del taller: ");
    scanf("%d", &numerousuario);
    printf("\n");
    printf("Para salir de este menú ingresa -1.\n");
    printf("\n");

    while(numerousuario != -1){
        if(numerousuario == 1){
            punto1();
        }
        if(numerousuario == 2){
            punto2();
        }
        if(numerousuario == 3){
            punto3a();
        }
        if(numerousuario == 4){
            punto3b();
        }
        if(numerousuario == 5){
            punto3c();
        }
        if(numerousuario == 6){
            punto4();
        }
        printf("\nRecuerda que puedes salir de este menu ingresando -1.\n");
        printf("\n");
        printf("Número 1 para el punto 1\n");
        printf("\n");
        printf("Número 2 para el punto 2\n");
        printf("\n");
        printf("Número 3 para el punto 3a\n");
        printf("\n");
        printf("Número 4 para el punto 3b\n");
        printf("\n");
        printf("Número 5 para el punto 3c\n");
        printf("\n");
        printf("Número 6 para el punto 4\n");
        printf("\n");
        printf("Ingresa un número para entrar a ese punto del taller: ");
        scanf("%d", &numerousuario);
        printf("\n");
    }        
}