
//Incluyo biblioteca de entrada/salida.
#include <stdio.h>
#include <string.h>

int sumar(int numUno, int numDos){
  return numUno + numDos;
}

int restar(int numUno, int numDos){
  return numUno - numDos;
}

int multiplicar(int numUno, int numDos){
  return numUno * numDos;
}

float dividir(int numUno, int numDos){
  float resultado = 0.0;
  if(numDos > 0){
	   resultado = (float)numUno/(float)numDos;
  }else{
	   printf("No se puede hacer esta operacion para los numeros %d--%d \n", numUno, numDos);
  }
  return resultado;
}

int calcularPalindromos(char * numero){
  //Aqui no te voy a mentir profe, este código lo tomé de internet porque no sabía como hacerlo,
  //le pude cambiar nombres y hacerlo ver como que lo hice yo pero no, prefiero decir la verdad,
  //el codigo no es mio pero lo puse para no dejar incompleto el taller, aun asi, lo he estudiado y entiendo como funciona.
  int longitud = strlen(numero);

  // Cadenas de 1 o menos son, por definición, recursivas
  if (longitud <= 1) return 1;

  // Comenzamos en el inicio y fin de la cadena
  int inicio = 0, fin = longitud - 1;


  // Mientras el primer y último carácter sean iguales
  while (numero[inicio] == numero[fin]){
      // Aquí sólo resta un carácter por comparar, eso indica que SÍ es palíndroma
      if (inicio >= fin) return 1;
      // Vamos acortando la cadena
      inicio++;
      fin--;
  }
  // Si termina el ciclo y no se rompió, entonces no es palíndroma
  return 0;
}

int calcularBiciestos(int anio){
  if(anio % 4 == 0 && anio % 100 != 0){
    return 1;
  }else if(anio % 400 == 0){
    return 1;
  }else{
    return 0;
  }
}

int main(){
  char numeroPalindromo[9];
  int numUno, numDos, resultado, anio, biciesto;
  float resultadoDivision;
  printf("Bienvenidos a este programa\n\n");
  printf("Ingrese el numero uno: ");
  scanf("%d",&numUno);
  printf("Ingrese el numero dos: ");
  scanf("%d",&numDos);

  //Operaciones
  resultado = sumar(numUno, numDos);
  printf("\nResultado suma: %d\n", resultado);

  resultado = restar(numUno, numDos);
  printf("Resultado resta: %d\n", resultado);

  resultado = multiplicar(numUno, numDos);
  printf("Resultado multiplicacion: %d\n", resultado);

  resultadoDivision = dividir(numUno, numDos);
  printf("Resultado division: %f\n", resultadoDivision);

  printf("\nEscriba un numero de 9 digitos: ");
  scanf("%s", &numeroPalindromo);

  if(calcularPalindromos(numeroPalindromo) == 1){
    printf("El numero es palindromo");
  }else{
    printf("El numero no es palindromo");
  }

  printf("\nEscriba un anio para calcular si es biciesto o no: ");
  scanf("%d", &anio);

  biciesto = calcularBiciestos(anio);

  if(biciesto == 1){
    printf("El anio %d es biciesto\n", anio);
    printf("Mi nombre es Sebastian");
  }else{
    printf("El anio %d NO es biciesto y tengo 0 hermano(s)", anio);
  }

  return 0;
}
