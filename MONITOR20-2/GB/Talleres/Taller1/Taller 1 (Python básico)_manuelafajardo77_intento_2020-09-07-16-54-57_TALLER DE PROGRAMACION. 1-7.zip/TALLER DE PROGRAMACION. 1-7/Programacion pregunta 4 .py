a = float (input ("Por favor digite el valor de la base del rectangulo:"))
b = float (input ("Por favor digite el valor de la altura del rectangulo:"))
Area = (a*b)
Perimetro = (a+b+a+b)

print ("El area del rectangulo es:",Area)
print ("El perimetro del Rectangulo es:",Perimetro)
