base= float(input("por favor digite la base del rectangulo: "))
altura= float(input("por favor digite la altura del rectangulo: "))

area= base*altura
perimetro= base+base+altura+altura

print("el area con base",base,"*",altura," es: ", area)
print("el perimetro con base y altura",base,"+",base,"+",altura,"+",altura," es: ", perimetro)
