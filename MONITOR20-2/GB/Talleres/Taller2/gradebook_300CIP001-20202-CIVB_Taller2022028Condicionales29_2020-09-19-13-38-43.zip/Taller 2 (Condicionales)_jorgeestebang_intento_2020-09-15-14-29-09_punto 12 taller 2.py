A=int(input("digite el numero de personas que van a ingresar: "))
B=input("digite la temporada en la qeu se encuentra: ")
C=input("digite el numero de atracciones que desea:")
precio1= 22000
precio2= 49000
precio3= 20000
precio4= 45000
if C=="todas" and B=="alta":
    if A==1:
        print("el precio base es de: ",precio2*A)
        print("mas el valor del seguro, en total serian: ", precio2*A+(precio2*0.06))
    else:
        print("el precio base es de: ",precio2*A)
        print("mas el valor del seguro, en total serian: ", precio2*A+(precio2*0.06*A))
        
if C=="8" and B=="alta":
    if A==1:
        print("el precio base es de: ",precio1*A)
        print("el valor de las entradas es de: ", precio1*A+(precio1*0.06))
    else:
        print("el precio base es de: ",precio1*A)
        print("mas el valor del seguro, en total serian: ", precio1*A+(precio1*0.06*A))
        
if C=="todas" and B=="baja":
    if A==1:
        print("el precio base es de: ",precio4*A)
        print("el valor de las entradas es de: ", precio4*A+(precio4*0.06))
    else:
        print("el precio base es de: ",precio4*A)
        print("mas el valor del seguro, en total serian: ", precio4*A+(precio4*0.06*A))

if C=="8" and B=="baja":
    if A==1:
        print("el precio base es de: ",precio3*A)
        print("el valor de las entradas es de: ", precio3*A+(precio3*0.06))
    else:
        print("el precio base es de: ",precio3*A)
        print("mas el valor del seguro, en total serian: ", precio3*A+(precio3*0.06*A)) 


         
