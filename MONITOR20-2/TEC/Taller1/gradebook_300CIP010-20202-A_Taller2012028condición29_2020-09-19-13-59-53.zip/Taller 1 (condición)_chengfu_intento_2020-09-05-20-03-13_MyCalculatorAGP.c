
//Inclunumero2o biblioteca de entrada/salida.
#include <stdio.h>


//Punto 4.1------------------------------------------
void verificarPalindromo(int numeroP) {
  int aux=numeroP , palindromo=0, potencia=100000000;
  for (int i = 0 ; i < 8 ; i++) {
    palindromo += (aux%10)*potencia;
    potencia = potencia/10;
    aux = (aux-aux%10)/(10);
  }
  palindromo+=aux;
  if ((palindromo-numeroP)==0) {
    printf("El numero es palindromo \n");
  }
  else{
    printf("El numero no es palindromo \n");
  }

  return;
}
//Punto 4.1------------------------------------------
//Punto 4.2------------------------------------------
int verificarBisiesto(int year){
  if((year%4 == 0) && (!(year%100==0)) ){
    return 1;
  }
  if ((year%400 == 0)) {
    return 1;
  }
  else{
    return 0;
  }
}
//Punto 4.2------------------------------------------

int sumarNumeros(int numero1, int numero2){
  return numero1+numero2;
}
int restarNumeros(int numero1, int numero2){
  return numero1-numero2;
}
int multiplicarNumeros(int numero1, int numero2){
  return numero1*numero2;
}
float dividirNumeros(int numero1, int numero2){
  float result=0.0;
  if(numero2>0){
	result= (float)numero1/ (float)numero2;
  }else{
	printf("No se puede hacer esta operacion para los numeros %d--%d \n", numero1,numero2);
  }
  return result;
}

int main(){
  int numero1,numero2,resultado_entero,numeroP,year,bisiesto;
  float resultado_flotante;
  printf("Bienvenidos a este programa \n");
  printf("Ingrese el num uno \n");
  scanf("%d",&numero1);
  printf("Ingrese el num dos \n");
  scanf("%d",&numero2);
 //palindromo
 printf("Ingrese el num de verificacion palindromo \n");
 scanf("%d",&numeroP);
 verificarPalindromo(numeroP);

  //Operaciones
  resultado_entero=sumarNumeros(numero1,numero2);
  printf("Resultado de la suma : %d \n", resultado_entero);

   resultado_entero=restarNumeros(numero1,numero2);
  printf("Resultado de la resta:%d \n", resultado_entero);

   resultado_entero=multiplicarNumeros(numero1,numero2);
  printf("Resultado de la multiplicacion: %d \n", resultado_entero);

   resultado_flotante=dividirNumeros(numero1,numero2);
  printf("Resultado de la division: %f \n", resultado_flotante);
  // anio bisiesto
  printf("Ingrese el anio \n");
  scanf("%d",&year);
  bisiesto=verificarBisiesto(year);

  if(bisiesto){
    printf("El anio %d es bisiesto y mi nombre es %s \n",year,"Alejandro");
  }
 else{
   printf("El anio %d no es bisiesto y tengo %d hermano(s) \n",year,1);
 }
  return 0;

}
