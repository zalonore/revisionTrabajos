#include <stdio.h>
#define CAP 500

int contarCaracteres(char * cadena){
	int i = 0, contador = 0;
	while (cadena[i] != '\0'){
		i++;
	}
	return i - 1;
}

void cambiarMayuscula(char * oracion){
	oracion[0]='E';
	oracion[16]='G';
	oracion[24]='G';
	return;
}

void cambiarVocales(char * oracion, char * h){
	int i, j = 2;
	for (i = 0; i < CAP; ++i){
		if ((oracion[i] == 'a' || oracion[i] == 'A') && (h[0] == 'a' || h[0] == 'A')){
			if(j % 2 == 0){
				oracion[i]='A';
				j++;
			}
			else{
				oracion[i]='a';
				j++;
			}
		}
		if ((oracion[i] == 'e' || oracion[i] == 'E') && (h[0] == 'e' || h[0] == 'E')){
			if(j % 2 == 0){
				oracion[i]='E';
				j++;
			}
			else{
				oracion[i]='e';
				j++;
			}
		}
		if ((oracion[i] == 'i' || oracion[i] == 'I') && (h[0] == 'i' || h[0] == 'I')){
			if(j % 2 == 0){
				oracion[i]='I';
				j++;
			}
			else{
				oracion[i]='i';
				j++;
			}
		}
		if ((oracion[i] == 'o' || oracion[i] == 'O') && (h[0] == 'o' || h[0] == 'O')){
			if(j % 2 == 0){
				oracion[i]='O';
				j++;
			}
			else{
				oracion[i]='o';
				j++;
			}
		}
		if ((oracion[i] == 'u' || oracion[i] == 'U') && (h[0] == 'u' || h[0] == 'U')){
			if(j % 2 == 0){
				oracion[i]='U';
				j++;
			}
			else{
				oracion[i]='u';
				j++;
			}
		}	
	}
	return;
}

void cambiarCamara(char * oracion, char * nueva){
	int i, j = 0;
	for (i = 0; i < CAP; ++i){
		if (oracion[i] == 'c' && oracion[i+1] == 'a' && oracion[i+2] == 'm' && oracion[i+3] == 'a' && oracion[i+4] == 'r' && oracion[i+5] == 'a'){
			i+=6;
		}
		else{
			nueva[j] = oracion[i];
			j++;
		}
	}
	return;
}


void menu(){
  	printf( "MENU\n"
            "=====\n"
            "1. Punto 1\n"
            "2. Punto 2\n"
            "3. Punto 3\n"
            "4. Punto 4\n"
            "0. Salir\n"
        	"Ingrese la opcion: ");
	return;
}

int main(){
	int v;
	char h[2], nueva[CAP], cadena[CAP], oracion[CAP] = "en un comienzo, gabriel garcia Marquez penso en titular su novela La Casa, pero se decidio por Cien anios de soledad para evitar confusiones con la novela La Casa Grande, publicada en 1954 por su amigo, Alvaro Cepeda Samudio";; 
	char oracion2[CAP]="Mi profe consiguio una camara vieja antes de la pandemia, pero como ahora es un profe digital, el profe se consiguio una camara nueva mas bonita. Pasado el tiempo se dio cuenta que la camara nueva aunque bonita era una camara mala, pero que bobada, al fin y al cabo, ya sea con una camara vieja o una camara nueva, nunca la muestra en clase.";
	do{
		menu();
		scanf("%d", &v);
		switch(v){
			case 1:
				printf("Ingrese la cadena: ");
				getchar();
				fgets(cadena,CAP,stdin);
				printf("Tiene %d caracteres\n", contarCaracteres(cadena));
				break;
			case 2:
				cambiarMayuscula(oracion);
				printf("%s\n", oracion);
				break;
			case 3:
				printf("Ingrese la vocal: ");
				getchar();
				fgets(h,2,stdin);
				printf("%s\n", h);
				cambiarVocales(oracion, h);
				printf("%s\n", oracion);
				break;
			case 4:
				cambiarCamara(oracion2, nueva);
				printf("%s\n", nueva);
				break;
		}
	} while (v != 0);	
	return 0;
}