numero1=int(input("digite su numero 1: "))
numero2=int(input("digite su numero 2: "))
numero3=int(input("digite su numero 3: "))

numero1=numero1>0
numero2=numero2>0
numero3=numero3>0

if (numero1==numero2==numero3):
    triangulo=("equilatero")
    print("es triangulo",triangulo)
elif (numero1==numero2 or numero2==numero3 or numero1==numero3):
    triangulo=("isoceles")
    print("es triangulo",triangulo)
elif (numero1!=numero2!=numero3):
    triangulo=("escaleno")
    print("es triangulo",triangulo)
else:
    print("no es triangulo")
    



