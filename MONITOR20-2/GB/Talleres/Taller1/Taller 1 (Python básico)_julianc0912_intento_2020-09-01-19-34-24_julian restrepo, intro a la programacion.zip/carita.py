print(" \ | / ")
print("  @ @ ")
print("\ ''' / ")
