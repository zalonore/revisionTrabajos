# Calculadora
numero_1 = int(input ( "escribe un numero: " ))
numero_2 = int(input ( "escribe un numero: " ))
suma = numero_1 + numero_2
resta = numero_1 - numero_2
multiplicacion = numero_1 * numero_2
division = numero_1 / numero_2
potencia=numero_1**2,numero_2**2
print(f"la suma es {suma}, la resta es {resta}, la division es {division}, la multiplicacion es {multiplicacion}, la potencia es {potencia}" )
