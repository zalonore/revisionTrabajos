primernumero=float(input("por favor digite el prmer digito:"))
segundonumero =float(input("porfavor digite el segundo numero:"))
suma=(primernumero+segundonumero)
resta=(primernumero-segundonumero)
multiplicacion=(primernumero*segundonumero)
division=(primernumero /segundonumero)
potencia=((primernumero)**segundonumero)

print("cuando se suma",suma," ,cuando se restan es ",resta,", cuando se multiplica es",multiplicacion,", cuando se divide es",division," y cuando se potencian es",potencia,"")

