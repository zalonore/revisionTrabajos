print("ejercicio 10")
dinero=int(input("cuanto dinero necesita parcero"))
if dinero <=300000 and dinero>=1000:
    am= (dinero-dinero%10000)//10000
    dinero= dinero%10000
    bm= (dinero-dinero%5000)//5000
    dinero=dinero%5000
    cm= (dinero-dinero%2000)//2000
    dinero=dinero%2000
    dm= (dinero-dinero%1000)//1000
    print(("dar",am,"billetes de 10000",
           "dar",bm,"billetes de 5000",
           "dar",cm,"billetes de 2000",
           "dar",dm,"billetes de 1000"))
else: print("pana no sea descarado dejele a los otros")
