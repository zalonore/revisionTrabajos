//Incluyo biblioteca de entrada/salida.
#include <stdio.h>

int sumarNumeros(int num1, int num2){
  return num1+num2;
}
int restarNumeros(int num1, int num2){
  return num1-num2;
}
int multiplicarNumeros(int num1, int num2){
  return num1*num2;
}
float dividirNumeros(int num1, int num2){
  float result=0.0;
  if(num2>0){
	result= (float)num1/ (float)num2;
  }else{
	printf("No se puede hacer esta operacion para los numeros %d--%d \n", num1,num2);
  }
  return result;
}
//Funcion para el palindromo
int revisarPalindromo(int numPalindromo){
  int multiplicar=100000000,check=0,value=numPalindromo;
  while(value!=0){//Se revisa si el numero ingresado es de 9 digitos
    value/=10;
    ++check;
  }
  if(check==9){
    check=0;
    value=numPalindromo;
  while (numPalindromo!=0){
    check+=numPalindromo%10*multiplicar;//Se adquiere el ultimo digito del numero y se multiplica por la variable multiplicar
    numPalindromo/=10;//Se elimina el ultimo digito del numero ingresado
    multiplicar/=10;//Se reduce la variable multiplicar dividiendola por 10
  }
  //Se imprime "es palindromo" o "no es palindromo"dependiendo si el numro ingresado es igual al numero adquirido antriormente
  if(value==check)printf("%d es palindromo\n",value);
  else printf("%d no es palindromo\n",value);
  }else printf("El numero ingresado es de %d digitos\n",check);
  
}
//Funcion para el anio
void revisarAnio(int anio){
  if((anio%4==0)&&!(anio%100==0)){//Se verifica si el numero es multiplo de 4 pero no lo es de 100
    printf("El anio %d es bisiesto \nMi nombre es %s",anio,"SEBASTIAN CAMACHO");    
  }else{
    printf("El anio %d no es bisiesto y tengo %d hemanos",anio,0);
  }
}

int main(){
  int num1,num2,numPalindromo,result,anio;
  float resultDivision;

  printf("Bienvenidos a este programa \n");
  printf("Ingrese el num uno \n");
  scanf("%d",&num1);
  printf("Ingrese el num dos \n");
  scanf("%d",&num2);
  
  //Operaciones
  result=sumarNumeros(num1,num2);
  printf("Resultado suma %d \n", result);
  
   result=restarNumeros(num1,num2);
  printf("Resultado resta %d \n", result);
  
   result=multiplicarNumeros(num1,num2);
  printf("Resultado multiplicacion %d \n", result);
  
   resultDivision=dividirNumeros(num1,num2);
  printf("Resultado division %f \n", resultDivision);
  
  //Opeacion para verificar si es palindromo
  printf("Ingrese un numero de 9 digitos\n");
  scanf("%d",&numPalindromo);
  result=revisarPalindromo(numPalindromo);

  //Operacion para el anio bisiesto
  printf("Ingrese el anio\n");
  scanf("%d",&anio);
  revisarAnio(anio);

  return 0;

}