//Incluyo biblioteca de entrada/salida.
#include <stdio.h>
//sumarNumeros
int sumar(int numero1, int numero2){
  return numero1+numero2;
}
//restarNumeros
int restar(int numero1, int numero2){
  return numero1-numero2;
}
//multiplicarNumeros
int multiplicar(int numero1, int numero2){
  return numero1*numero2;
}
//dividirNumeros
float dividir(int numero1, int numero2){
  float result=0.0; //resultadoDivision
  if(numero2>0){
  result= (float)numero1/ (float)numero2;
  }else{
  printf("No se puede hacer esta operacion para los numeros %d--%d \n", numero1,numero2);
  }
  return result;
}
//verificarAñoBisiesto
void bisiesto(int ano){
  if(((ano%4)==0 && (ano%100)!=0) || ((ano%400)==0)) {
    printf("el ano %d es bisiesto y mi nombre es Miguel Angel\n", ano);
  }
  else{
    printf("el ano %d no es bisiesto y tengo 1 hermano\n", ano);
  }
}
//verificarNumeroPalindromo
void palindromo(int numero3){
  int invertir=0, ultimoDigito, numeroOriginal=numero3;
  while(numero3>0){
    ultimoDigito=numero3%10;
    numero3 /= 10;
    invertir=(invertir*10)+ultimoDigito;
  }
  if(numeroOriginal==invertir){
    printf("el numero %d es palindromo\n", numeroOriginal);
  }
  else{
    printf("el numero %d no es palindromo\n", numeroOriginal);
  }
}
//funcionMain
int main(){
  int numero1,numero2,numero3=0,ano,resultado; //numerosYResultado
  float resultadoDivision; //resultadoDivision
  printf("Bienvenidos a este programa \n");
  printf("Ingrese el primer numero \n"); //pedirNumero
  scanf("%d",&numero1); //leerNumero
  printf("Ingrese el segundo numero \n"); //pedirNumero
  scanf("%d",&numero2); //leerNumero
  while( numero3<100000000 || numero3>999999999 ){
    printf("Ingrese un numero de 9 digitos: \n"); //pedir numero
    scanf("%d",&numero3); //leerNumero
  }
  printf("Ingrese un ano: \n"); //pedirAño
  scanf("%d", &ano); //leerAño
  //Operaciones
  resultado=sumar(numero1,numero2);
  printf("Resultado de la suma es: %d \n", resultado);
  
  resultado=restar(numero1,numero2);
  printf("Resultado de la resta es: %d \n", resultado);
  
  resultado=multiplicar(numero1,numero2);
  printf("Resultado de la multiplicacion es: %d \n", resultado);
  
  resultadoDivision=dividir(numero1,numero2);
  printf("Resultado de la division es: %f \n", resultadoDivision);

  bisiesto(ano);
  palindromo(numero3);
  
  return 0;
}