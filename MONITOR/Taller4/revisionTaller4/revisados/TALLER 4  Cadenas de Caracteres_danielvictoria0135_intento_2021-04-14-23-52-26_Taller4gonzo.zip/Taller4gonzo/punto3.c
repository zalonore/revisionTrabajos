#include <stdio.h>
int punto1(){
    int i, vecesvocal = 0;
    char texto[500], vocal;
    printf("\n ponga el texto: \n");
    fgets(texto, sizeof(texto), stdin);
    printf("\n ponga la vocal : \n");
    scanf("%s", &vocal);
    for(i = 0; i < sizeof(texto); i++){
        if(texto[i] == vocal){
            vecesvocal++;
        }
    }
    printf("\nLa vocal %c está %d veces en el texto\n", vocal, vecesvocal);
    return 0;
}
int punto2(){
    int i;
    char texto[500], vocal;
    printf("\n ponga el texto: \n");
    fgets(texto, sizeof(texto), stdin);
    printf("\n ponga la vocal : \n");
    scanf("%s", &vocal);
    for(i = 0; i < sizeof(texto); i++){
        if (texto[i] == vocal){
            if (vocal == 'a'){
                vocal = 'A';
            }
            else if (vocal == 'e'){
                vocal = 'E';
            }
            else if (vocal == 'i'){
                vocal = 'I';
            }
            else if (vocal == 'o'){
                vocal = 'O';
            }
            else if (vocal == 'u'){
                vocal = 'U';
            }
            texto[i] = vocal;
        }
    }
    for(i = 0; i < sizeof(texto); i++){
        if(texto[i] == '\0'){
            break;
        }
        else{
            printf("%c", texto[i]);
        }    
    }    
    return 0;
}
int punto3(){
    int i = 0;
    char texto[500], vocal, vocalnocambia;
    printf("\n ponga el texto: \n");
    fgets(texto, sizeof(texto), stdin);
    printf("\n ponga la vocal : \n");
    scanf("%s", &vocal);
    vocalnocambia = vocal;
    while(i < sizeof(texto)){
        if (texto[i] == vocal){
            if (vocal == 'a'){
                vocal = 'A';
            }
            else if (vocal == 'e'){
                vocal = 'E';
            }
            else if (vocal == 'i'){
                vocal = 'I';
            }
            else if (vocal == 'o'){
                vocal = 'O';
            }
            else if (vocal == 'u'){
                vocal = 'U';
            }
            texto[i] = vocal;
        }
        if (texto[i] == vocalnocambia){
            if (vocal == 'A'){
                vocal = 'a';
            }
            else if (vocal == 'E'){
                vocal = 'e';
            }
            else if (vocal == 'I'){
                vocal = 'i';
            }
            else if (vocal == 'O'){
                vocal = 'o';
            }
            else if (vocal == 'U'){
                vocal = 'u';
            }
        }
        i++;
    }
    for(i = 0; i < sizeof(texto); i++){
        if(texto[i] == '\0'){
            break;
        }
        else{
            printf("%c", texto[i]);
        }    
    }    
    return 0;
}

int main(){
    printf("\n PUNTO 3.1\n")
    punto1();
    printf("\n PUNTO 3.2\n")
    punto2();
    printf("\n PUNTO 3.3\n")
    punto3();
    return 0;
}
