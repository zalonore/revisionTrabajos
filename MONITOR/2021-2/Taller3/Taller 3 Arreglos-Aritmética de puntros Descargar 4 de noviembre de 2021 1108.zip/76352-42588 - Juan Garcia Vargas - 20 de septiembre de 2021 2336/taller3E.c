#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#define VALOR 20


int funcionUno(){
   int arrayA[VALOR] = {1,2,3,4,5,6,7,8,9,10,12,13,14,15,16,17,18,19,20};
   int arrayB[VALOR] = {2,4,6,7,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40};
   int arrayC[VALOR] = {0,50,36,70,67,24,70,24,43,12,2,32,6,4,70,21,0,13,55,22};
   int arrayD[VALOR], arrayE[VALOR],i,j,k,cont = 0,comi = 0;
   printf("arreglo A : ");
   for(i = 0; i < 20; i++){
      printf("%d ",arrayA[i]);
   }
   printf("\n");
   printf("arreglo B : ");
   for(i = 0; i < 20; i++){
      printf("%d ",arrayB[i]);
   }
   printf("\n");
   printf("arreglo C : ");
   for(i = 0; i < 20; i++){
      printf("%d ",arrayC[i]);
   }
   int n = sizeof(arrayA) / sizeof(int);
   printf("\n");
   for(i = 0; i < n; i++){
      for(j = 0; j < n; j++){
         if(arrayA[i] == arrayB[j]){
            int vale = 0;
            //arrayD[i] = arrayA[i];
            for( k = 0; k < cont ; k++){
               if(arrayA[i] == arrayD[k]){
                  vale = 1;
                  break;
               }
            }
            if(!vale){
               arrayD[cont++] = arrayA[i];
            }
            break;
         }

      } 

   }

   for(i = 0; i < cont; i++){
      for(j = 0; j < n; j++){
         if(arrayD[i] == arrayC[j]){
            int vale = 0;
            //arrayD[i] = arrayA[i];
            for( k = 0; k < comi ; k++){
               if(arrayD[i] == arrayE[k]){
                  vale = 1;
                  break;
               }
            }
            if(!vale){
               arrayE[cont++] = arrayD[i];
            }
            break;
         }

      } 

   }
   for(i = 0; i < cont; i++){
      printf("%d ", arrayE[i]);
   }
   printf("\n");


    
}



int main(){

   funcionUno();
}
