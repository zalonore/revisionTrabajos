x = int(input("Digite el primer nùmero:"))
y = int(input("Digite el segundo nùmero:"))
division = x % y
if(division == 0):
 print ("True")
else:
  print("False")
