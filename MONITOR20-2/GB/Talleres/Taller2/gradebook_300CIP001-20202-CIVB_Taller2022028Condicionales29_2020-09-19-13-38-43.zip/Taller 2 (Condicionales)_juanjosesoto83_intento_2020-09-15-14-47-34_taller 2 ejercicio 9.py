print("ejercicio 9")
ventastotales=int(input("ventas totales= "))
ventamedicamento=int(input("numero de ventas de medicamentos del vendedor= "))
ventaaseo=int(input("numero de ventas de aseo del vendedor= "))
ganancia1= ventamedicamento *0.09
ganancia2= ventaaseo * 0.13
gananciatotal= 200+ganancia1+ganancia2
print("las ganancias del vendedro son", gananciatotal)
