print("Para encontrar X teniendo en cuenta la formula cuadratica ingrese el valor de a, de b y de c")
a = float(input("Ingrese el valor de a: "))
b = float(input("Ingrese el valor de b: "))
c = float(input("Ingrese el valor de c: "))

discriminante = b ** 2 - 4 * a * c
if discriminante < 0:
    print ("La ecuacion no tiene soluciones reales")
if discriminante == 0:
    x = -b / (2 * a)
    print ("La ecuacion solo tiene una solucion que es x=", x)
else:
    x1 = (-b + (discriminante ** 0.5)) / (2 * a)
    x2 = (-b - (discriminante ** 0.5)) / (2 * a)
    print ("Las dos soluciones son:")
    print ("x1 =", x1)
    print ("x2 =", x2)