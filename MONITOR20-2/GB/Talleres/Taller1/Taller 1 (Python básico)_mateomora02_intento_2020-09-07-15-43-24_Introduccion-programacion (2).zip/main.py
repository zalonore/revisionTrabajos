print ("\  |  /")
print ("  @ @  ")
print ("\ ''' /")



Numero1 = int(input("Digite el primer numero:"))
Numero2 = int(input("Digite el segundo numero:"))
Suma = Numero1 + Numero2
Resta = Numero1 - Numero2
Multiplicacion = Numero1 * Numero2
Division= Numero1 / Numero2
Potencia = Numero1 ** Numero2
print ("El resultado de la suma es:", Suma)
print ("El resultado de la resta es:", Resta)
print ("El resultado de la multiplicacion es:", Multiplicacion)
print ("El resultado de la division es:", round (Division, 2))
print ("El resultado de la potencia es:", round (Potencia, 3))



r = float(input("Digite el valor deseado de r:"))
Pi = float(input("Digite el valor desado para pi:"))
Potencia = int(input("Digite el valor de la potencia necesaria:"))
r2 = r**Potencia
print ("El valor de r a la potencia es:",round (r2,2))
a = Pi*r2
print ("El valor del area de este circulo es:", round (a,2))



b = int(input("Digite el valor de la base del rectangulo:"))
h = int(input("Digite el valor de la altura del rectangulo:"))
a = b*h
print ("El area del rectangulo es:", a)
l1 = int(input("Digite el valor del primer lado:"))
l2 = int(input("Digite el valor del segundo lado:"))
p = 2*(l1+l2)
print ("El perimetro del rectangulo es:", p)



a = int(input("Digite el valor del primer numero:"))
b = int(input("Digite el valor del segundo numero:"))
c = int(input("Digite el valor del tercer numero:"))
Variable1 = 4
Variable2 = 2
Potencia = 2
VariableEcuacion = -b
ResultadoPotencia = b**Potencia
print ("El resultado de la potencia de b es:", ResultadoPotencia)
ResultadoMultiplicacion1 = Variable1*a*c
print("El resultado de la primera multiplicacion es:", ResultadoMultiplicacion1)
ResultadoResta = ResultadoPotencia - ResultadoMultiplicacion1
print ("El resultado de la resta es:", ResultadoResta)
ResultadoRaiz = (ResultadoResta**(.5))
print ("El resultado de la raiz:", round (ResultadoRaiz,2))
ResultadoEcuacion1 = VariableEcuacion - ResultadoRaiz
print ("El resultado de la ecuacion 1:", round (ResultadoEcuacion1, 2))
ResultadoMultiplicacion2 = Variable2*a
print ("El resultado de la segunda Multiplicacion es:", ResultadoMultiplicacion2)
ResultadoDivision = ResultadoEcuacion1 / ResultadoMultiplicacion2
print ("El resultado para X1 es igual a:", round (ResultadoDivision,2))

Variable1 = 4
Variable2 = 2
Potencia = 2
VariableEcuacion = -b
ResultadoPotencia = b**Potencia
print ("El resultado de la potencia de b es:", ResultadoPotencia)
ResultadoMultiplicacion1 = Variable1*a*c
print("El resultado de la primera multiplicacion es:", ResultadoMultiplicacion1)
ResultadoResta = ResultadoPotencia - ResultadoMultiplicacion1
print ("El resultado de la resta es:", ResultadoResta)
ResultadoRaiz = (ResultadoResta**(.5))
print ("El resultado de la raiz:", round (ResultadoRaiz,2))
ResultadoEcuacion1 = VariableEcuacion + ResultadoRaiz
print ("El resultado de la ecuacion 1:", round (ResultadoEcuacion1, 2))
ResultadoMultiplicacion2 = Variable2*a
print ("El resultado de la segunda Multiplicacion es:", ResultadoMultiplicacion2)
ResultadoDivision = ResultadoEcuacion1 / ResultadoMultiplicacion2
print ("El resultado para X2 es igual a:", round (ResultadoDivision,2))



a = int(input("Digite un numero de cuatro digitos:"))
b1 = a %10
b2 = a // 10
c1 = b2 % 10
c2 = b2 // 10 
d1 = c2 % 10
d2 = c2 // 10
e1 = d2 % 10
e2 = d2 // 10
print ("El inverso del numero ingresado es:",b1,c1,d1,e1)



a = int(input("Ingrese el valor deseado para esta variable:"))
b = str(input("Ingrese la palabra deseada:"))
NuevoA = b
NuevaB = a
print ("El valor de X es:", NuevoA)
print ("El valor de Y es:", NuevaB)