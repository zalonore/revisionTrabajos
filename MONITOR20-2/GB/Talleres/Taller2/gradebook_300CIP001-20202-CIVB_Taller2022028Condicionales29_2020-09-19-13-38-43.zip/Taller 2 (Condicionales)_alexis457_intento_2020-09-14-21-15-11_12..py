cantidad_personas=int(input("digite la cantidad de personas: "))
temporada=int(input("digite 1 si es temporada baja o digite 2 si es temporada alta: "))
cantidad_atracciones=int(input("digite la cantidad de atracciones que desea disfrutar: "))

if cantidad_atracciones<=8 and temporada==1:
    personas=cantidad_personas*22000 
    valor_total_con_seguro= personas*0.06
    total=valor_total_con_seguro+personas
    print("el valor base es de: ",personas)
    print("el valor total a pagar con seguro incluido es de: ",total)
if cantidad_atracciones<=8 and temporada==2:
    personas=cantidad_personas*20000 
    valor_total_con_seguro= personas*0.06
    total=valor_total_con_seguro+personas
    print("el valor base es de: ",personas) 
    print("el valor total a pagar con seguro incluido es de: ",total)
if cantidad_atracciones>8 and temporada==1:
    personas=cantidad_personas*49000 
    valor_total_con_seguro= personas*0.06
    total=valor_total_con_seguro+personas
    print("el valor base es de: ",personas)
    print("el valor total a pagar con seguro incluido es de: ",total)
if cantidad_atracciones>8 and temporada==2:
    personas=cantidad_personas*45000 
    valor_total_con_seguro= personas*0.06
    total=valor_total_con_seguro+personas
    print("el valor base es de: ",personas) 
    print("el valor total a pagar con seguro incluido es de: ",total)