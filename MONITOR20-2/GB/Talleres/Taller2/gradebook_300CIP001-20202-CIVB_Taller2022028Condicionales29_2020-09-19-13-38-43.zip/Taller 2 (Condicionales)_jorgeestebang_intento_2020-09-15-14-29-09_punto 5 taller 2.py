numero=input("ingresa tu numero de mes :")

if numero =="1" :
    mes=31
    print("su mes tiene:",mes)
elif numero=="2":
    mes=28
    print("su mes tiene:",mes)
elif numero=="3":
    mes=31
    print("su mes tiene:",mes)
elif numero=="4":
    mes=30
    print("su mes tiene:",mes)
elif numero=="5":
    mes=31
    print("su mes tiene:",mes)
elif numero=="6":
    mes=30
    print("su mes tiene:",mes)
elif numero=="7":
    mes=31
    print("su mes tiene:",mes)
elif numero=="8":
    mes=31
    print("su mes tiene:",mes)
elif numero=="9":
    mes=30
    print("su mes tiene:",mes)
elif numero=="10":
    mes=31
    print("su mes tiene:",mes)
elif numero=="11":
    mes=30
    print("su mes tiene:",mes)
elif numero=="12":
    mes=31
    print("su mes tiene:",mes)

else:
    print("numero de mes no encontrado")
