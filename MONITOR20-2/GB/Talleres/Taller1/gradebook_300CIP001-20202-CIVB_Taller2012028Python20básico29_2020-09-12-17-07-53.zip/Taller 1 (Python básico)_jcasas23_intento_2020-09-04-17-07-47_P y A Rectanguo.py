base = int (input ("Ingrese la base del rectangulo: "))
altura = int (input ("Ingrese la altura del rectangulo: "))

P = (base*2) + (altura*2)
A = base*altura

print ("El Perímetro de su rectángulo es: ",P)
print ("El Área de su rectángulo es: ",A)
# Jorge Casas
