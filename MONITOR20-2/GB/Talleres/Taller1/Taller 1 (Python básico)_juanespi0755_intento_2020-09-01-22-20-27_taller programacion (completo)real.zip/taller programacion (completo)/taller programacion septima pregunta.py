x=int(input("digite su primera variable:"))
y=(input("digite su segunda variable:"))
nuevox= y
nuevoy=x
print("el nuevo valor de x",nuevox)
print("el nuevo valor de y",nuevoy)
