x=float(input("digite la medida del lado 1:"))
y=float(input("digite la medida del lado 2:"))
z=float(input("digite la medida del lado 3:"))
if  (x>0 and y>0 and z>0) and  (x+y>z or x+z>y or y+z>x):
    print("usted tiene un triangulo")

    if x==y and x==z and z==y:
        print("ademas es equilatero")
    
    elif x==y or x==z or z==y:
        print("y ademas es isósceles ")

    else:
        print("y ademas es escaleno")
        
else:
    print("con respecto a sus medidas, usted no tiene un triangulo")
