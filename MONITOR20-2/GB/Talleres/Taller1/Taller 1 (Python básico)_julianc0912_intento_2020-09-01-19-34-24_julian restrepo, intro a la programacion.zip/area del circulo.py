a=float(input("digite el radio del circulo"))
pi=3.1416
area=pi*(a**2)
print("el area del circulo es", area)
