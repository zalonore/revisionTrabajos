a = int (input ("Ingrese su variable a: "))
b = int (input ("Ingrese su variable b: "))
c = int (input ("Ingrese su variable c: "))

unox = (-b +sqrt(b**2-(4*a*c)))/(2*a)
dosx = (-b -sqrt(b**2-(4*a*c)))/(2*a)

print ("Tu resultado en la ecuación es: ",unox "; ",dosx)
# Jorge Casas
