#include <stdio.h>
#define CAP 250

int main(){
	int i, cont = 0, b = 0, m = 1, acum = 0, acum2 = 0;
	char cadena[ CAP ], l;
	printf( "Digite la oracion:\n");

	fgets( cadena, CAP, stdin );
	for( i = 0; i < CAP; i++ ){
    	if( cadena[ i ] == '\0' ){
    		break;
    	}else{
    		acum++;
    	}
    }

	printf( "Digite la vocal minuscula a buscar:\n" );
	scanf( "%c", &l );

	for( i = 0; i < acum; i++ ){
		if( (cadena[ i ] == l) || ( cadena[ i ] == l - 32 ) ){
			cont++;
		}
	}
	printf( "La vocal ingresada esta %d veces en la oracion\n", cont );

	printf( "\n" );

	for( i = 0; i < acum; i++ ){
		if( (cadena[ i ] == l) && ( b == 0 ) ){
			cadena[ i ] -= 32;
			b = 1;
		}
	}
	printf( "Oracion cambiada:\n" );
	puts(  cadena );

	getchar();
	printf( "Digite la oracion en minusculas:\n");

	fgets( cadena, CAP, stdin );
	for( i = 0; i < CAP; i++ ){
    	if( cadena[ i ] == '\0' ){
    		break;
    	}else{
    		acum2++;
    	}
    }

	printf( "Digite la vocal minuscula:\n" );
	scanf( "%c", &l );

	for( i = 0; i < acum2; i++ ){
		if( cadena[ i ] == l ){
			if( m % 2 != 0 ){
				cadena[ i ] -= 32;
				m++;
			}else{
				m++;
			}	
		}
	}
	printf( "Oracion con letras intercambiadas:\n" );
	puts( cadena );
	return 0;
}