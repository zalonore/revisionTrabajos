a = int(input("Ingrese primer valor:"))
b = int(input("Ingrese segundo valor:"))
r1 = (a % 2 ==0)
r2 = (b % 2 ==0)
if r1:
  if r2:
    print (a*b)
  else:
    print (a*a)
else:
  if r2:
    print (b*b)
  else:
    print (0)

if a > 0 and b > 0:
  print ("""1. El programa entiende que los numeros ingresados son positivos.
  2. El programa mira si al hacer la operacion da como resultado 0 en alguno de ellos(llamese r1 o r2).
  3. En caso de que r1 al operar es igual a 0, procede a analizar la condicion de la segunda variable, es decir, mira si r2 tambien cumple con la propiedad de  igual a 0.
  4. De ser el resultado de r2 igual a 0 opera de una forma, pero si r2 no da como resultado 0, operara de otra forma.
  5. En caso contrario que r1 no sea igual a 0, pero r2 si sea igual a 0, operara de la segunda forma.
  6. Ya dado el caso que ninguno de los numeros registrados su residuo sea igual a 0 pero sean positivos, el programa dara en automatico la respuesta 0""")
  if a==11 and b==2:
    print ("Como se explico anteriormente en el subpunto 5, r1 no tener residuo igual a 0, pero r2 si el programa procedera a operar en este caso (b*b), es decir, (2*2) = 4")
else:
  print ("La ecuacion tiene numero negativo")
