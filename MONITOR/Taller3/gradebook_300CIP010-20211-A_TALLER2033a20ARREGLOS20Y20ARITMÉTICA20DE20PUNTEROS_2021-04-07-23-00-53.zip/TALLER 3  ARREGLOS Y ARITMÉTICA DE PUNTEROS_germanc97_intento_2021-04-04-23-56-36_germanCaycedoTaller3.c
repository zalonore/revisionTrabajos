//
// Created by German Caycedo on 4/04/21.
//
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

void punto1(){
    srand(time(NULL));
    int arrA[20];
    int arrB[20];
    int arrC[20];
    int arrD[20] = {0};
    int a,b,c,set;
    int cont = 0;
    for (int i = 0; i < 20; ++i) {
        arrA[i] = rand() % 10;
        arrB[i] = rand() % 10;
        arrC[i] = rand() % 10;
    }

    for (int i = 0; i < 20; ++i) {
        set = 1;
        int j =0 ;
        b = 0;
        while (j<20 && b == 0){
            if (arrA[i]==arrB[j]){
                b = 1;
                int k = 0;
                c = 0;
                while (k<20 && c == 0){
                    if (arrA[i]==arrC[k]){
                        int l = 0;
                        c = 1;
                        while (set==1 && l < i) {
                            if (arrA[i] == arrD[l]){
                                set = 0;
                            }
                            l++;
                        }
                        if (set == 1){
                            arrD[cont] = arrA[i];
                            cont++;
                        }
                    }
                    k++;
                }
            }
            j++;
        }
    }
    printf("----------------- PUNTO 1 ------------------\n");
    for (int i = 0; i < 20; ++i) {
        printf("%d ",arrA[i]);
    }
    printf("\n");
    for (int i = 0; i < 20; ++i) {
        printf("%d ",arrB[i]);
    }
    printf("\n");
    for (int i = 0; i < 20; ++i) {
        printf("%d ",arrC[i]);
    }
    printf("\n");
    for (int i = 0; i < cont; ++i) {
        printf("%d ",arrD[i]);
    }
}

void punto2(){
    srand(time(NULL));
    int arr[40];
    int a,b,c,set;
    for (int i = 0; i < 40; ++i) {
        arr[i] = rand() % 100 + 2500;
    }
    int *pArr1=arr;
    int *pArr2=arr;
    int resul, absolu;
    int *dir1, *dir2;
    int temp = 1000000;
    for (int i = 0; i < 40; ++i) {
        for (int j = i; j < 40; ++j) {
            if(j != i){
                resul = *(pArr1+i) + *(pArr2+j);
                absolu = abs(*(pArr1+i) - *(pArr2+j));
                if(resul >= 3333 && absolu < temp){
                    temp = absolu;
                    dir1 = pArr1+i;
                    dir2 = pArr2+j;
//            printf("dir 1: %p y dir 2: %p valor 1: %d, valor 2: %d, absolu %d \n", pArr1+i, pArr2+j, *(pArr1+i), *(pArr2+j), absolu);
                }
            }
        }

    }
//    printf("\n Las llaves son: dir 1: %p y dir 2: %p valor 1: %d, valor 2: %d \n", dir1, dir2, *(dir1), *(dir2));
    printf("\n----------------- PUNTO 2 ------------------\n");
    printf("Las llaves son: %p y %p", dir1, dir2);
}

void punto3(){
    srand(time(NULL));
    int N = 20;
    int arr[N];
    int arr2[2*N];
    int *pArr = arr;
    int *pArr2 = arr2;
    int sum = 0, cant = 0, j = 0;
    for (int i = 0; i < N; ++i) {
        arr[i] = rand() % 70;
    }

    for (int i = 0; i <= N; ++i) {
        if(sum + *(pArr+i) > 100 || i==N){
           *(pArr2+j) = cant;
           *(pArr2+j+1) = sum;
           j+=2;
           cant = 0, sum = 0;
        }
        cant++;
        sum = sum + *(pArr+i);
    }
    printf("\n----------------- PUNTO 3 ------------------\n");
    for (int i = 0; i < N; ++i) {
        printf("%d ",arr[i]);
    }
    printf("\n");
    for (int i = 0; i < j; ++i) {
        printf("%d ",arr2[i]);
    }

}


int main()
{
    punto1();
    punto2();
    punto3();

    return 0;
}