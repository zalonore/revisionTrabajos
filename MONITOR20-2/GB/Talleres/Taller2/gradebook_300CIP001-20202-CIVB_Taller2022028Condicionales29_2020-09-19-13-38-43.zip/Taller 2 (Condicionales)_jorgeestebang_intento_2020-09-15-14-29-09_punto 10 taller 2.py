dinero=int(input("digite el valor de la transaccion: "))
dinero=dinero

if dinero>=1000 and dinero<=300000:
    dinero1=dinero//10000
    dinero=dinero%10000
    dinero2=dinero//5000
    dinero=dinero%5000
    dinero3=dinero//2000
    dinero=dinero%2000
    dinero4=dinero//1000
    dinero=dinero%1000
    print(dinero1,"billetes de 10000")
    print(dinero2,"billetes de 5000")
    print(dinero3,"billetes de 2000")
    print(dinero4,"billetes de 1000")
else:
    print("la suma de dinero no corresponde a la que aceptamos")
        
        
        
    
 

