Vx=(input("digite el valor de la variable x:"))
Vy=(input("digite el valor de la variable y:"))

x=Vy
y=Vx

print("si intercambiamos las varialbles,X seria igual a",x,"y Y seria igual a",y) 
