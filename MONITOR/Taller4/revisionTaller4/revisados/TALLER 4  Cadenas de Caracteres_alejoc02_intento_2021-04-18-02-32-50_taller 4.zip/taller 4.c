#include<stdio.h>

int punto1()
{
    int contar = 0, i;
    char cadena[1000];
    printf("Digite una cadena: ");
    scanf("%s",cadena);
    for( i =0 ; cadena [i] != '\0'; i++ ){
        contar++;
    }
    return contar;
}

int punto2(char *cadena){
    cadena[0] = cadena[0] & ~ 32;
    printf("Cambio de la primer letra:\n%s", cadena);
    cadena[16] = cadena[16] & ~ 32;
    cadena[24] = cadena[24] & ~ 32;
    printf("Cambio de la letra inicial del nombre:\n%s", cadena);
}

int punto3(char *cadena, char vocal[0]){
    int contar = 0, segundo = -1;
    for(int i = 0 ; cadena [i] != '\0' ; i++ ){
        if ( cadena[i] == vocal[0]){
            contar++;
        }
    }
    printf("%s se encuentra %d veces.\n", vocal, contar);

    for(int i =0 ; cadena [i] != '\0'; i++ ){
        if ( cadena[i] == vocal[0]){
            cadena[i] ^= 32;
            break;
        }
    }
    printf("Cambio del primer %s:\n%s",vocal , cadena);
     
    for(int i =0 ; cadena [i] != '\0'; i++ ){
        if ( cadena[i] == vocal[0]){
            if ( segundo == 1 ){
                cadena[i] ^= 32;
                }
            segundo *= -1;
        }
    }
    printf("Cambio del cada segundo %s:\n%s",vocal , cadena);
    }

void camara(){
    char cadena[1000] = "Mi profe consiguio una camara vieja antes de la pandemia, pero como ahora es un profe digital, el profe se consiguio una camara nueva mas bonita. Pasado el tiempo se dio cuenta que la camara nueva aunque bonita era una camara mala, pero que bobada, al fin y al cabo, ya sea con una camara vieja o una camara nueva, nunca la muestra en clase.";
    for(int i =0 ; cadena [i] != '\0'; i++ ){
        if ( cadena[i] == 'c' && cadena[i+1] == 'a' && cadena[i+2] == 'm' && cadena[i+3] == 'a' && cadena[i+4] == 'r' && cadena[i+5] == 'a'){
            for(int j = i ; cadena [j] != '\0'; j++ )  {
                cadena [j] = cadena [j+7];
            } 
        }
    }
    printf("%s\n",cadena);
}


int main(){
   int menuOpcions = 0;
   char vocal[0], cadena[10000] = "en un comienzo, gabriel garcia Marquez penso en titular su novela La Casa, pero se decidio por Cien anios de soledad para evitar confusiones con la novela La Casa Grande, publicada en 1954 por su amigo, Alvaro Cepeda Samudio\n";
   while (menuOpcions != 5 ){
      printf("\nMenu:\n 1.Cantidad de Caracters\n 2.Modificar Cadena\n 3.Cambiar vocal\n 4.Camara\n5.Salir\n");
      scanf( "%d", &menuOpcions);
      switch(menuOpcions){ 
          case 1: printf("La cadena tiene %d elementos\n", punto1()); break;
          case 2: punto2(cadena); break;
          case 3: 
            printf("Digite una vocal: ");
            scanf("%s", vocal);
            punto3(cadena, vocal);
            break;
          case 4: camara(); break;
   }
   }
    return 0;

}

