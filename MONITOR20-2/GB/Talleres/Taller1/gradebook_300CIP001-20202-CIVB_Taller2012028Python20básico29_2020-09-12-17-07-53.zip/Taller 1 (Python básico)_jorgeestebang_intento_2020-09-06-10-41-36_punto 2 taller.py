numero1=int(input("coloque un numero para realizar operaciones: "))
numero2=int(input("coloque el numero por el que desea hacer la operacion: "))
suma= numero1+numero2
print("la suma de", numero1,"+",numero2,"es",suma)
resta= numero1-numero2
print("la resta de", numero1,"-",numero2,"es",resta)
multiplicacion= numero1*numero2
print("la multiplicacion de", numero1,"*",numero2,"es",multiplicacion)
division=numero1/numero2
print("la division de", numero1,"/",numero2,"es",division)
potencia=numero1**numero2
print("la potencia de", numero1,"^",numero2,"es",potencia)
