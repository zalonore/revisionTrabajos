
//Incluyo biblioteca de entrada/salida.
#include <stdio.h>
#include <math.h>


int suma(int x, int y){
  return x+y;
}
int resta(int x, int y){
  return x-y;
}
int multiplicacion(int x, int y){
  return x*y;
}
float division(int x, int y){
  float result=0.0;
  if(y>0){
	result= (float)x/ (float)y;
  }else{
	printf("No se puede hacer esta operacion para los numeros %d--%d \n", x,y);
  }
  return result;
}

//Dice si un numero x es palindrome. Retorna 1 si lo es y 0 si no.
void numeroPalindrome(const int x){
  unsigned numeroDigitos = 0;
  while(pow(10,numeroDigitos) < x) numeroDigitos++;
  // printf_s("Numero de Digitos %d\n",numeroDigitos);
  int ans = 1;
  unsigned indexL = numeroDigitos, indexR = 1;
  unsigned indexLNumber, indexRNumber;
  // printf_s("IndexeL %d -- IndexeR %d\n",indexL,indexR);

  while(indexL > indexR && ans == 1){
    indexLNumber = (x%(int)pow(10,indexL) - x%(int)pow(10,indexL-1))/(int)pow(10,indexL-1);
    indexRNumber = (x%(int)pow(10,indexR) - x%(int)pow(10,indexR-1))/(int)pow(10,indexR-1);
    // printf_s("IndexNumbers %d %d\n",indexLNumber,indexRNumber);
    if(indexLNumber != indexRNumber) ans = 0;
    indexL--;
    indexR++;
  }
  if(ans == 1) printf_s("El numero %d es Palindrome\n",x);
  else printf_s("El numero %d no es Palindrome\n",x);
  // return ans;
}

//Dice si un ano x es bisiesto. Retorna 1 si lo es y 0 si no.
int anoBisiesto(const int x){
  return (( x%4 == 0 && x%100 != 0 ) || x%400 == 0) ? 1 : 0;
}

int main(){
  
  int valor1,valor2,respuestaD;
  float respuestaF;
  printf("Bienvenidos a este programa \n");
  printf("Ingrese el num uno \n");
  scanf_s("%d",&valor1);
  printf("Ingrese el num dos \n");
  scanf_s("%d",&valor2);
  
  //Operaciones
  respuestaD=suma(valor1,valor2);
  printf("Resultado operacion suma %d \n", respuestaD);
  
  respuestaD=resta(valor1,valor2);
  printf("Resultado operacion resta %d \n", respuestaD);
  
  respuestaD=multiplicacion(valor1,valor2);
  printf("Resultado operacion multiplicacion %d \n", respuestaD);
  
  respuestaF=division(valor1,valor2);
  printf("Resultado operacion division %f \n", respuestaF);
  
  //Deses el punto 4 del taller
  int d;
  //La unica razon de prev era hacer pruebas con scanf.
  int* prev[2] = {&d,&d};
  printf_s("Ingrese un numero a analizar: ");
  //Utilizo scanf_s porque al compilar me salia un warning que recomendaba utilizar scanf_s pues scanf ya era obsoleta en cuanto a seguridad.
  scanf_s("%d",prev[0]);
  numeroPalindrome(d);
  prev[0] = prev[1];
  printf_s("Ingrese el ano a analizar: ");
  scanf_s("%d",prev[0]);
  if(anoBisiesto(d) == 1)
    printf_s("El ano %d es Bisiesto y mi Nombre es Juan Fernando Otoya",d);
  else
    printf_s("El ano %d no es Bisiesto y tengo 1 hermana",d);

  return 0;

}