mes = float(input("Inserte el numero del mes"))
a,b,c,d,e,f,g,h,i,j,k,l = 1,2,3,4,5,6,7,8,9,10,11,12
if (mes> 12):
 print("Lo siento el número no corresponde a un mes del año")
else:
 if(mes == a or mes == c or mes == e or mes == g or mes == h or mes == j or mes ==l):
   print("Este mes tiene 31 días")
 else:
   if(mes == k or mes == d or mes == f or mes == i):
     print("Este mes tiene 30 días")
   else:
     if(mes == b):
       print("Este mes tiene 28 días")
