//Incluyo biblioteca de entrada/salida.
#include <stdio.h>

int digitos, cortar, invertido, numero; 

// numero1 y numero2 cumplen lo mismo en cada función, siendo numero1 y numero2 variables que sirven para procesar y dar resultado a cada operación especificada

int suma( int numero1, int numero2 ){ 
  return numero1+numero2;	// Devuelve suma
}

int resta( int numero1, int numero2 ){
  return numero1-numero2;	// Devuelve resta
}

int multiplicar( int numero1, int numero2 ){
  return numero1*numero2;	// Devuelve multiplicación
}

float dividir( int numero1, int numero2 ){
  float resultado = 0.0;

  if( numero2>0 ){	// Condicional en caso de que el divisor sea 0, porque 
	resultado= (float)numero1/ (float)numero2;
  }else{
	printf( "No se puede hacer esta operacion para los numeros %d--%d \n", numero1, numero2 );
  }

  return resultado;	// Devuelve división
}

int palindromo ( int digitos, int cortar, int numero, int invertido ){ // El proceso usado consta de almacenar el último número en cortar y después elinarlo del número introducido
	numero = digitos;	// "numero" almacena el valor de "digitos" antes de ser modificada
	
	while ( digitos > 0 ){
		cortar = digitos % 10;	// "cortar" sirve para tomar el último digito del número "digitos" dado por el usuario
		digitos /= 10;	// este proceso sirve para eliminar el último número de "digitos" justo después de que ese número es almacenado en "cortar"
		invertido = invertido*10+cortar;	// "invertido" genera los numeros invertidos y los almacena
	}
	
	if ( invertido==numero ){	//se compara al número invertido con el original con un condicional.
		printf( "El numero %d es palindromo \n", numero );
	}else{
		printf( "El numero %d no es palindromo \n", numero );
	}
}

int yearBisiesto ( int year ){
	/* 
	Se divide entre 4, 100 y 400, si en todos su residuo es 0, 
	es bisiesto
	*/

	if ( year%4==0 && year%100!=0 || year%400==0){
		return 1;
	}
	else{
		return 0;
	}

}

int main(){
  int num1, num2, operaciones, numeroPal, palindromoP, calcularYear, yearU; //operaciones servirá para llamar a las funciones e imprimir valor, palindromoP para imprimir
  float division;	// división devolverá el valor de la división exclusivamente
  char almacenarCortar[10];	// variable creada para el uso de sprintf en la función palindromo 

  printf( "Bienvenidos a este programa \n" );
  printf( "Ingrese el numero uno: \n" );
  scanf( "%d", &num1 );	// Se almacena el número dado por el usuario en la variable num1

  printf( "Ingrese el numero dos: \n" );
  scanf( "%d", &num2 );	// Así como en el caso de num1, pasa con num2

  printf( "Ingrese el numero para saber si es palindromo, debe poner 9 digitos: \n" );
  scanf( "%d", &numeroPal );	// Almacena el valor del numero para saber si es palindromo en "numeroPal"
  
  // Aquí se hace uso de num1 y num2, llamando las funciones en variables "operaciones" e imprimiendo cada resultado (suma, resta y multiplicación)

  operaciones = suma( num1, num2 );
  printf( "Resultado de la suma: %d \n", operaciones );
  
  operaciones = resta( num1, num2 );
  printf( "Resultado de la resta: %d \n", operaciones );
  
  operaciones = multiplicar( num1, num2 );
  printf( "Resultado de la multipliacion: %d \n", operaciones );
  
  division = dividir( num1, num2 );	// Esta devuelve exclusivamene el valor de división
  printf( "Resultado de la division: %f \n", division );

  palindromoP = palindromo( numeroPal, cortar, numero, invertido ); //Llama a la función y dice si es o no palindromo

  printf( "Ingrese un anio para calcular si es o no bisiesto: \n" );
  scanf( "%d", &yearU ); // Almacena el valor del año que digita el usuario en "year"  

  calcularYear = yearBisiesto( yearU );

  if ( calcularYear == 1 ){
  	printf( "El anio %d es bisiesto y mi nombre es Cristian David \n", yearU );
  }else{
  	printf( "El anio %d no es bisiesto y tengo 0 hermanos \n", yearU );
  }

  return 0;
}