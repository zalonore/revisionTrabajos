totalm=int(input("digite las ventas totales de la semana en medicamentos:"))
totala=int(input("digite las ventas totales de la semana en productos de aseo:"))
medicamentosv=int(input("digite la cantidad total de medicamentos vendidos en la semana por el vendedor:"))
aseov=int(input("digite la cantidad total de implementos de aseo vendidos en la semana por el vendedor:"))

a=totalm+totala
x=medicamentosv*0.09
y=aseov*0.13

ganancias=x+y
print(" el total de productos vendidos entre aseo y medicamentos en la semana es:",a)
print("las ganancias del vendedor son:", x+y)
print("el salario del vendedor es:,",200+x+y)


