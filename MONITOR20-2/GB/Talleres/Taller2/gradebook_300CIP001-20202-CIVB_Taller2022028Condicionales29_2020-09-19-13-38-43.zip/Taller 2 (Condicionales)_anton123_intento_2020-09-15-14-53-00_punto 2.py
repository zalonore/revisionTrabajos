x = int(input("Ingrese un numero:"))
if x%2==0:
  print ("Es un numero par", x%2==0)
else:
  print ("Es un numero impar", x%2==0)
