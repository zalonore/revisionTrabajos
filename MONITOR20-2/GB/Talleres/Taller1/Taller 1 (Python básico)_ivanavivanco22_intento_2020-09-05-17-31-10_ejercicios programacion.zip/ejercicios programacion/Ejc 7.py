print("Ingrese las variables X, Y")
x = (input("Ingrese x: "))
y = (input("Ingrese y: "))
x , y = y , x
print("Ahora el valor de x es: ", x)
print("Ahora el valor de y es: ", y)