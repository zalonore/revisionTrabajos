numero = int(input('escribir el numeros'))
cambio = 0
while (numero > 0):
    recordatorio = numero % 10
    cambio = (cambio*10) + recordatorio
    numero = numero //10
print ('los numeros al revés', cambio)
