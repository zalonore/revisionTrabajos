#include <stdio.h>
#include <stdlib.h>
#define CAP 350

void p1() {
  char cadena[CAP];
  int i, contadorLetras = 0, contadorEspacios = 0;
  printf("Escriba lo que desee:\n");
  scanf(" %[^\n]s\n", cadena);
  for(i = 0; i < CAP; i++) {
    if(cadena[i] == '\0') {
      break;
    } else {
      if(cadena[i] == ' ') {
        contadorEspacios++;
      } else {
        contadorLetras++;
      }
    }
  }
  printf("Lo que usted ingreso posee %d caracteres y %d espacios.\n",
   contadorLetras, contadorEspacios);
}

void p3(char *cadena, int size) {
  int i, contador = 0;
  char vocal;
  printf("Ingrese la vocal que desea usar: ");
  scanf(" %c", &vocal);
  for(i = 0; i < size; i++) {
    if(*(cadena + i) == vocal || (int)*(cadena + i) == (int)vocal - 32) {
      contador++;
      if(contador % 2 > 0 && (int)cadena[i] > 96 && (int)cadena[i] < 123) {
        *(cadena + i) = (char)((int)cadena[i] - 32);
      } else if(contador % 2 == 0 && (int)cadena[i] > 64 && (int)cadena[i] < 91){
        *(cadena + i) = (char)((int)cadena[i] + 32);
      }
    }
  }
  printf("%d\n", contador);
  printf("%s\n", cadena);
}

void p2() {
  int i;
  char cadena[] = "en un comienzo, gabriel garcia Marquez penso en titular su "
    "novela La Casa, pero se decidio por Cien anios de soledad para evitar confusiones "
    "con la novela La Casa Grande, publicada en 1954 por su amigo, Alvaro Cepeda Samudio";
  for(i = 0; i < sizeof(cadena)/sizeof(char); i++) {
    if(i == 0 && (int)cadena[0] > 96 && (int)cadena[0] < 123) {
      cadena[i] = (char)((int)cadena[i] - 32);
    } else if(cadena[i] == 'g' && cadena[i + 1] == 'a' && cadena[i + 2] == 'b' && (int)cadena[i] > 96 && (int)cadena[i] < 123) {
      cadena[i] = (char)((int)cadena[i] - 32);
    } else if(cadena[i] == 'g' && cadena[i + 1] == 'a' && cadena[i + 2] == 'r' && (int)cadena[i] > 96 && (int)cadena[i] < 123) {
      cadena[i] = (char)((int)cadena[i] - 32);
    }
  }
  printf("%s\n", cadena);
  printf("\nAhora el punto 3\n");
  p3(cadena, sizeof(cadena)/sizeof(char));
}

void p4() {
  int i, j;
  char cadena[] = "Mi profe consiguio una camara vieja antes de la pandemia, pero "
    "como ahora es un profe digital, el profe se consiguio una camara nueva mas bonita. "
    "Pasado el tiempo se dio cuenta que la camara nueva aunque bonita era una camara mala, "
    "pero que bobada, al fin y al cabo, ya sea con una camara vieja o una camara nueva, nunca la muestra en clase.";
  char cadena2[] = "";
  for(i = 0, j = 0; i < sizeof(cadena)/sizeof(char); i++) {
    if(cadena[i] == 'c' && cadena[i + 1] == 'a' && cadena[i + 2] == 'm' && cadena[i + 3] == 'a' &&
      cadena[i + 4] == 'r' && cadena[i + 5] == 'a') {
        i += 6;
    } else {
      cadena2[j] = cadena[i];
      j++;
    }
  }
  printf("%s\n", cadena2);
}

void menu() {
  int opc;
  do{
    printf("1. Punto 1.\n"
    "2. Punto 2.\n"
    "3. Punto 3.\n"
    "4. Punto 4.\n"
    "0. exit\n"
    "opc: ");
    scanf(" %d", &opc);
    switch(opc) {
      case 1: // Punto 1
      p1();
      break;
      case 2: // Punto 2
      p2();
      break;
      case 4: // Punto 4
      p4();
      break;
    }
  } while(opc != 0);
}


int main(){
  menu();
}
