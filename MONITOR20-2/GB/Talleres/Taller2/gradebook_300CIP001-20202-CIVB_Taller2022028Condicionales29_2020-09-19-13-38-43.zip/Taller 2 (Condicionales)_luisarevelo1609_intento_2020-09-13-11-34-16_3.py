numero1= int(input("digite su primer numero:"))
numero2= int(input("digite su segundo numero:"))

if numero1%numero2==0:
    print("true")

else:
    print("false")
