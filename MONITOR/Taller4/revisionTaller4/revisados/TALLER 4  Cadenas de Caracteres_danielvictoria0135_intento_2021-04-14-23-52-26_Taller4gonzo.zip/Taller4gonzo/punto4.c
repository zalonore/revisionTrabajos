#include <stdio.h>

int main(){
    char texto[500];
    char textomodificado[500];
    int i, j = 0;

    printf("\nPonga el texto: ");
    fgets(texto, sizeof(texto), stdin);
    printf("\n");
    for(i = 0; i < sizeof(texto); i++){
        if(texto[i] != 'c' && texto[i+1] != 'a' && texto[i+2] != 'm' && texto[i+3] != 'a' && texto[i+4] != 'r' && texto[i+5] != 'a'){
            textomodificado[j] = texto[i];
            j++;
        }
    }
    for(i = 0; i < sizeof(textomodificado); i++){
        if(textomodificado[i] == '\0'){
            break;
        }
        else{
            printf("%c", textomodificado[i]);
        }    
    }
    printf("\n");
    return 0;
}
