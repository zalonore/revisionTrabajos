a = input("Por favor digite el valor de X:")
b = input("Por favor digite el valor de Y:")
a,b=b,a
print ("El valor de X es",a)
print ("El valor de Y es",b)
