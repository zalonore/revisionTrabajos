#include <stdio.h>

void menu(){
  printf("\n");
  printf("Puntos del taller 4:\n"
        "1.Punto 1\n"
        "2.Punto 2\n"
        "3.Punto 3\n"
        "4.Punto 4\n"
        "0.Salir\n"
        "opc: ");
}
void punto1(){
  int i, cont = 0;
  char s[20];
  printf("Ingrese la cadena:\n");
  scanf("%s", s);
  for(i = 0; i < 20; i++){
    if(s[i] == '\0'){
      break;
    }
    cont++;
  }
  printf("%d\n", cont);
}

void punto2(){
  char s[] = "en un comienzo, gabriel garcia Marquez penso en titular su novela La Casa, pero se decidio por Cien anios de soledad para evitar confusiones con la novela La Casa Grande, publicada en 1954 por su amigo, Alvaro Cepeda Samudio. ";
  int i, n = 0;
  n = s[0] - 32;
  s[0] = n;
  for(i = 0; i < sizeof(s); i++){
    n = 0;
    if(s[i] == 'g' && s[i + 1] == 'a' && s[i + 2] == 'b'){
      n = s[i] - 32;
      s[i] = n;
    }
    if(s[i] == 'g' && s[i + 1] == 'a' && s[i + 2] == 'r'){
      n = s[i] - 32;
      s[i] = n;
    }
  }
  printf("%s\n", s);
}

void punto3(){
  int i, n = 0, cont = 0, opc1, contV = 0;
  char c[1], s[] = "en un comienzo, gabriel garcia Marquez penso en titular su novela La Casa, pero se decidio por Cien anios de soledad para evitar confusiones con la novela La Casa Grande, publicada en 1954 por su amigo, Alvaro Cepeda Samudio. ";
  printf("Ingrese una vocal: ");
  scanf("%s", c);
  if(c[0] != 'a' && c[0] != 'e' && c[0] != 'i' && c[0] != 'o' && c[0] != 'u'){
    printf("No es una vocal");
  }
  else{
    n = c[0] - 32;
    do{
      printf("\n");
      printf("Punto 3:\n"
          "0.Regresar\n"
          "3.1\n"
          "3.2\n"
          "3.3\n"
          "opc: ");
          scanf("%d", &opc1);
          switch(opc1){
            case 1: //Punto 3.1
              for(i = 0; i < sizeof(s); i++){
                if(s[i] == c[0] || s[i] == n){
                  cont++;
                }
              }
              printf("%d\n", cont);
              break;
            case 2: //Punto 3.2
              for(i = 0; i < sizeof(s); i++){
                if(s[i] == c[0]){
                  s[i] = n;
                  contV++;
                  break;
                }
              }
              printf("%s\n", s);
              break;
            case 3: //Punto 3.3
              for(i = 0; i < sizeof(s); i++){
                if(s[i] == c[0]){
                  if(contV == 0){
                    s[i] = n;
                    contV++;
                  }
                  else if(contV > 0){
                    contV = 0;
                  }
                }
              }
              printf("%s\n", s);
              break;
          }
    }while(opc1 != 0);
  }
}
void punto4(){
  int i, j;
  char s[] = "Mi profe consiguio una camara vieja antes de la pandemia, pero como ahora es un profe digital, el profe se consiguio una camara nueva mas bonita. Pasado el tiempo se dio cuenta que la camara nueva aunque bonita era una camara mala, pero que bobada, al fin y al cabo, ya sea con una camara vieja o una camara nueva, nunca la muestra en clase.";
  char l[sizeof(s)];
  for(i = 0, j = 0; i < sizeof(s); i++){
    if(s[i] == 'c' && s[i + 1] == 'a' && s[i + 2] == 'm' && s[i + 3] == 'a' && s[i + 4] == 'r' && s[i + 5] == 'a'){
      i += 5;
    }
    else{
      l[j] = s[i];
      j++;
    }
  }
  printf("%s\n", l);;
}
int main(){
  int opc;
  do{
    menu();
    scanf("%d", &opc);
    switch(opc){
      case 1: //Punto 1
        punto1();
        break;
      case 2: //Punto 2
        punto2();
        break;
      case 3: //Punto 3
        punto3();
        break;
      case 4: //Punto 4
      punto4();
      break;
    }
  }while(opc != 0);
  return 0;
}
