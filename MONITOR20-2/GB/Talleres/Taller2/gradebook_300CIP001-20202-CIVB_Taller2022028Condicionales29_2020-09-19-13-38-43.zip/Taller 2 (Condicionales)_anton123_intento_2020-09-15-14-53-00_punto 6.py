a = int(input("¿A que piso va?"))
if (a== 1 or a== 2):
  print ("Vas por las escaleras")
else:
  if (a>15):
   print ("Sube por el ascensor 1")
  else:
    if (a%2==0+1):
      print ("Sube por el ascensor 2")
    if (a%2==0):
      print ("Sube por el ascensor 3")
