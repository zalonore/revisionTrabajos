s= 200
m= .09
a= .13

Valor1= int(input("¿Cuanto vendio en medicamentos?"))
Valor2= int(input("¿Cuanto vendio en aseo?"))
Ecuacion= (m*Valor1)+(a*Valor2)
print ("El vendedor gano:", s+Ecuacion)
