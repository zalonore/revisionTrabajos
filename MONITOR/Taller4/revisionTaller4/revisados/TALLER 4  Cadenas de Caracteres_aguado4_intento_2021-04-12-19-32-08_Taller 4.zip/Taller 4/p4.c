#include <stdio.h>

void main (){
   int i, j, k;
   char string[] = "Mi profe consiguio una camara vieja antes de la pandemia, pero como ahora es un profe digital, el profe se consiguio una camara nueva mas bonita. Pasado el tiempo se dio cuenta que la camara nueva aunque bonita era una camara mala, pero que bobada, al fin y al cabo, ya sea con una camara vieja o una camara nueva, nunca la muestra en clase.";
   for (i = 0; string[i] != '\0'; i++){
   }
   for (j = 0; j < i; j++){
      if (string[j] == 'c'){
         if (string[j+1] == 'a'){
            if (string[j+2] == 'm'){
               if (string[j+3] == 'a'){
                  if (string[j+4] == 'r'){
            	     if (string[j+5] == 'a'){
            	        for (k = j; k < i; k++){
            	           string[k] = string[k + 7];
            	        }
            	        i -= 7;
                     }
                  }
               }
            }
         }
      }
   }
   printf("%s\n", string);
}