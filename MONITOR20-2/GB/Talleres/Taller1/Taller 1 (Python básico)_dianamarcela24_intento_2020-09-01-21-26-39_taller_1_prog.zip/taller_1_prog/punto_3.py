radio = float( input( "Por favor digite el radio del circulo: "))

pi = 3.1416

area = pi * (radio**2)

print("El area del circulo de radio: ", radio, " es: ", area)
