base=float(input("ingrese la base del rectangulo:"))
altura=float(input("ingrese la altura del rectangulo:"))

area=(base*altura)
perimetro=((2*base)+(2*altura))
print("el area del rectangulo con esas medidas es",area,"")
print("el perimetro del rectangulo con esas medidas es",perimetro,"")

