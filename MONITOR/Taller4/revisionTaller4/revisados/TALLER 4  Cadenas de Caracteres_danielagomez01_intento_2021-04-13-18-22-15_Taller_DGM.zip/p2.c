#include <stdio.h>
#include <stdlib.h>

// Modificar la cadena para pasar a mayúscula A)la letra inicial de la oración y b) la letra inicial del nombre y apellido.


void main (){

	int i = 0, num = 0, par, opc; 
    char ch[1];
	char str[]={"en un comienzo, gabriel garcia Marquez penso en titular su novela La Casa, pero se decidio por Cien anios de soledad para evitar confusiones con la novela La Casa Grande, publicada en 1954 por su amigo, Alvaro Cepeda Samudio"};

    //Cambiar primera letra

	if(str[i]>='a' && str[i]<='z'){
            str[i] = str[i] - 32;
    }

    //Corrección de Gabriel Garcia

    for(i = 0 ; str[i] != '\0' ; i++){

    	if (str[i] == 'g' && str[i+6] == 'l'){
    		str[i] = str[i] - 32;
    	}

    	if (str[i] == 'g' && str[i+5] == 'a'){
    		str[i] = str[i] - 32;
    	}
    }

    // 3.1

	printf("\nDESEA ENCONTRAR LA FRECUENCIA DE UN CARACTER?\n1. SI \n2. NO\nSeleccion: ");
    scanf("%d", &opc);

    if (opc == 1){

        fflush(stdin);
    	printf("\nEncontrar la frecuencia de: ");
    	scanf("%s", ch);

	    for (i = 0; str[i] != '\0'; i++) {

            if ( str[i] == ch[0]  ){
                num++;
            }
	    }

		printf("Frecuencia de %s = %d\n", ch, num);

        printf("\nHACER MAYUSCULAS DE %s\n1. NO\n2. SI (Solo Primera)\n3. SI (Intercaladas)\nSeleccion: ", ch);
        scanf("%d", &opc);

        switch(opc){

            // 3.2

            case 2:
                    fflush(stdin);
                    for (i = 0; str[i] != '\0'; i++) {
                        if ( str[i] == ch[0]  ){
                            str[i] = str[i] - 32;
                            break;
                        }
                    }
                    break;

            // 3.3

            case 3:
                    fflush(stdin);
                    par = 1;
                    for (i = 0; str[i] != '\0'; i++) {
                        if ( ch [0] == str[i]){
                            par++;
                            if (par % 2 == 0 ){
                                str[i] = str[i] - 32;
                            }
                        }
                    }
                    break;
        }

    }

    printf("\nTexto Final: %s", str);

}




