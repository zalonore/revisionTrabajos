#include<stdio.h> 

int main(){
    char cadena[ 100 ];
    int i, num = 0;
   
    printf( "Introduzca una palabra: " );
    fgets(cadena, sizeof(cadena), stdin );

    for( i = 0; i < sizeof(cadena); i++ ){
    	if( cadena[ i ] == '\0' ){
    		break;
    	}
    	else if ( cadena[ i ] == ' ' ){
    		num=num;
    	}
    	else{
    		num++;
    	}
    }
   
    printf( "la palabra tiene %d letras" , num - 1 );

    return 0;
}
