radio = input("digite el radio ")
pi = (3.1416)
a = float(radio)
r = (a**2)
area = (pi*r)
print ("Su area del cirulo es :",area)


