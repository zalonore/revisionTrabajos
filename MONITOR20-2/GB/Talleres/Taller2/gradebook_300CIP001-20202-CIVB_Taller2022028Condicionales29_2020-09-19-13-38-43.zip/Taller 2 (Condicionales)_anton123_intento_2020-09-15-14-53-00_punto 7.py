a= input("¿Cual es el nombre del primer jugador?")
b= input("¿Cual es el nombre del segundo jugador?")
import random
x= random.randrange(1,6)
Newx= print (a, "Lanzó el dado y su numero es", x)
y= random.randrange(1,6)
Newy= print (b, "Lanzó el dado y su numero es", y)
if (x == y or y == x):
  print ("No gana nadie, hay empate")
else:
  if (x<y):
    print ("El ganador es", b)
  else:
    print ("El ganador es", x)
