#Programa de intercambio de variables
x=input(" inserte el valor de la variable,(x): ")
y=input(" inserte el valor de la variable,(y): ")
z=y
y=x
x=z
print(f"la variable x es: {x},la variable y es: {y}")


