a=(" \ | / ")
b=("  @ @  ")
c=('\ """ /')

print(a)
print( b)
print(c)




