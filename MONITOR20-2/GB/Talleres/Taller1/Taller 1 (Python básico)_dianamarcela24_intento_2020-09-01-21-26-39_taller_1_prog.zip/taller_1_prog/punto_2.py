a = float( input( "Por favor digite el primer número: "))
b = float( input( "Por favor digite el segundo número: "))

suma = a + b
resta = a - b
multiplicacion = a*b
division = a/b
potenciacion = a**b

print( "la suma de ", a, "+", b, " es: ", suma)
print( "la resta de ", a, "-", b, " es: ", resta)
print( "la multiplicación de ", a, "+", b, " es: ", multiplicacion)
print( "la división de ", a, "+", b, " es: ", division)
print( "la potenciación de ", a, "+", b, " es: ", potenciacion)
