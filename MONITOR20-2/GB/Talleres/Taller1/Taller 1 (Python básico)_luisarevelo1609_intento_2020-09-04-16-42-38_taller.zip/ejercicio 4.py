base=int(input("digite el valor de la base de su rectangulo:"))
altura=int(input("digite el valor de la altura de su rectangulo:"))
area=base*altura
print("el area de su rectagulo con las medidas dadas es:",area)
perimetro= 2*base+ 2*altura
print("el perimetro de su rectangulo con las medidas dadas es:",perimetro)

