#include <stdio.h>

int count (char string[], char vocalMay, char vocalMin){
   int i, j, cant = 0;
   for (i = 0; string[i] != '\0'; i++){
   }
   for (j = 0; j < i; j++){
      if (string[j] == vocalMay || string[j] == vocalMin){
         cant++;
      }
   }
   return cant;
}

void change (char string[], char vocalMay, char vocalMin){
   int i, j;
   for (i = 0; string[i] != '\0'; i++){
   }
   for (j = 0; j < i; j++){
      if (string[j] == vocalMin){
      	string[j] = vocalMay;
      	printf("%s\n", string);
      	return;
      }
   }
}

void inter (char string[], char vocalMay, char vocalMin){
   int i, j, cant = 0;
   for (i = 0; string[i] != '\0'; i++){
   }
   for (j = 0; j < i; j++){
      if (string[j] == vocalMin || string[j] == vocalMay){     
         if (cant % 2 == 0){
      	    string[j] = vocalMay;
         }else{
            string[j] = vocalMin;
         }
         cant++;
      }
   }
   printf("%s\n", string);
}

void main (){
   char string[] = "en un comienzo, gabriel garcia Marquez penso en titular su novela La Casa, pero se decidio por Cien anios de soledad para evitar confusiones con la novela La Casa Grande, publicada en 1954 por su amigo, Alvaro Cepeda Samudio";
   char vocal, vocalMay, vocalMin;
   string[0] = 'E';
   string[16] = 'G';
   string[24] = 'G';
   printf ("Ingrese una vocal : ");
   scanf ("%c", &vocal);
   if (vocal == 'a' || vocal == 'A'){
      vocalMay = 'A';
      vocalMin = 'a';
      printf ("La vocal %c se encuentra %d veces\n", vocal, count (string, vocalMay, vocalMin));
      printf ("El string con la primera %c en mayuscula seria : \n", vocalMin);
      change (string, vocalMay, vocalMin);
      printf ("El string con la vocal %c intercalada seria : \n", vocal);
      inter (string, vocalMay, vocalMin);
   }else if (vocal == 'e' || vocal == 'E'){
      vocalMay = 'E';
      vocalMin = 'e';
      printf ("La vocal %c se encuentra %d veces\n", vocal, count (string, vocalMay, vocalMin));
      printf ("El string con la primera %c en mayuscula seria : \n", vocalMin);
      change (string, vocalMay, vocalMin);
      printf ("El string con la vocal %c intercalada seria : \n", vocal);
      inter (string, vocalMay, vocalMin);
   }else if (vocal == 'i' || vocal == 'I'){
      vocalMay = 'I';
      vocalMin = 'i';
      printf ("La vocal %c se encuentra %d veces\n", vocal, count (string, vocalMay, vocalMin));
      printf ("El string con la primera %c en mayuscula seria : \n", vocalMin);
      change (string, vocalMay, vocalMin);
      printf ("El string con la vocal %c intercalada seria : \n", vocal);
      inter (string, vocalMay, vocalMin);
   }else if (vocal == 'o' || vocal == 'O'){
      vocalMay = 'O';
      vocalMin = 'o';
      printf ("La vocal %c se encuentra %d veces\n", vocal, count (string, vocalMay, vocalMin));
      printf ("El string con la primera %c en mayuscula seria : \n", vocalMin);
      change (string, vocalMay, vocalMin);
      printf ("El string con la vocal %c intercalada seria : \n", vocal);
      inter (string, vocalMay, vocalMin);
   }else if (vocal == 'u' || vocal == 'U'){
      vocalMay = 'U';
      vocalMin = 'u';
      printf ("La vocal %c se encuentra %d veces\n", vocal, count (string, vocalMay, vocalMin));
      printf ("El string con la primera %c en mayuscula seria : \n", vocalMin);
      change (string, vocalMay, vocalMin);
      printf ("El string con la vocal %c intercalada seria : \n", vocal);
      inter (string, vocalMay, vocalMin);
   }else{
      printf("vocal invalida\n");
   }
}