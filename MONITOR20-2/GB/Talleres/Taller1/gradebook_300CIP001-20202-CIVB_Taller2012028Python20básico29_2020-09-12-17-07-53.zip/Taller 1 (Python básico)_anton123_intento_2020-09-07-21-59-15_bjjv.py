print ("\  |  /")
print (" @   @ ")
print ("\ ... /")
