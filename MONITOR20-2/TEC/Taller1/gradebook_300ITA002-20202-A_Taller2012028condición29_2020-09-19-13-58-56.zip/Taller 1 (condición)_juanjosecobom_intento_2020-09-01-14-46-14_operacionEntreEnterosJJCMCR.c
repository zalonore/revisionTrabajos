
//Incluyo biblioteca de entrada/salida.
#include <stdio.h>
#include <math.h>

int suma(int enteroA, int enteroB){
  return enteroA+enteroB;
}
int resta(int enteroA, int enteroB){
  return enteroA-enteroB;
}
int multiplicacion(int enteroA, int enteroB){
  return enteroA*enteroB;
}
float division(int enteroA, int enteroB){
  float result=0.0;
  if(enteroB>0){
	result= (float)enteroA/ (float)enteroB;
  }else{
	printf("No se puede hacer esta operacion para los numeros %d--%d \n", enteroA,enteroB);
  }
  return result;
}
/*
int esNueveDigitos(int numero){
	if((numero<999999999) && (numero>100000000)){
		printf("Es valido\n");
		return 1;
	}
	else{
		printf("El numero no es valido, intente nuevamente\n");
		return 0;
	}
}

int esPalindromo(int numero){
	
	if(reverso == numero){
		printf("ES PALIDNROMO!! WOHOO!!");
		return 0;
	}
	else{
		printf("No es palindromo... aw...");
		return 0;
	}
}
*/

int esBisiesto(int year){
	if((year%4)==0){
		if((year%100)==0){
			if((year%400)==0){
				return 1;
			}
			else{
				return 0;
			}
		}
		else{
			return 1;
		}
	}
	else{
		return 0;
	}
}

int main(){
  int enteroA,enteroB,resultadoEntero, enteroNueveDigitos,reset = 1, year;
  float resultadoDecimal;
  printf("Bienvenidos a este programa \n");
  printf("Ingrese el num uno \n");
  scanf("%d",&enteroA);
  printf("Ingrese el num dos \n");
  scanf("%d",&enteroB);
  
  //Operaciones
   resultadoEntero=suma(enteroA,enteroB);
  printf("Resultado de la suma %d \n", resultadoEntero);
  
   resultadoEntero=resta(enteroA,enteroB);
  printf("Resultado de la resta %d \n", resultadoEntero);
  
   resultadoEntero=multiplicacion(enteroA,enteroB);
  printf("Resultado de la multiplicaci�n %d \n", resultadoEntero);
  
   resultadoDecimal=division(enteroA,enteroB);
  printf("Resultado de la divisi�n %f \n", resultadoDecimal);
/*
	while(reset){
	
  		printf("Ahora por favor ingrese un numero de 9 digitos: ");
  		scanf("%d", &enteroNueveDigitos);
  		if(esNueveDigitos(enteroNueveDigitos)){
  			reset = 0;
  		}
  		else{
  			reset=1;
		}
	}
  
  esPalindromo(enteroNueveDigitos);
  */
  
  printf("Ingrese un a�o: ");
  scanf("%d",&year);
  if(esBisiesto(year)){
  	printf("El a�o es bisiesto\n");
  }
  else{
  	printf("No es bisiesto :(\n");
  }
  
  
  
  return 0;
}

