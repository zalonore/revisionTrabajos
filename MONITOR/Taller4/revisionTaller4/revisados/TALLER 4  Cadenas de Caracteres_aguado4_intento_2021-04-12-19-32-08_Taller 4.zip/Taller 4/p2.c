#include <stdio.h>

void main (){
   char string[] = "en un comienzo, gabriel garcia Marquez penso en titular su novela La Casa, pero se decidio por Cien anios de soledad para evitar confusiones con la novela La Casa Grande, publicada en 1954 por su amigo, Alvaro Cepeda Samudio";
   string[0] = 'E';
   string[16] = 'G';
   string[24] = 'G';
   printf("%s\n", string);
}