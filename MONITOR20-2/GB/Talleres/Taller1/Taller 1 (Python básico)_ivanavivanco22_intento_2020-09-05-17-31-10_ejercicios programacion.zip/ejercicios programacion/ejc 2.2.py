numero1 = float(input("Escriba un numero:"))
numero2 = float(input("Escriba otro numero:"))

suma=numero1+numero2
resta=numero1-numero2
multiplicación=numero1*numero2
división=numero1/numero2
potencia=numero1**numero2

print("La suma es igual a:",suma,)
print("La resta es igual a:",resta,)
print("La multiplicación es igual a:",multiplicación,)
print("La división es igual a:",división,)
print("La potencia es igual a:",potencia,)