#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
	int i, j, k, n, nAleatorio, veces = 0, count = 0, sum = 0, array2[50], m = 0;
	srand(time(NULL));
    printf("Numero de valores del arreglo: ");
    scanf("%d", &n);
    int array[n];
    printf("Arreglo 1:\n");
    for (i = 0; i < n; i++){
	    nAleatorio = rand() % (70 - 1);
	    array[i] = nAleatorio;
	    printf("%d ", array[i]);
    }
    printf("\n");
    for (j = 0; j <= n; j++){
        if ((sum + *(array + j)) <= 100){
            sum += *(array + j);
            count++;
        }
        else{
            printf("\n%d %d", count, sum);
            *(array2 + m) = count;
            m++;
            veces++;
            *(array2 + m) = sum;
            m++;
            veces++;
            count = 0;
            sum = 0;
            printf(" %d", j);
            if (j != n){
        		j--;
        	}
        }

    }
    printf("\nArreglo 2:\n");
    for (k = 0; k < veces; k++){
        printf("%d ", *(array2 + k));
    }
    
    return 0;
}