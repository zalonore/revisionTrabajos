numero= int(input("a que piso se dirije?"))
if numero>15:
    print("tome el ascensor 1")
else:
    if numero <=15 and numero%2==0:
        print("tome el ascensor 2")
    else:
        if numero == 1 or numero==2:
            print("tome la escaleras")
        else:
            print("tome el ascensor 3")
