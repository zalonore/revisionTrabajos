#include <stdio.h>
#include <stdlib.h>

//Bien, porque sigo usando los "break"?, profe, siceramente si le encuentro utilidad y no quita profesionalismo
//Miremoslo desde el punto de optmizar el codigo, facilmente definimos un breack que aborta un ciclo indefinido en el cual no sabemos
//en que momento ocurrira lo que va a ocurrir, tal vez tu me diras, se puede colocar un condicional que frene ese ciclo
//y yo te respondo que eso implicaria definir mas variables que me ocupan espacio en la memoria y da cierto modo longevidad al codigo.
//y por ultimo se logra entender de manera mas clara las condiciones para frenar el codigo a programadores externos.
//Si mi respuesta no te convence, me puedo ahorrar los break apartir de ahora, pero sinceramente si les veo cierto grado de utilidad.
int fIntercesion( int x[], int y[], int z[], int size ){
	int i, j, k, tempArreglo[size], n = 0, m = 0, arregloD[size], temp, encontro;
	for( i = 0; i < size; i++ ){
		for( j = 0; j < size; j++ ){
			if( x[i] == y[j] ){
				encontro = 0;
				for( k = 0; k < n; k++ ){
					if( x[i] == tempArreglo[k] ){
						encontro = 1;
						break;
					}
				}
				if( encontro == 0 ){
					temp = x[i];
					tempArreglo[n++] = temp;
				}
				break;		
			}
		}
	}
	for( i = 0; i < n; i++ ){
		for( j = 0; j < size; j++ ){
			if( tempArreglo[i] == z[j] ){
				encontro = 0;
				for( k = 0; k < m; k++ ){
					if( tempArreglo[k] == z[i] ){
						encontro = 1;
						break;
					}
				}
				if( encontro == 0 ){
					temp = z[j];
					arregloD[m++] = temp;
				}
				break;		
			}
		}
	}
	for( i = 0; i < m; i++ ){
		printf(" %d ", arregloD[i] );
	}
}
int fRespuesta( int x[], int size ){
	int i = 0, m = 0, k = 0, arregloD[size], temp = 0, cont = 0;
	while( k < size ){
		temp = 0;
		cont = 0;
		while( x[i] + temp <= 100 && i < size ){
			temp += x[i];
			cont += 1;
			i++;
		}
		k += cont;
		arregloD[m++] = cont;
		arregloD[m++] = temp;
	}
	printf("CS = Cantidad de veces sumadas\n");
	printf("S = Suma\n");
	for( i = 0; i < m; i++ ){
		if( i % 2 == 0 ){
			printf( "CS: %d ", arregloD[i] );
		}
		else{
			printf( "S: %d ", arregloD[i] );
		}
	}
	printf("\n");
	return 0;
	//Retorno el 0 debido a que al final me da un numero raro
}
int fTesoro( int X[], int size ){
	int *pX = X, i, j, k = 1, temp, coorX, coorY, codigo;
	temp = 2500;
	for( i = 0; i < size; i++ ){
		for( j = 0 + k; j < size; j++ ){
			if( pX[i] + pX[j] >= 3333 ){
				if( pX[i] - pX[j] < 0 ){
					codigo = (pX[i] - pX[j]) *- 1;
				}
				else{
					codigo = pX[i] - pX[j];
				}
				if( codigo < temp ){
					coorX = i;
					coorY = j;
					temp = codigo;
				}

			}
		}
		k++; 
	}
	printf( "La menor resta es %d - %d = %d\n", pX[coorX], pX[coorY], temp );
	printf( "Y sus coordenadas son: %p - %p\n", &X[coorX], &X[coorY] );
	return 0;
}
void main(){
	int arregloA[20], arregloB[20], arregloC[20], arregloD[20], arregloFuncion, i, arreglo2[40], opcion, arreglo3[1], size, funcion3, funcion2;
	printf( "A que parte del taller desea entrar\n" );
	scanf( "%d", &opcion );
	switch( opcion ){
		case 1:
			printf( "Arreglo A\n" );
			for( i = 0; i < 20; i++ ){
				arregloA[i] = rand() % 20;
				printf( " %d ", arregloA[i] );
			}
			printf( "\nArreglo B\n" );
			for( i = 0; i < 20; i++ ){
				arregloB[i] = rand() % 20;
				printf( " %d ", arregloB[i] );
			}
			printf( "\nArreglo C\n" );
			for( i = 0; i < 20; i++ ){
				arregloC[i] = rand() % 20;
				printf( " %d ", arregloC[i] );
			}
			printf( "\n\nIntercesion entre A, B y C\n" );
			arregloFuncion = fIntercesion( arregloA, arregloB, arregloC, 20 );
			printf( "%d\n", arregloFuncion );
			break;
		case 2:
			printf( "Arreglo de 40 enteros\n\n" );
			for( i = 0; i < 40; i++ ){
				arreglo2[i] = 100 + rand() % ( 2501 - 100 ) ;
				printf( "%d ", arreglo2[i] );
			}
			printf("\n||||Nuestro tesoro cuenta con las coordenadas|||| \n");
			funcion2 = fTesoro( arreglo2, 40 );
			printf( "%d", funcion2 );
			break;
		case 3:
			// es que no deja escribir tamaño por la "ñ", arriba el spanglish
			printf( "Digite el size del arreglo\n" );
			scanf( "%d", &size );
			arreglo3[size];
			for( i = 0; i < size; i++ ){
				arreglo3[i] = rand() % 70;
				printf( "%d ", arreglo3[i] );
			}
			printf( "\n" );
			printf( "\nRespuesta\n\n" );
			funcion3 = fRespuesta( arreglo3, size );
			printf( "%d", funcion3 );
			break;
		case 4:
		//es para experimentar, ignore esto
			printf( "digite:\n" );
			scanf( "%d", &size );
			printf( "%p\n", &size );
			break;
	}
	
}