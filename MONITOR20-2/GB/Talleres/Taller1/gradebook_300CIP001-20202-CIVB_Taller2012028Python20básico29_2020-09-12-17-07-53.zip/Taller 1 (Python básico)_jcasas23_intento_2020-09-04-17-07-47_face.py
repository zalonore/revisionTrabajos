print (" \ | /")
print ("")
print ("  @ @")
print ("")
print ('\ \"\"\" /')
# Jorge Casas
