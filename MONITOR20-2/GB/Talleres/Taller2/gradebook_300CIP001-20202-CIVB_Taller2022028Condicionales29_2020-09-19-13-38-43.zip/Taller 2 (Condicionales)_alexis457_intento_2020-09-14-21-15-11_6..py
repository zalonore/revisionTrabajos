piso = int(input("Digite su numero de piso:"))

if piso>15:
    print("el usuario se despacha en el ascensor 1")
if piso%2!=0 and piso<=15 and piso !=1:
    print("el usuario se despacha en el ascensor 2")
if piso%2==0 and piso<15 and piso !=2:
    print("el usuario se despacha en el ascensor 3")
if piso==1 or piso==2:
    print("usar las escaleras")