x = 11
y = 9 
z = 10
w = 4



if(y>z or x==w):
    print("verdad")
else:
    print("falso")

