ventasmed=int(input("ingrese el valor de ventas de medicamentos en esta semana "))
ventasaseo=int(input("ingrese el valor de ventas de aseo en esta semana "))
salariobase=200
comision1=9/100
comision2=13/100

if ventasmed>=0 and ventasaseo>=0:
    resultado= salariobase+ (comision1*ventasmed) + (comision2*ventasaseo)
    print("el salario del vendedor es", resultado)
