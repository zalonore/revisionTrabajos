numero = int(input("Ingrese un numero de 4 cifras: "))

cifra4 = numero%10
cifra3 = int((numero%100)/10)
cifra2 = int((numero%1000)/100)
cifra1 = int((numero%10000)/1000)

print(cifra4, cifra3, cifra2,cifra1)
