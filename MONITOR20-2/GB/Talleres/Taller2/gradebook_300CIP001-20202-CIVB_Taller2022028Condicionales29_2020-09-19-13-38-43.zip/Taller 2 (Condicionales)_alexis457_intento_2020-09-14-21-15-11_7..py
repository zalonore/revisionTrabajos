import random
nombre1 = input("digite su nombre:")
variable1 = random.randint(1,7)
nombre2 = input("digite su nombre:")
variable2 = random.randint(1,7) 
print("Dado:", nombre1, variable1)
print("Dado:", nombre2, variable2)

if variable1>variable2:
    print("ganador es:", nombre1)
else:
    print("ganador es:", nombre2)

