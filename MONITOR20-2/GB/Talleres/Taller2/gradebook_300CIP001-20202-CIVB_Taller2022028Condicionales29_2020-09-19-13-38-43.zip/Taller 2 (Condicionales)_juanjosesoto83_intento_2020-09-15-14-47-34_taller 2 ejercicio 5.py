mes= int(input("numero="))
if mes == 11 or mes == 4 or mes ==6 or mes ==9:
    print("este mes tiene 30 dias")
elif mes == 2:
    print("este mes tiene 28 dias")
else:
    if mes == 1 or mes == 3 or mes ==5 or mes ==7 or mes ==8 or mes ==10 or mes ==12:
        print("el mes tiene 31 dias")
    else:
        print("lo siento el número no corresponde a un mes del año")
