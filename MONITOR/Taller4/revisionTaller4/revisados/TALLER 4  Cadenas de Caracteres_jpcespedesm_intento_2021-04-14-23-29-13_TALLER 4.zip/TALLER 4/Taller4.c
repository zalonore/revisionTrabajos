#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>



void punto1()
{
  char cadena[200];
  char *p = cadena;
  int total = 0;
  gets(cadena);
  gets(cadena);
  printf("%s\n",cadena );
  while (*p != '\0')
  {
    total++;
    p++;
  }
  printf("%d\n", total);
}

void punto2()
{
	char cadena[] = "en un comienzo, gabriel garcia Marquez penso en titular su novela La Casa,pero se decidio por Cien anios de soledad para evitar confusiones con la novela La Casa Grande, publicada en 1954 por su amigo, Alvaro Cepeda Samudio";
  char *p = cadena;
  int cont = 0;
  *p = 'E';
  //printf("%s\n",cadena );
  while (*p != '\0')
  {
    if (cont == 16)
    {
      *p = 'G';
    }
    if (cont == 24)
    {
      *p = 'G';
    }
    p++;
    cont++;
  }
  printf("%s\n", cadena);
}

char punto3(){
  char cadena[] = "En un comienzo, Gabriel Garcia Marquez penso en titular su novela La Casa,pero se decidio por Cien anios de soledad para evitar confusiones con la novela La Casa Grande, publicada en 1954 por su amigo, Alvaro Cepeda Samudio";
  char *p = cadena;
  char vocal[1];
  char *p1 = vocal;
  char vocalInversa[1] = "";
  int cont = 0, codigoAscii = 0;
  printf("Digite una vocal: \n");
  scanf(" %c", vocal);

  codigoAscii = *p1;
  if (*p1 >= 'a' && *p1 <= 'z')
  {
    vocalInversa[0] = codigoAscii - 32;
  }
  else
  {
    vocalInversa[0] = codigoAscii + 32;
  }
  while (*p != '\0')
  {
    if (*p == *p1 || *p == vocalInversa[0])
    {
      if (cont % 2 == 0)
        {
          if (*p1 == 'a' || *p1 == 'A')
            {
              cont++;
              *p = 'A';
            }
          if (*p1 == 'e' || *p1 == 'E')
            {
              cont++;
              *p = 'E';
            }
          if (*p1 == 'i' || *p1 == 'I')
            {
              cont++;
              *p = 'I';
            }
          if (*p1 == 'o' || *p1 == 'O')
            {
              cont++;
              *p = 'O';
            }
          if (*p1 == 'u' || *p1 == 'U')
            {
              cont++;
              *p = 'U';
            }
        }
        else
        {
          if (*p1 == 'a' || *p1 == 'A')
            {
              cont++;
              *p = 'a';
            }
          if (*p1 == 'e' || *p1 == 'E')
            {
              cont++;
              *p = 'e';
            }
          if (*p1 == 'i' || *p1 == 'I')
            {
              cont++;
              *p = 'i';
            }
          if (*p1 == 'o' || *p1 == 'O')
            {
              cont++;
              *p = 'o';
            }
          if (*p1 == 'u' || *p1 == 'U')
            {
              cont++;
              *p = 'u';
            }
        }
      
    }
    
    
    p++;
  }
  printf("%d\n", cont);
  printf("%s\n", cadena);
}


char punto4(){
  char cadena[] = "Mi profe consiguio una camara vieja antes de la pandemia, pero como ahora es un profe digital, el profe se consiguio una camara nueva mas bonita. Pasado el tiempo se dio cuenta que la camara nueva aunque bonita era una camara mala, pero que bobada, al fin y al cabo, ya sea con una camara vieja o una camara nueva, nunca la muestra en clase.";
  char *p = cadena;
  char nuevaCadena[500] = "";
  int posicion = 0;
  char palabra[] = "camara";
  char *p1 = palabra;
  bool continua = false;
  char *paCadena;

  while (*p != '\0')
  {
    if (*p == *p1)
    {
      continua = true;
      paCadena = p;
      while(*p1 != '\0' && continua)
      {
        if (*p1 == *paCadena)
        {
          p1++;
          paCadena++;
          
        }
        else
        {
          continua = false;
        }
      
      }
      p1 = palabra;
      if (continua)
      {
        p = paCadena;
      }
    }
  nuevaCadena[posicion] = *p;
  p++;
  posicion++;

  }
  printf("%s\n", nuevaCadena);

}


void menu(){
	printf( "BIENVENIDO AL TALLER 4\n"
           "=================\n"
           "Presione 1 si quiere iniciar el punto 1\n"
           "Presione 2 si quiere iniciar el punto 2\n"
           "Presione 3 si quiere iniciar el punto 3\n"
           "Presione 4 si quiere iniciar el punto 4\n"
           "Presione 0 para salir del programa\n");
}
   
	
int main()
{
	int opcion;
	do{
		menu();
   		scanf( "%d", &opcion );
   		//gets(opcion);
   		switch(opcion)
   		{
	   		case 1:
	   			punto1();
	   			break;
	   		case 2:
	   			punto2();
	   			break;
	   		case 3:
	   			punto3();
	   			break;
	   		case 4:
	   			punto4();
	   			break;
   		}
	}
	while(opcion != 0);
	
	return 0;
}