//Incluyo biblioteca de entrada/salida.
#include <stdio.h>

int sumarNumeros(int numero1, int numero2){
  return numero1+numero2;
}
int restarNumeros(int numero1, int numero2){
  return numero1-numero2;
}
int multiplicarNumeros(int numero1, int numero2){
  return numero1*numero2;
}
float dividirNumeros(int numero1, int numero2){
  float result=0.0;
  if(numero2>0){
	result= (float)numero1/ (float)numero2;
  }else{
	printf("No se puede hacer esta operacion para los numeros %d--%d \n", numero1,numero2);
  }
  return result;
}


void sacarPalindromo(numero){
	int cifra1, cifra2, cifra3, cifra4, cifra6, cifra7, cifra8, cifra9;
	cifra1=numero % 10;
	numero /= 10;
	
	cifra2=numero % 10;
	numero /= 10;
	
	cifra3=numero % 10;
	numero /= 10;
	
	cifra4=numero % 10;
	numero /= 100;
	
	cifra6=numero % 10;
	numero /= 10;
	
	cifra7=numero % 10;
	numero /= 10;
	
	cifra8=numero % 10;
	numero /= 10;
	
	cifra9=numero % 10;

	if(cifra1 == cifra9 && cifra2 == cifra8 && cifra7 == cifra3 && cifra6 == cifra4){
		printf("El numero %d es palindromo \n",numero);
	}
	else{
		printf("El numero %d no es palindromo \n",numero);
	}
	return  0;
}

int verificarBisiesto(anio){
	if((anio % 100 != 0 && anio % 4 == 0) || (anio % 400 == 0)){
		return 1;
	}
	else{
		return 0;
	}
}

int main(){
  int num1,num2,resultadoSRM, palindromo, anio, bisiesto;
  float rDivision;
  printf("Bienvenidos a la calculadora basica \n");
  printf("Ingrese el primer numero: \n");
  scanf("%d",&num1);
  printf("Ingrese el segundo numero: \n");
  scanf("%d",&num2);
  
  //Operaciones
  resultadoSRM=sumarNumeros(num1,num2);
  printf("Resultado de la suma: %d \n", resultadoSRM);
  
   resultadoSRM=restarNumeros(num1,num2);
  printf("Resultado resta:  %d \n", resultadoSRM);
  
   resultadoSRM=multiplicarNumeros(num1,num2);
  printf("Resultado multiplicacion:  %d \n", resultadoSRM);
  
   rDivision=dividirNumeros(num1,num2);
  printf("Resultado division: %f \n \n", rDivision);
  // Numero palindromo
  printf("Digite un numero de 9 cifras: \n");
  scanf("%d", &palindromo);
  sacarPalindromo(palindromo);
  //A�o bisiesto
  printf("Digite un anio:");
  scanf("%d", &anio);
  bisiesto = verificarBisiesto(anio);
  if (bisiesto == 1){
  	printf("El anio %d es bisiesto y mi nombre es Edinson Pedroza \n", anio);
  }
  else{
  	printf("El anio %d no es bisiesto y tengo 2 hermanos \n", anio);
  }
  
  return 0;

}
