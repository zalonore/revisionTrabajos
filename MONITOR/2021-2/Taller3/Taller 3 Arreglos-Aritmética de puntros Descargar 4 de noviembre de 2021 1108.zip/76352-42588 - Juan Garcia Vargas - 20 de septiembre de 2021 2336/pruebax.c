#include<stdio.h>
#include<stdlib.h>
#include<time.h>


int funcionDos(int *array,int t){

   int i = 0,j = 0,sum,res,numero1,numero2;   
   printf("El arreglo aleatorio es el siguiente : ");
   for(i = 0; i < t; i++){
      printf("%d ",array[i]);
   }
   for(i = 0; i < t; i++){
      for(j = i + 1; j < t; j++){
         sum = array[i] + array[j];
         if(sum > 3333){
            res = array[i]-array[j];
            printf("\n");
            printf("la suma de %d + %d : %d y su resta es : %d",array[i],array[j],sum,res);
         }
         if(sum > 3333 && res < array[i++]-array[j++]){
               numero1 = array[i];
               numero2 = array[j];
            }
      }
   }
   printf("\n");
   printf("%d         %d",numero1,numero2);      



}


int main(){

   int array[40], i;
   srand(time(NULL));
   int t = sizeof( array ) / sizeof( int );
   for(i = 0; i < 40; i++){
      array[i] = 100 + rand()%2500; //printf(" %d ", array[i]);
   }
   funcionDos(array,t);
   return 0;
}