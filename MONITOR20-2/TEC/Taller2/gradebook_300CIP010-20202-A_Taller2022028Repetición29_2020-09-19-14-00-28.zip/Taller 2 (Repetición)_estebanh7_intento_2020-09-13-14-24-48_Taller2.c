#include <stdio.h>
#include <stdlib.h>

void menu(){
	printf( "\n" );
   	printf( "BIENVENIDO\n" );
  	printf( "=============== \n" );
  	printf( "QUE PUNTO DEL TALLER DESEA EJECUTAR?\n" );
  	printf( "1. Punto 1\n" );
   	printf( "2. Punto 2\n" );
   	printf( "3. Punto 3\n" );
  	printf( "4. Punto 4\n" );
   	printf( "0. salir\n" );
   	printf( "opcion: " );


   return;

}

void numerosAleatorios(){

	int numero, num, contador = 0;

	do{
		printf("Ingrese un numero del 0 al 5000: \n");
		scanf("%d",&num);

		srand(time(NULL));
		numero = rand() % 5000 ;
		printf("El numero era: %d\n", numero);
		contador++;

		if( contador > 5 && num == numero ){

			printf("Lo siento, eres muy lento, tienes que volver a intentar\n");
			
		}
		else if(num > numero){
			printf("Demasiado grande\n");
		}
		else if(num < numero){
			printf("Demasiado pequeno\n");
		}


	}while(num != numero);

	return;

}



void juego(){
	int numVeces, i, num, con = 0;
	float prom;
	printf("Cuantas veces va a digitar numeros en este juego?\n");
	scanf("%d",&numVeces);
	for(i=0; i < numVeces; i++){
		printf("Digite un numero del 50 al 80: \n");
		scanf("%d",&num);

		if(num < 50 || num > 80 ){
			printf( "\n" );
			printf("Digite otro numero!!!\n");
			printf( "\n" );
			
		}

		else if(num == 71 && i == 0){
			printf( "\n" );
			printf("Felicitaciones\n");
			printf( "\n" );

		}
		else if(num == 71 && i == 1 ){
			printf( "\n" );
			printf("Felicitaciones, venga por un premio manana\n");
			printf( "\n" );
		}
		else if(num == 71 && i == 2){
			printf( "\n" );
			printf("Usted esta muy sospechoso!!!\n");
			printf( "\n" );
		}
		
		con += num;
	}
	prom = con / (i + 1);
	printf("El promedio de los numeros es : %.2f\n", prom);



	return;
}



void camiones(){
	int papa, temp1=0, temp2=0,tempC=0,tempN=0,tempM=0, productos, i, camionesA, camionesB, tomate, cebolla, naranja, mango;
	printf("Cuantos camiones de papa llegaron? \n");
	scanf("%d",&camionesA);
	printf("Cuantos bultos de papa trajo en la carga? \n");
	scanf("%d",&papa);
	printf("Cuantos camiones B llegaron? \n");
	scanf("%d", &camionesB);
	for(i=1; i <= camionesB; i++){
		printf("\n");
		printf("Cuantos productos trae el camion %d? \n", i);
		scanf("%d",&productos);
		if(productos == 2){
			printf("Cuantos kilos de tomate el camion %d?\n",i);
			scanf("%d",&tomate);
			printf("Cuantos kilos de cebolla el camion %d?\n", i);
			scanf("%d",&cebolla);
		}
		else if(productos==3){
			printf("Cuantos kilos de tomate el camion %d?\n",i);
			scanf("%d",&tomate);
			printf("Cuantos kilos de cebolla el camion %d?\n", i);
			scanf("%d",&cebolla);
			printf("Cuantos kilos de naranja el camion %d?\n", i);
			scanf("%d",&naranja);
			temp1++;

		}
		else if(productos==4){
			printf("Cuantos kilos de tomate el camion %d?\n", i);
			scanf("%d",&tomate);
			printf("Cuantos kilos de cebolla el camion %d?\n", i);
			scanf("%d",&cebolla);
			printf("Cuantos kilos de naranja el camion %d?\n", i);
			scanf("%d",&naranja);
			printf("Cuantos kilos de mango el camion %d?\n", i);
			scanf("%d", &mango);
			temp2++;
		}
		else{
			return;
		}
		tempC+=cebolla;
		tempN+=naranja;
		tempM+=mango;
	}

	printf("LLegaron %d camiones tipo A\n", camionesA);
	printf("LLegaron %d camiones de 3 y 4 productos \n", (temp1 + temp2));
	printf("Llegaron %d kilos de cebolla\n", tempC);
	printf("Llegaron %d kilos de naranja\n", tempN);
	printf("Llegaron %d kilos de mango\n", tempM);



	return;
}


	


void numerosPrimos(){
	int p, i, j, contador=0;

	printf("Digite un numero mayor a 1000\n");
	scanf("%d",&p);
	for(i=2; i <= p; i++){
		for(j=2; j <= i; j++){
			if(i % j == 0){
				contador++;
			}
		}
		if(contador == 1){
			printf("%d\n",i);
		}
	

		contador=0;
	}
	

	return;
}



int main(){
	int opt;
	do{
		menu();
		scanf("%d",&opt);
		switch( opt ){
			case 1: numerosAleatorios();

				break;

			case 2: juego();
				break;

			case 3: camiones();
				break;

			case 4:numerosPrimos();
				break;


		}

	}while(opt != 0);
	

	return 0;
}





