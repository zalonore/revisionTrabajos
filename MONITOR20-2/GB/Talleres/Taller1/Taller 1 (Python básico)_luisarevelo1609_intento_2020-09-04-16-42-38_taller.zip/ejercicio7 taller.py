x=input("digite la primera variable, x=")
y=input("digite la segunda variable:y=")
variable1=x
variable2=y
x=variable2
y=variable1
print("la variable uno invertida es:x=",x)
print("la variable dos invertida es:y=",y)


