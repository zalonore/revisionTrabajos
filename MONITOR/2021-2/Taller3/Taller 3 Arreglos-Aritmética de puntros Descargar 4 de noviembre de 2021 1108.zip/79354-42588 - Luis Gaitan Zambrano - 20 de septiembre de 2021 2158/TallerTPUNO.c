/* 
TALLER 3
LUIS FELIPE GAITAN ZAMBRANO
PUNTO 1
*/
# include <stdio.h>
# define print printf

int main(){
	int i, j, k, l, contd = 0, conte= 0;
	int A[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
	int B[] = { 5, 7, 9, 10, 23, 8, 13, 87, 88, 90, 45, 67, 43, 32, 33, 54, 65, 66, 12, 69 };
	int C[] = { 2, 3, 4 ,10, 21, 12, 5, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 13, 9, 96 };
	int D[ 100 ];
	int E[ 100 ];
	// D y E, son la intersecci�n de los conjuntos A, B y C
	
	printf( "|= = = = = = = = = = = = = = = Conjunto A = = = = = = = = = = = = = = =|\n" );
	int n = sizeof( A ) / sizeof( int );
	for( i = 0; i < n; i++ ){
		printf( " %d ", A[ i ] ); 
	}
	printf( "\n\n\n|= = = = = = = = = = = = = = = = Conjunto B = = = = = = = = = = = = = = = =|" );
	printf("\n");
	for( i = 0; i < n; i++ ){
		printf( " %d ", B[ i ] ); 

	}
	printf( "\n\n\n|= = = = = = = = = = = = = = = = Conjunto C = = = = = = = = = = = = = = = =|" );
	printf("\n");
	for( i = 0; i < n; i++ ){
		printf( " %d ", C[ i ] ); 
	}
	printf( "\n\n\n|= = = = Conjunto D (interseccion de los elementos del conjunto A, B y C) = = =|" );
	printf("\n");
	for( i = 0; i < n; i++ ){
		for( j = 0; j < n; j++ ){
			if( A[ i ] == B[ j ] ){
				int found = 0;
				for( k = 0; k < contd; k++ ){
					if( A[ i ] == D[ k ] ){
						found = 1; 
						break;
					}	
				}
				if( !found ){
					D[ contd++ ] = A[ i ];
				}
				break;
			}
		}
	}	
	for( i = 0; i < contd; i++ ){
		for( j = 0; j < n; j++ ){
			if( D[ i ] == C[ j ] ){
				int found = 0;
				for( k = 0; k < conte; k++ ){
					if( D[ i ] == E[ k ] ){
						found = 1;
						break;
					}
				}
				if( !found ){
					E[ conte++ ] = D[ i ];
				}
				break;
			}
		}
	}
	for( i = 0; i < conte; i++){
		printf( " %d ", E[ i ] );
	}
	return 0;
}

