radio= int(input("digite el valor del radio="))
pi= float(input("dijite el valor de π(pi)="))


areadelcirculo= pi*radio**2
print("el valor del area de su circulo es=",areadelcirculo)
