#include<stdio.h> 

int main(){
    char palabra[ 100 ];
    int i, num = 0;
   
    printf( "Ponga una palabra / frase: " );
    fgets(palabra, sizeof(palabra), stdin );

    for( i = 0; i < sizeof(palabra); i++ ){
    	if( palabra[ i ] == '\0' ){
    		break;
    	}
    	else if ( palabra[ i ] == ' ' ){
    		num=num;
    	}
    	else{
    		num++;
    	}
    }

    printf("\n");
    printf( "la palabra o frase tiene %d letras" ,num - 1 );
    printf("\n");
    return 0;
}